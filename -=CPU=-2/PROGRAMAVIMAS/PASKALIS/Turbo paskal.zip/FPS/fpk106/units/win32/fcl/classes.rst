
# hash value = 82797892
classes.serrinvalidbitindex='Invalid bit index : %d'


# hash value = 220541588
classes.serrindextoolarge='Bit index exceeds array limit: %d'


# hash value = 33444681
classes.serroutofmemory='Out of memory'

