
# hash value = 216488147
math.smatherror='Math Error : %s'


# hash value = 12736788
math.sinvalidargument='Invalid argument'

