
# hash value = 47007666
typinfo.serrpropertynotfound='Unknown property: "%s"'


# hash value = 135048418
typinfo.serrunknownenumvalue='Unknown enumeration value: "%s"'

