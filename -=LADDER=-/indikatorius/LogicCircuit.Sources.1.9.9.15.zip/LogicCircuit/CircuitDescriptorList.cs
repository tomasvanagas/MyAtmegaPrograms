﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;

namespace LogicCircuit {
	public class CircuitDescriptorList : IEnumerable<CircuitDescriptor>, INotifyCollectionChanged {

		public event NotifyCollectionChangedEventHandler CollectionChanged;

		private ProjectManager projectManager;
		private MainFrame mainFrame;
		private List<CircuitDescriptor> staticList;
		private List<CircuitDescriptor> list;
		private bool listIsDirty;

		public CircuitDescriptorList(ProjectManager projectManager, MainFrame mainFrame) {
			this.projectManager = projectManager;
			this.mainFrame = mainFrame;
			this.InitStaticList();
			this.InitList();
			this.projectManager.ProjectStore.ItemChanged += new ItemStore<Project>.ItemChangedEventHandler(this.ProjectStoreChanged);
			this.projectManager.PinStore.ItemChanged += new ItemStore<Pin>.ItemChangedEventHandler(this.PinStoreChanged);
			this.projectManager.LogicalCircuitStore.ItemChanged += new ItemStore<LogicalCircuit>.ItemChangedEventHandler(this.LogicalCircuitStoreChanged);
			this.projectManager.EditEnded += new EventHandler(this.ProjectManagerEditEnded);
		}

		private void InitStaticList() {
			ProjectManager pm = new ProjectManager();
			pm.BeginTransaction();
			List<CircuitDescriptor> list = new List<CircuitDescriptor>();
			list.Add(new PinDescriptor(pm, PinType.Input));
			list.Add(new PinDescriptor(pm, PinType.Output));
			list.Add(new ButtonDescriptor(pm));
			list.Add(new ConstantDescriptor(pm));
			list.Add(new SplitterDescriptor(pm));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Clock, 0, 0, false));

			list.Add(new GateDescriptor(pm.GateStore, GateType.Led, 1, 1, false));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Led, 8, 8, false));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Probe, 1, 1, false));

			list.Add(new GateDescriptor(pm.GateStore, GateType.Not, 1, 1, true));
			list.Add(new GateDescriptor(pm.GateStore, GateType.TriState, 2, 2, false));
			list.Add(new GateDescriptor(pm.GateStore, GateType.And, 2, Gate.MaxInputCount, false));
			list.Add(new GateDescriptor(pm.GateStore, GateType.And, 2, Gate.MaxInputCount, true));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Or, 2, Gate.MaxInputCount, false));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Or, 2, Gate.MaxInputCount, true));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Xor, 2, Gate.MaxInputCount, false));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Xor, 2, Gate.MaxInputCount, true));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Even, 2, Gate.MaxInputCount, false));
			list.Add(new GateDescriptor(pm.GateStore, GateType.Odd, 2, Gate.MaxInputCount, false));

			list.Add(new MemoryDescriptor(pm, false));
			list.Add(new MemoryDescriptor(pm, true));

			this.staticList = list;
		}

		private void InitList() {
			LogicalCircuitStore store = this.projectManager.LogicalCircuitStore;
			List<CircuitDescriptor> list = new List<CircuitDescriptor>();
			foreach(LogicalCircuit item in store) {
				list.Add(
					new LogicalCircuitDescriptor(this.projectManager, item,
						s => this.staticList.Find(d => StringComparer.OrdinalIgnoreCase.Compare(d.Category, s) == 0) != null
					)
				);
			}
			list.Sort(NameComparer.Comparer);
			this.list = new List<CircuitDescriptor>(list.Count + this.staticList.Count);
			this.list.AddRange(list);
			this.list.AddRange(this.staticList);
		}

		public IEnumerator<CircuitDescriptor> GetEnumerator() {
			return this.list.GetEnumerator();
		}

		System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() {
			return this.GetEnumerator();
		}

		private void Notify() {
			NotifyCollectionChangedEventHandler handler = this.CollectionChanged;
			if(handler != null) {
				handler(this, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
			}
		}

		private void Update() {
			try {
				this.InitList();
				this.Notify();
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void ProjectManagerEditEnded(object sender, EventArgs e) {
			if(this.listIsDirty) {
				this.listIsDirty = false;
				try {
					this.mainFrame.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, new Action(this.Update));
				} catch(Exception exception) {
					MainFrame.Report(exception);
				}
			}
		}

		private void ProjectStoreChanged(Project item, ItemAction action) {
			this.listIsDirty = true;
		}

		private void PinStoreChanged(Pin item, ItemAction action) {
			this.listIsDirty = true;
		}

		private void LogicalCircuitStoreChanged(LogicalCircuit item, ItemAction action) {
			this.listIsDirty = true;
		}

		private class NameComparer : IComparer<CircuitDescriptor> {
			public static readonly NameComparer Comparer = new NameComparer();

			public int Compare(CircuitDescriptor x, CircuitDescriptor y) {
				return StringComparer.Ordinal.Compare(x.Name, y.Name);
			}
		}
	}
}
