﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace LogicCircuit {
	/// <summary>
	/// Interaction logic for DialogRAM.xaml
	/// </summary>
	public partial class DialogRAM : Window {

		private SettingsWindowLocationCache windowLocation;
		public SettingsWindowLocationCache WindowLocation { get { return this.windowLocation ?? (this.windowLocation = new SettingsWindowLocationCache(this)); } }

		private Memory memory;

		public DialogRAM(Memory memory) {
			Tracer.Assert(memory.Writable);
			this.memory = memory;
			this.DataContext = this;
			this.InitializeComponent();

			this.addressBitWidth.ItemsSource = CircuitDescriptor.AddressBitRange();
			this.dataBitWidth.ItemsSource = CircuitDescriptor.BitRange(1);
			this.writeOn.ItemsSource = new string[] { LogicCircuit.Resources.WriteOn0, LogicCircuit.Resources.WriteOn1 };
			this.addressBitWidth.SelectedItem = this.memory.AddressBitWidth;
			this.dataBitWidth.SelectedItem = this.memory.DataBitWidth;
			this.writeOn.SelectedIndex = this.memory.WriteOn1 ? 1 : 0;
		}

		private void ButtonOkClick(object sender, RoutedEventArgs e) {
			Transaction transaction = this.memory.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				this.memory.AddressBitWidth = (int)this.addressBitWidth.SelectedItem;
				this.memory.DataBitWidth = (int)this.dataBitWidth.SelectedItem;
				this.memory.WriteOn1 = (this.writeOn.SelectedIndex == 0) ? false : true;
				MemoryStore.UpdateWritePinName(this.memory);
				foreach(CircuitSymbol symbol in this.memory.ProjectManager.CircuitSymbolStore.Select(this.memory)) {
					symbol.RefreshGlyph();
				}
				success = true;
			} catch(Exception exception) {
				MainFrame.Report(exception);
			} finally {
				this.memory.ProjectManager.EndTransaction(transaction, success);
			}
			MainFrame mainFrame = this.Owner as MainFrame;
			if(mainFrame != null) {
				mainFrame.CircuitEditor.Refresh();
			}
			this.Close();
		}
	}
}
