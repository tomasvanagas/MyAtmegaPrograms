﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;

namespace LogicCircuit {
	partial class MainFrame {
		private void FileNewCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				this.New();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.FileNewCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void FileOpenCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				this.Open();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.FileOpenCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void FileSaveCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				this.Save();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.FileSaveCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void FileSaveAsCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				this.SaveAs();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.FileSaveAsCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void FileExportImageCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(!this.CircuitEditor.LogicalCircuit.IsEmpty) {
					DialogExportImage dialog = new DialogExportImage(this.CircuitEditor);
					dialog.Owner = this;
					dialog.ShowDialog();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.FileExportImageCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void FileExportImageCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = !this.CircuitEditor.LogicalCircuit.IsEmpty;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.FileExportImageCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void FileCloseCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			this.Close();
		}

		private void EditCutCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.Cut();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditCutCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditCutCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && 0 < this.CircuitEditor.SelectionCount;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditCutCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditCopyCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.Copy();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditCopyCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditCopyCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && 0 < this.CircuitEditor.SelectionCount;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditCopyCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditPasteCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.Paste();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditPasteCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditPasteCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && this.CircuitEditor.CanPaste();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditPasteCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditDeleteCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.Delete();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditDeleteCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditDeleteCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && 0 < this.CircuitEditor.SelectionCount;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditDeleteCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.SelectAll();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllWiresCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.SelectAllWires();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllWiresCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllWiresCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllWiresCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectFreeWiresCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.SelectFreeWires();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectFreeWiresCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectFreeWiresCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectFreeWiresCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectFloatingSymbolsCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.SelectFloatingSymbols();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectFloatingSymbolsCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectFloatingSymbolsCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectFloatingSymbolsCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllButWiresCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.SelectAllButWires();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllButWiresCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllButWiresCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllButWiresCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditUnselectAllWiresCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode && 0 < this.CircuitEditor.SelectionCount) {
					this.CircuitEditor.UnselectAllWires();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditUnselectAllWiresCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditUnselectAllWiresCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && 0 < this.CircuitEditor.SelectionCount;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditUnselectAllWiresCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditUnselectAllButWiresCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode && 0 < this.CircuitEditor.SelectionCount) {
					this.CircuitEditor.UnselectAllButWires();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditUnselectAllButWiresCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditUnselectAllButWiresCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && 0 < this.CircuitEditor.SelectionCount;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditUnselectAllButWiresCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllProbesCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.SelectAllProbes(false);
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllProbesCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllProbesCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllProbesCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllProbesWithWireCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.SelectAllProbes(true);
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllProbesWithWireCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditSelectAllProbesWithWireCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditSelectAllProbesWithWireCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void EditUndoCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode && this.CircuitEditor.ProjectManager.HasUndo) {
					this.CircuitEditor.Undo();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditUndoCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditUndoCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && this.CircuitEditor.ProjectManager.HasUndo;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditUndoCommandCanExecut", exception);
				this.ReportException(exception);
			}
		}

		private void EditRedoCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode && this.CircuitEditor.ProjectManager.HasRedo) {
					this.CircuitEditor.Redo();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditRedoCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void EditRedoCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode && this.CircuitEditor.ProjectManager.HasRedo;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.EditRedoCommandCanExecut", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitProjectCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.Edit(this.CircuitEditor.ProjectManager.ProjectStore.Project);
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitProjectCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitProjectCommandCanExecuted(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitProjectCommandCanExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitCurrentCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					this.CircuitEditor.Edit(this.CircuitEditor.LogicalCircuit);
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitCurrentCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitCurrentCommandCanExecuted(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitCurrentCommandCanExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitNewCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode) {
					Transaction transaction = this.CircuitEditor.ProjectManager.BeginTransaction();
					bool success = false;
					try {
						LogicalCircuit lc = this.CircuitEditor.ProjectManager.LogicalCircuitStore.Create();
						this.CircuitEditor.LogicalCircuit = lc;
						this.CircuitEditor.Refresh();
						success = true;
					} finally {
						this.CircuitEditor.ProjectManager.EndTransaction(transaction, success);
					}
					this.OnPropertyChanged("ProjectManager");
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitCurrentCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitNewCommandCanExecuted(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = this.CircuitEditor.InEditMode;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitNewCommandCanExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitDeleteCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitEditor.InEditMode && 1 < this.CircuitEditor.ProjectManager.LogicalCircuitStore.Count) {
					this.CircuitEditor.DeleteLogicalCircuit();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitDeleteCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void CircuitDeleteCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = (this.CircuitEditor.InEditMode && 1 < this.CircuitEditor.ProjectManager.LogicalCircuitStore.Count);
			} catch(Exception exception) {
				Tracer.Report("MainFrame.CircuitDeleteCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void ToolsReportCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				LogicalCircuit root = this.CircuitEditor.LogicalCircuit;
				CircuitMap map = this.CircuitRunner.VisibleMap;
				if(map != null && !this.CircuitEditor.InEditMode) {
					map = map.Root;
					root = map.Circuit;
				}
				DialogReport dialog = new DialogReport(root);
				dialog.Owner = this;
				dialog.ShowDialog();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.ToolsReportCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void ToolsOscilloscopeCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				if(this.CircuitRunner.IsTurnedOn &&
					this.CircuitRunner.CircuitState.HasProbes &&
					this.CircuitRunner.DialogOscilloscope == null
				) {
					DialogOscilloscope dialog = new DialogOscilloscope(this.CircuitRunner);
					dialog.Owner = this;
					dialog.Show();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.ToolsOscilloscopeCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void ToolsOscilloscopeCommandCanExecute(object target, CanExecuteRoutedEventArgs e) {
			try {
				e.CanExecute = (
					this.CircuitRunner.IsTurnedOn &&
					this.CircuitRunner.CircuitState.HasProbes &&
					this.CircuitRunner.DialogOscilloscope == null
				);
			} catch(Exception exception) {
				Tracer.Report("MainFrame.ToolsOscilloscopeCommandCanExecute", exception);
				this.ReportException(exception);
			}
		}

		private void ToolsOptionsCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				DialogOptions dialog = new DialogOptions();
				dialog.Owner = this;
				bool? result = dialog.ShowDialog();
				if(result.HasValue && result.Value) {
					Transaction transaction = this.ProjectManager.BeginTransaction();
					bool success = false;
					try {
						foreach(CircuitSymbol symbol in this.ProjectManager.CircuitSymbolStore) {
							symbol.RefreshGlyph();
						}
						success = true;
					} finally {
						this.ProjectManager.EndTransaction(transaction, success);
					}
					this.OnPropertyChanged("CircuitDescriptorList");
					this.OnPropertyChanged("GridBrush");
					this.CircuitEditor.Refresh();
					if(this.CircuitRunner.IsTurnedOn) {
						this.CircuitRunner.VisibleMap.Redraw();
					}
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.ToolsOptionsCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void HelpContentCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				Process.Start(LogicCircuit.Resources.HelpContent);
			} catch(Exception exception) {
				Tracer.Report("MainFrame.HelpContentCommandExecuted", exception);
				this.ReportException(exception);
			}
		}

		private void HelpAboutCommandExecuted(object target, ExecutedRoutedEventArgs e) {
			try {
				DialogAbout dialog = new DialogAbout();
				dialog.Owner = this;
				dialog.ShowDialog();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.HelpAboutCommandExecuted", exception);
				this.ReportException(exception);
			}
		}
	}
}
