﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace LogicCircuit {
	/// <summary>
	/// Interaction logic for DialogCircuit.xaml
	/// </summary>
	public partial class DialogCircuit : Window {

		private SettingsWindowLocationCache windowLocation;
		public SettingsWindowLocationCache WindowLocation { get { return this.windowLocation ?? (this.windowLocation = new SettingsWindowLocationCache(this)); } }
		private LogicalCircuit logicalCircuit;

		public DialogCircuit(LogicalCircuit logicalCircuit) {
			this.DataContext = this;
			this.InitializeComponent();
			this.logicalCircuit = logicalCircuit;
			this.name.Text = this.logicalCircuit.Name;
			this.notation.Text = this.logicalCircuit.Notation;
			HashSet<string> list = new HashSet<string>();
			foreach(LogicalCircuit circuit in this.logicalCircuit.ProjectManager.LogicalCircuitStore) {
				if(list.Add(circuit.Category)) {
					this.category.Items.Add(circuit.Category);
				}
			}
			if(list.Add(string.Empty)) {
				this.category.Items.Add(string.Empty);
			}
			this.category.Text = this.logicalCircuit.Category;
			this.description.Text = this.logicalCircuit.Description;
			this.Loaded += new RoutedEventHandler(this.DialogCircuitLoaded);
		}

		private void DialogCircuitLoaded(object sender, RoutedEventArgs e) {
			ControlTemplate template = this.category.Template;
			if(template != null) {
				TextBox textBox = template.FindName("PART_EditableTextBox", this.category) as TextBox;
				if(textBox != null) {
					SpellCheck spellCheck = textBox.SpellCheck;
					if(spellCheck != null) {
						spellCheck.IsEnabled = true;
					}
				}
			}
		}

		private void ButtonOkClick(object sender, RoutedEventArgs e) {
			Transaction transaction = this.logicalCircuit.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				this.logicalCircuit.Rename(this.name.Text.Trim());
				this.logicalCircuit.Notation = this.notation.Text.Trim();
				string text = this.category.Text.Trim();
				text = text.Substring(0, Math.Min(text.Length, 64)).Trim();
				this.logicalCircuit.Category = text;
				this.logicalCircuit.Description = this.description.Text.Trim();
				foreach(CircuitSymbol symbol in this.logicalCircuit.ProjectManager.CircuitSymbolStore.Select(this.logicalCircuit)) {
					symbol.RefreshGlyph();
				}
				success = true;
			} catch(Exception exception) {
				MainFrame.Report(exception);
			} finally {
				this.logicalCircuit.ProjectManager.EndTransaction(transaction, success);
			}
			MainFrame mainFrame = this.Owner as MainFrame;
			if(mainFrame != null) {
				mainFrame.CircuitEditor.Refresh();
			}
			this.Close();
		}
	}
}
