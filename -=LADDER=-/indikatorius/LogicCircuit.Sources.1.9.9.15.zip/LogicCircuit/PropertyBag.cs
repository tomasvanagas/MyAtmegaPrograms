﻿using System;
using System.ComponentModel;
using System.Diagnostics;

namespace LogicCircuit {
	public abstract class PropertyBag : INotifyPropertyChanged {

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string propertyName) {
			PropertyChangedEventHandler handler = this.PropertyChanged;
			if(handler != null) {
				handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}
}
