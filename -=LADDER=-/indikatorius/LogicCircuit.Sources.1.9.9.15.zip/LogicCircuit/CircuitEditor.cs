﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;

namespace LogicCircuit {
	public partial class CircuitEditor : CircuitViewer {

		public MainFrame MainFrame { get; private set; }
		private Switcher switcher;

		public CircuitEditor(MainFrame mainFrame, Canvas canvas, ProjectManager projectManager) : base(canvas, projectManager) {
			this.MainFrame = mainFrame;
			canvas.DragEnter += new DragEventHandler(this.canvas_DragOver);
			canvas.DragLeave += new DragEventHandler(this.canvas_DragLeave);
			canvas.DragOver += new DragEventHandler(this.canvas_DragOver);
			canvas.Drop += new DragEventHandler(this.canvas_Drop);
			canvas.MouseDown += new MouseButtonEventHandler(this.canvas_MouseDown);
			canvas.MouseUp += new MouseButtonEventHandler(this.canvas_MouseUp);
			canvas.MouseMove += new MouseEventHandler(this.canvas_MouseMove);
			canvas.LostFocus += new RoutedEventHandler(this.canvas_LostFocus);
			canvas.LostKeyboardFocus += new KeyboardFocusChangedEventHandler(this.canvas_LostKeyboardFocus);
			this.MainFrame.LostFocus += new RoutedEventHandler(this.canvas_LostFocus);
			this.MainFrame.LostKeyboardFocus += new KeyboardFocusChangedEventHandler(this.canvas_LostKeyboardFocus);
			Keyboard.AddKeyDownHandler(this.MainFrame, new KeyEventHandler(this.canvas_KeyDown));
			Keyboard.AddKeyUpHandler(this.MainFrame, new KeyEventHandler(this.canvas_KeyUp));
			this.OnProjectLoad();
		}

		public bool InEditMode { get { return !this.MainFrame.CircuitRunner.IsTurnedOn; } }

		public void OnProjectLoad() {
			this.switcher = new Switcher(this);
			// TODO: this is not very good way to get scroll control as this assumes canvas is sitting on scroll viewer.
			// What if this get changed? For now just do it in hackky way
			ScrollViewer scrollViewer = this.Canvas.Parent as ScrollViewer;
			if(scrollViewer != null) {
				scrollViewer.ScrollToTop();
				scrollViewer.ScrollToLeftEnd();
			}
		}

		public void OpenLogicalCircuit(LogicalCircuit logicalCircuit) {
			this.CancelAllMoves();
			this.ClearSelection();
			Transaction transaction = this.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				LogicalCircuit oldLogicalCircuit = this.LogicalCircuit;
				this.LogicalCircuit = logicalCircuit;
				this.Redraw();
				// TODO: this is not very good way to get scroll control as this assumes canvas is sitting on scroll viewer.
				// What if this get changed? For now just do it in hackky way
				ScrollViewer scrollViewer = this.Canvas.Parent as ScrollViewer;
				if(scrollViewer != null) {
					oldLogicalCircuit.ScrollOffset = new Point(scrollViewer.HorizontalOffset, scrollViewer.VerticalOffset);
					scrollViewer.ScrollToHorizontalOffset(logicalCircuit.ScrollOffset.X);
					scrollViewer.ScrollToVerticalOffset(logicalCircuit.ScrollOffset.Y);
				}
				success = true;
			} finally {
				this.ProjectManager.EndTransaction(transaction, success);
			}
		}

		public void OpenLogicalCircuit(CircuitMap map) {
			this.OpenLogicalCircuit(map.Circuit);
			this.MainFrame.CircuitRunner.VisibleMap = map;
			this.MainFrame.Status = map.Path();
			map.Redraw();
		}

		public void Refresh() {
			this.CancelWire();
			this.ClearSelection();
			this.Redraw();
		}

		public void Copy() {
			this.CancelWire();
			if(0 < this.SelectionCount) {
				XmlDocument xml = this.ProjectManager.Copy(this.selection.Keys);
				StringBuilder text = new StringBuilder();
				using(StringWriter stringWriter = new StringWriter(text, CultureInfo.InvariantCulture)) {
					using(XmlTextWriter writer = new XmlTextWriter(stringWriter)) {
						Store.DefineFormatting(writer);
						xml.WriteTo(writer);
					}
				}
				Clipboard.SetDataObject(text.ToString(), false);
			}
		}

		public bool CanPaste() {
			return this.CanPaste(Clipboard.GetText());
		}

		public void Paste() {
			this.CancelWire();
			this.ClearSelection();
			string text = Clipboard.GetText();
			if(this.CanPaste(text)) {
				XmlDocument xml = new XmlDocument();
				xml.LoadXml(text);
				List<Symbol> result = null;
				Transaction transaction = this.ProjectManager.BeginTransaction();
				bool success = false;
				try {
					result = this.ProjectManager.Paste(xml);
					success = true;
				} finally {
					this.ProjectManager.EndTransaction(transaction, success);
				}
				this.Refresh();
				LogicalCircuit lc = this.LogicalCircuit;
				foreach(Symbol symbol in result) {
					if(symbol.LogicalCircuit == lc) {
						this.Select(symbol);
					}
				}
			}
		}

		public void Delete() {
			this.CancelWire();
			if(0 < this.SelectionCount) {
				IEnumerable<Symbol> selection = this.Selection();
				this.ClearSelection();
				Transaction transaction = this.ProjectManager.BeginTransaction();
				bool success = false;
				try {
					foreach(Symbol symbol in selection) {
						CircuitSymbol circuitSymbol = symbol as CircuitSymbol;
						if(circuitSymbol != null) {
							if(circuitSymbol.Circuit is Gate || circuitSymbol.Circuit is LogicalCircuit) {
								circuitSymbol.Delete();
							} else {
								circuitSymbol.Circuit.Delete();
							}
						} else if(symbol is Wire) {
							symbol.Delete();
						}
					}
					success = true;
				} finally {
					this.ProjectManager.EndTransaction(transaction, success);
				}
				this.Redraw();
			}
		}

		public void Cut() {
			this.CancelWire();
			if(0 < this.SelectionCount) {
				this.Copy();
				this.Delete();
			}
		}

		public void DeleteLogicalCircuit() {
			if(1 < this.ProjectManager.LogicalCircuitStore.Count) {
				this.CancelWire();
				this.ClearSelection();
				LogicalCircuit current = this.LogicalCircuit;
				LogicalCircuit other = this.switcher.SuggestNext();
				Tracer.Assert(other != null && other != current);
				Transaction transaction = this.ProjectManager.BeginTransaction();
				bool success = false;
				try {
					this.LogicalCircuit = other;
					current.Delete();
					success = true;
				} finally {
					this.ProjectManager.EndTransaction(transaction, success);
				}
				this.Redraw();
			}
		}

		public void Edit(Project project) {
			Tracer.Assert(project == this.ProjectManager.ProjectStore.Project);
			DialogProject dialog = new DialogProject(project);
			dialog.Owner = this.MainFrame;
			dialog.ShowDialog();
		}

		public void Edit(LogicalCircuit logicalCircuit) {
			DialogCircuit dialog = new DialogCircuit(logicalCircuit);
			dialog.Owner = this.MainFrame;
			dialog.ShowDialog();
		}

		public void Edit(Pin pin) {
			DialogPin dialog = new DialogPin(pin);
			dialog.Owner = this.MainFrame;
			dialog.ShowDialog();
		}

		public void Edit(CircuitButton button) {
			DialogButton dialog = new DialogButton(button);
			dialog.Owner = this.MainFrame;
			dialog.ShowDialog();
		}

		public void Edit(Constant constant) {
			DialogConstant dialog = new DialogConstant(constant);
			dialog.Owner = this.MainFrame;
			dialog.ShowDialog();
		}

		public void Edit(Memory memory) {
			if(memory.Writable) {
				DialogRAM dialog = new DialogRAM(memory);
				dialog.Owner = this.MainFrame;
				dialog.ShowDialog();
			} else {
				DialogROM dialog = new DialogROM(memory);
				dialog.Owner = this.MainFrame;
				dialog.ShowDialog();
			}
		}

		public void ShowFunctionProbe(FunctionProbe functionProbe) {
			if(functionProbe != null) {
				DialogProbeHistory dialog = new DialogProbeHistory(functionProbe);
				dialog.Owner = this.MainFrame;
				dialog.ShowDialog();
			}
		}

		public void ShowFunctionMemory(FunctionMemory functionMemory) {
			if(functionMemory != null) {
				DialogMemory dialog = new DialogMemory(functionMemory);
				dialog.Owner = this.MainFrame;
				dialog.ShowDialog();
			}
		}

		public void TurnOn() {
			this.ClearSelection();
			this.CancelWire();
			this.MainFrame.CircuitRunner.TurnOn();
		}
		public void TurnOff() {
			this.MainFrame.CircuitRunner.TurnOff();
		}

		public void Undo() {
			this.CancelWire();
			this.ClearSelection();
			this.ProjectManager.Undo();
			this.Redraw();
		}

		public void Redo() {
			this.CancelWire();
			this.ClearSelection();
			this.ProjectManager.Redo();
			this.Redraw();
		}

		public RenderTargetBitmap ExportImage() {
			Rect rect = new Rect();
			bool isEmpty = true;
			foreach(Wire wire in this.LogicalCircuit.Wire) {
				Rect wireRect = new Rect(Plotter.ScreenPoint(wire.Point1), Plotter.ScreenPoint(wire.Point2));
				if(isEmpty) {
					rect = wireRect;
					isEmpty = false;
				} else {
					rect.Union(wireRect);
				}
			}
			foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
				Rect symbolRect = new Rect(Plotter.ScreenPoint(symbol.Point), new Size(symbol.Glyph.Width, symbol.Glyph.Height));
				if(isEmpty) {
					rect = symbolRect;
					isEmpty = false;
				} else {
					rect.Union(symbolRect);
				}
			}
			if(!isEmpty) {
				rect.Inflate(Plotter.GridSize, Plotter.GridSize);
				rect.Intersect(new Rect(0, 0, this.Canvas.Width, this.Canvas.Height));
				Brush oldBackground = this.Canvas.Background;
				Transform oldRenderTransform = this.Canvas.RenderTransform;
				Transform oldLayoutTransform = this.Canvas.LayoutTransform;
				double horizontalOffset = 0;
				double verticalOffset = 0;
				ScrollViewer scrollViewer = this.Canvas.Parent as ScrollViewer;
				try {
					if(scrollViewer != null) {
						horizontalOffset = scrollViewer.HorizontalOffset;
						verticalOffset = scrollViewer.VerticalOffset;
						scrollViewer.ScrollToHorizontalOffset(0);
						scrollViewer.ScrollToVerticalOffset(0);
						scrollViewer.UpdateLayout();
					}
					this.Canvas.Background = Brushes.White;
					this.Canvas.RenderTransform = new TranslateTransform(-rect.X, -rect.Y);
					this.Canvas.LayoutTransform = Transform.Identity;
					this.Canvas.UpdateLayout();
					RenderTargetBitmap bitmap = new RenderTargetBitmap(
						(int)Math.Round(rect.Width), (int)Math.Round(rect.Height), 96, 96, PixelFormats.Pbgra32
					);
					bitmap.Render(this.Canvas);
					return bitmap;
				} finally {
					this.Canvas.Background = oldBackground;
					this.Canvas.RenderTransform = oldRenderTransform;
					this.Canvas.LayoutTransform = oldLayoutTransform;
					this.Canvas.UpdateLayout();
					if(scrollViewer != null) {
						scrollViewer.ScrollToHorizontalOffset(horizontalOffset);
						scrollViewer.ScrollToVerticalOffset(verticalOffset);
						scrollViewer.UpdateLayout();
					}
				}
			}
			return null;
		}

		private bool CanPaste(string text) {
			return (
				!string.IsNullOrEmpty(text) &&
				Regex.IsMatch(text, Regex.Escape("<lc:CircuitProject xmlns:lc=\"" + this.ProjectManager.NamespaceUri + "\">"))
			);
		}

		private void ShowStatus(CircuitSymbol symbol) {
			this.MainFrame.Status = symbol.Circuit.Notation + symbol.Point.ToString();
		}

		private FrameworkElement RootElement(FrameworkElement element) {
			while(element != null && element.Parent != this.Canvas && element.Tag == null) {
				if(element.Parent == null) {
					element = element.TemplatedParent as FrameworkElement;
				} else {
					element = element.Parent as FrameworkElement;
				}
			}
			return element;
		}

		private static bool IsPinClose(Point p1, Point p2) {
			return Point.Subtract(p1, p2).LengthSquared <= Plotter.PinRadius * Plotter.PinRadius * 5;
		}

		private static Point WireEndPoint(Point point) {
			return Point.Add(Plotter.ScreenPoint(Plotter.GridPoint(point)), new Vector(Plotter.PinRadius, Plotter.PinRadius));
		}

		private Line FindLineNear(Point point) {
			Rect rect = new Rect(
				point.X - 2 * Plotter.PinRadius, point.Y - 2 * Plotter.PinRadius,
				2 * 2 * Plotter.PinRadius, 2 * 2 * Plotter.PinRadius
			);
			foreach(UIElement element in this.Canvas.Children) {
				Line line = element as Line;
				if(line != null) {
					if(Plotter.Intersected(new Point(line.X1, line.Y1), new Point(line.X2, line.Y2), rect)) {
						return line;
					}
				}
			}
			return null;
		}

		private bool JamExistsNear(GridPoint point) {
			foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
				if(symbol.X <= point.X && symbol.Y <= point.Y) {
					foreach(Jam jam in this.ProjectManager.JamStore.Select(symbol)) {
						if(jam.AbsolutePoint == point) {
							return true;
						}
					}
				}
			}
			return false;
		}

		private bool JamExistsNear(Point point) {
			return (
				CircuitEditor.IsPinClose(point, CircuitEditor.WireEndPoint(point)) &&
				this.JamExistsNear(Plotter.GridPoint(CircuitEditor.WireEndPoint(point)))
			);
		}

		private bool Split(Wire wire, GridPoint point) {
			Tracer.Assert(wire.LogicalCircuit == this.LogicalCircuit);
			if(wire.Point1 != point && wire.Point2 != point) {
				Wire wire2 = null;
				Transaction transaction = this.ProjectManager.BeginTransaction();
				bool success = false;
				try {
					wire2 = this.ProjectManager.WireStore.Create(wire.LogicalCircuit, point, wire.Point2);
					wire.Point2 = point;
					success = true;
				} finally {
					this.ProjectManager.EndTransaction(transaction, success);
				}
				this.ClearSelection();
				this.Refresh();
				this.Select(wire);
				this.Select(wire2);
				return true;
			}
			return false;
		}

		private bool Merge(Wire wire1, Wire wire2) {
			Tracer.Assert(wire1.LogicalCircuit == this.LogicalCircuit && wire2.LogicalCircuit == this.LogicalCircuit);
			GridPoint point1, point2;
			if(wire1.Point1 == wire2.Point1) {
				point1 = wire1.Point2;
				point2 = wire2.Point2;
			} else if(wire1.Point1 == wire2.Point2) {
				point1 = wire1.Point2;
				point2 = wire2.Point1;
			} else if(wire1.Point2 == wire2.Point1) {
				point1 = wire1.Point1;
				point2 = wire2.Point2;
			} else if(wire1.Point2 == wire2.Point2) {
				point1 = wire1.Point1;
				point2 = wire2.Point1;
			} else {
				return false;
			}
			Transaction transaction = this.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				wire2.Delete();
				wire1.Point1 = point1;
				wire1.Point2 = point2;
				success = true;
			} finally {
				this.ProjectManager.EndTransaction(transaction, success);
			}
			this.ClearSelection();
			this.Refresh();
			this.Select(wire1);
			return true;
		}
	}
}
