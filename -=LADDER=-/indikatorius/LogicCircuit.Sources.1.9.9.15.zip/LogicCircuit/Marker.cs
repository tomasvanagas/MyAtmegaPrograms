﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace LogicCircuit {
	public class Marker {

		public Symbol Symbol { get; private set; }
		public FrameworkElement Glyph { get; private set; }
		public Canvas Canvas { get { return MainFrame.FindMainFrame(this.Glyph).diagram; } }
		public MarkerPoint Point1 { get; private set; }
		public MarkerPoint Point2 { get; private set; }

		public Marker(Symbol symbol) {
			this.Symbol = symbol;
			Tracer.Assert(this.Symbol.Glyph != null);
			CircuitSymbol circuitSymbol = symbol as CircuitSymbol;
			if(circuitSymbol != null) {
				this.Init(circuitSymbol);
			} else {
				//wire
				Wire wire = symbol as Wire;
				if(wire != null) {
					this.Init(wire);
				} else {
					//nothing else can be here so far
					Tracer.Fail();
				}
			}
		}

		public void Move(double x, double y) {
			if(this.Point1 != null) {
				Line line = (Line)this.Glyph;
				line.X1 += x;
				line.Y1 += y;
				line.X2 += x;
				line.Y2 += y;
				this.Point1.Move(x, y);
				this.Point2.Move(x, y);
			} else {
				Canvas.SetLeft(this.Glyph, Canvas.GetLeft(this.Glyph) + x);
				Canvas.SetTop(this.Glyph, Canvas.GetTop(this.Glyph) + y);
			}
		}

		public void Commit() {
			if(this.Point1 != null) {
				Line line = (Line)this.Glyph;
				Wire wire = (Wire)this.Symbol;
				wire.Point1 = Plotter.GridPoint(new Point(line.X1 - Plotter.PinRadius, line.Y1 - Plotter.PinRadius));
				wire.Point2 = Plotter.GridPoint(new Point(line.X2 - Plotter.PinRadius, line.Y2 - Plotter.PinRadius));
			} else {
				this.Symbol.Point = Plotter.GridPoint(new Point(Canvas.GetLeft(this.Glyph), Canvas.GetTop(this.Glyph)));
			}
		}

		public void Delete() {
			this.Canvas.Children.Remove(this.Glyph);
			if(this.Point1 != null) {
				this.Point1.Delete();
				this.Point1 = null;
				this.Point2.Delete();
				this.Point2 = null;
			}
			this.Glyph = null;
			this.Symbol = null;
		}

		private void Init(CircuitSymbol circuitSymbol) {
			Rectangle rect = new Rectangle();
			rect.Tag = this;
			rect.Width = circuitSymbol.Glyph.Width;
			rect.Height = circuitSymbol.Glyph.Height;
			Canvas.SetLeft(rect, Canvas.GetLeft(circuitSymbol.Glyph));
			Canvas.SetTop(rect, Canvas.GetTop(circuitSymbol.Glyph));
			Canvas.SetZIndex(rect, int.MaxValue - 1);
			this.Canvas.Children.Add(rect);
			this.Glyph = rect;
			rect.Stroke = Plotter.MarkerStroke;
			rect.StrokeThickness = 1;
			rect.Fill = Plotter.MarkerFill;
			rect.ToolTip = circuitSymbol.Circuit.ToolTip;
		}

		private void Init(Wire wire) {
			Line line = new Line();
			line.Tag = this;
			line.Stroke = Plotter.MarkerStroke;
			line.StrokeThickness = 1;
			Canvas.SetZIndex(line, int.MaxValue - 1);
			Point p1 = Plotter.ScreenPoint(wire.Point1);
			p1.Offset(Plotter.PinRadius, Plotter.PinRadius);
			line.X1 = p1.X;
			line.Y1 = p1.Y;
			Point p2 = Plotter.ScreenPoint(wire.Point2);
			p2.Offset(Plotter.PinRadius, Plotter.PinRadius);
			line.X2 = p2.X;
			line.Y2 = p2.Y;
			this.Point1 = new MarkerPoint(this, wire.Point1);
			this.Point2 = new MarkerPoint(this, wire.Point2);
			this.Canvas.Children.Add(line);
			this.Glyph = line;
			line.ToolTip = Resources.ToolTipWire;
		}
	}
}
