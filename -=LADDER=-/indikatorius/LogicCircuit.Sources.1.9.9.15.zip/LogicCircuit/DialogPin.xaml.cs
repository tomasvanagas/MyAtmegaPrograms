﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace LogicCircuit {
	/// <summary>
	/// Interaction logic for DialogPin.xaml
	/// </summary>
	public partial class DialogPin : Window {

		private SettingsWindowLocationCache windowLocation;
		public SettingsWindowLocationCache WindowLocation { get { return this.windowLocation ?? (this.windowLocation = new SettingsWindowLocationCache(this)); } }

		private Pin pin;

		public DialogPin(Pin pin) {
			this.DataContext = this;
			this.pin = pin;
			this.InitializeComponent();
			this.type.Text = this.pin.PinType.ToString();
			this.name.Text = this.pin.Name;
			this.note.Text = this.pin.Note;
			this.side.ItemsSource = Enum.GetNames(typeof(PinSide));
			this.side.SelectedItem = this.pin.PinSide.ToString();
			this.inverted.IsChecked = this.pin.Inverted;
			for(int i = 1; i <= BasePin.MaxBitWidth; i++) {
				this.bitWidth.Items.Add(i);
			}
			this.bitWidth.SelectedItem = this.pin.BitWidth;
		}

		private void ButtonOkClick(object sender, RoutedEventArgs e) {
			Transaction transaction = this.pin.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				this.pin.Rename(this.name.Text.Trim());
				this.pin.Note = this.note.Text.Trim();
				this.pin.PinSide = (PinSide)Enum.Parse(typeof(PinSide), this.side.SelectedItem.ToString());
				this.pin.Inverted = this.inverted.IsChecked.Value;
				this.pin.BitWidth = (int)this.bitWidth.SelectedItem;

				foreach(CircuitSymbol symbol in this.pin.ProjectManager.CircuitSymbolStore.Select(this.pin)) {
					symbol.RefreshGlyph();
				}
				success = true;
			} catch(Exception exception) {
				MainFrame.Report(exception);
			} finally {
				this.pin.ProjectManager.EndTransaction(transaction, success);
			}
			MainFrame mainFrame = this.Owner as MainFrame;
			if(mainFrame != null) {
				mainFrame.CircuitEditor.Refresh();
				if(mainFrame.CircuitEditor.LogicalCircuit == this.pin.Circuit) {
					mainFrame.CircuitEditor.Select(this.pin.ProjectManager.CircuitSymbolStore.Select(this.pin));
				}
			}
			this.Close();
		}
	}
}
