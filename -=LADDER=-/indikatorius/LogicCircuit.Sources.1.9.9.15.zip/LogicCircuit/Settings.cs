﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Xml;

namespace LogicCircuit {
	public class Settings {

		/// <summary>
		/// Returns the name of settings file
		/// </summary>
		/// <returns>Returns the name of settings file</returns>
		public static string FileName {
			get {
				return Path.Combine(
					Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
					@"LogicCircuit\Settings.xml"
				);
			}
		}

		/// <summary>
		/// Gets Current settings
		/// </summary>
		public  static UserSettings User { get; private set; }

		/// <summary>
		/// Gets Session settings. This setting is working during session only.
		/// </summary>
		//public static SessionSettings Session { get; private set; }

		static Settings() {
			Settings.User = new UserSettings();
			//Settings.Session = new SessionSettings();
		}

		protected Store SettingsStore { get; private set; }
		private Store.Table settings;
		private int keyColumn;
		private int valueColumn;

		public bool FirstUse { get; private set; }

		protected Settings(Store store) {
			this.SettingsStore = store;
			this.settings = this.SettingsStore["Settings"];
			this.keyColumn = this.settings.ColumnOrdinal("Key");
			this.valueColumn = this.settings.ColumnOrdinal("Value");
		}

		protected Settings(bool loadData) : this(new Store(Schema.SettingsData)) {
			if(loadData) {
				string file = Settings.FileName;
				this.FirstUse = true;
				try {
					if(File.Exists(file)) {
						XmlDocument xml = new XmlDocument();
						xml.Load(file);
						this.SettingsStore.Load(xml);
						this.FirstUse = false;
					} else {
						this.Save();
					}
				} catch(Exception exception) {
					Tracer.Report("Settigns", exception);
				}
			}
		}

		/// <summary>
		/// Saves current settings to Application.LocalUserAppDataPath Settings.xml file
		/// </summary>
		public void Save() {
			if(this == Settings.User) {
				string file = Settings.FileName;
				if(!File.Exists(file)) {
					string dir = Path.GetDirectoryName(file);
					if(!Directory.Exists(dir)) {
						try {
							Directory.CreateDirectory(dir);
						} catch(Exception exception) {
							Tracer.Report("Settigns.Save", exception);
						}
					}
					StreamWriter writer = null;
					try {
						writer = File.CreateText(file);
					} catch(Exception exception) {
						Tracer.Report("Settigns.Save", exception);
					} finally {
						writer.Close();
					}
				}
				Store.WriteXml(this.SettingsStore.Save(), file, Encoding.UTF8);
			}
		}

		public void Delete(string key) {
			Store.Table.Row row = this.settings.Select(key);
			if(row != null) {
				row.Delete();
			}
		}

		public string this[string key] {
			get {
				Store.Table.Row row = this.settings.Select(key);
				if(row != null) {
					return row[this.valueColumn].ToString().Trim();
				}
				return null;
			}
			set {
				Store.Table.Row row = this.settings.Select(key);
				if(row == null) {
					row = this.settings.NewRow();
					row[this.keyColumn] = key;
					row[this.valueColumn] = value.Trim();
					row.Add();
				} else {
					row[this.valueColumn] = value.Trim();
				}
			}
		}
	}

	public class UserSettings : Settings {
		private Store.Table recentFile;
		private int dateTime;
		private int fileName;

		private SettingsIntegerCache maxRecentFileCount;
		public int MaxRecentFileCount {
			get { return this.maxRecentFileCount.Value; }
			set { this.maxRecentFileCount.Value = value; }
		}

		private SettingsBoolCache loadLastFileOnStartup;
		public bool LoadLastFileOnStartup {
			get { return this.loadLastFileOnStartup.Value; }
			set { this.loadLastFileOnStartup.Value = value; }
		}

		private SettingsBoolCache showGrid;
		public bool ShowGrid {
			get { return this.showGrid.Value; }
			set { this.showGrid.Value = value; }
		}

		private SettingsEnumCache<GateShape> gateShape;
		public GateShape GateShape {
			get { return this.gateShape.Value; }
			set { this.gateShape.Value = value; }
		}

		public UserSettings() : base(true) {
			this.recentFile = this.SettingsStore["RecentFile"];
			this.fileName = this.recentFile.ColumnOrdinal("FileName");
			this.dateTime = this.recentFile.ColumnOrdinal("DateTime");
			this.maxRecentFileCount = new SettingsIntegerCache(this, "Settings.MaxRecentFileCount", 1, 32, 4);
			this.loadLastFileOnStartup = new SettingsBoolCache(this, "Settings.LoadLastFileOnStartup", true);
			this.showGrid = new SettingsBoolCache(this, "Settings.ShowGrid", true);
			this.gateShape = new SettingsEnumCache<GateShape>(this, "Settings.GateShape", GateShape.Rectangular);
		}

		private Store.Table.Row[] RecentFileRow() {
			Store.Table.Row[] row = this.recentFile.Rows();
			Array.Sort<Store.Table.Row>(row, this.recentFile.TableColumn(this.dateTime).Comparer);
			Array.Reverse(row);
			return row;
		}

		private void TruncateRecentFile(int count) {
			if(this.recentFile.Count > count) {
				Store.Table.Row[] row = this.RecentFileRow();
				for(int i = count; i < row.Length; i++) {
					row[i].Delete();
				}
			}
		}

		/// <summary>
		/// Adds the file name to the list of recently opened files.
		/// </summary>
		/// <param name="file">File name to be added</param>
		public void AddRecentFile(string file) {
			file = file.Trim();
			Store.Table.Row row = this.recentFile.Select(file);
			if(row == null) {
				row = this.recentFile.NewRow();
				row[this.fileName] = file;
			}
			row[this.dateTime] = DateTime.UtcNow.ToString("s", DateTimeFormatInfo.InvariantInfo);
			if(row.State == Store.RowState.New) {
				row.Add();
			}
			this.TruncateRecentFile(this.MaxRecentFileCount);
		}

		/// <summary>
		/// Deletes file name from recent file list
		/// </summary>
		/// <param name="file">File name to delete from recent file list</param>
		public void DeleteRecentFile(string file) {
			file = file.Trim();
			Store.Table.Row row = this.recentFile.Select(file);
			if(row != null) {
				row.Delete();
			}
		}

		/// <summary>
		/// Returns array of file names of recently opened files.
		/// </summary>
		/// <param name="maxCount">Maximum number of files to be returned</param>
		/// <returns></returns>
		public string[] RecentFile(int maxCount) {
			Store.Table.Row[] row = this.RecentFileRow();
			string[] name = new string[Math.Min(Math.Max(0, maxCount), row.Length)];
			for(int i = 0; i < name.Length; i++) {
				name[i] = (string)row[i][this.fileName];
			}
			return name;
		}

		public string LastFile {
			get {
				Store.Table.Row[] row = this.RecentFileRow();
				if(row != null && 0 < row.Length) {
					return (string)row[0][this.fileName];
				} else {
					return null;
				}
			}
		}

		public string RecentFolder {
			get {
				try {
					string[] file = this.RecentFile(1);
					if(file.Length > 0 && file[0].Length > 0) {
						string folder = Path.GetDirectoryName(file[0]);
						if(Directory.Exists(folder)) {
							return folder;
						}
					}
				} catch(Exception exception) {
					Tracer.Report("Settings.RecentFolder", exception);
				}
				return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
			}
		}

		/// <summary>
		/// Merges itself with content of settings file
		/// </summary>
		/// <returns>true if data was changed</returns>
		public bool Merge() {
			UserSettings external = new UserSettings();
			Store.Table.Row.Comparer comparer = this.recentFile.TableColumn(this.dateTime).Comparer;
			int version = this.recentFile.Version;
			for(int i = 0; i < external.recentFile.Count; i++) {
				string file = ((string)external.recentFile[i][this.fileName]).Trim();
				string date = ((string)external.recentFile[i][this.dateTime]).Trim();
				Store.Table.Row row = this.recentFile.Select(file);
				if(row == null) {
					row = this.recentFile.NewRow();
					row[this.fileName] = file;
					row[this.dateTime] = date;
					row.Add();
				} else if(comparer.Compare(row, date) < 0) {
					row[this.dateTime] = date;
				}
			}
			this.MaxRecentFileCount = Math.Max(this.MaxRecentFileCount, external.MaxRecentFileCount);
			return version != this.recentFile.Version;
		}
	}

	//public class SessionSettings : Settings {
	//    public SessionSettings() : base(false) {
	//    }
	//}

	internal class SettingsBoolCache {
		private Settings settings;
		private string key;

		private bool cache;
		public bool Value {
			get { return this.cache; }
			set {
				this.cache = value;
				this.settings[this.key] = this.cache.ToString(CultureInfo.InvariantCulture);
			}
		}

		public SettingsBoolCache(
			Settings settings,
			string key,
			bool defaultValue
		) {
			this.settings = settings;
			this.key = key;
			string text = this.settings[this.key];
			if(string.IsNullOrEmpty(text) || !bool.TryParse(text, out this.cache)) {
				this.cache = defaultValue;
			}
		}
	}

	internal class SettingsIntegerCache {
		private Settings settings;
		private string key;
		private int minimum;
		private int maximum;

		private int cache;
		public int Value {
			get { return this.cache; }
			set {
				this.cache = Math.Max(this.minimum, Math.Min(value, this.maximum));
				this.settings[this.key] = this.cache.ToString(CultureInfo.InvariantCulture);
			}
		}

		public SettingsIntegerCache(
			Settings settings,
			string key,
			int minimum,
			int maximum,
			int defaultValue
		) {
			this.settings = settings;
			this.key = key;
			this.minimum = minimum;
			this.maximum = maximum;
			string text = this.settings[this.key];
			if(string.IsNullOrEmpty(text) || !int.TryParse(text, out this.cache)) {
				this.cache = Math.Max(this.minimum, Math.Min(defaultValue, this.maximum));;
			}
		}
	}

	internal class SettingsDoubleCache {
		private Settings settings;
		private string key;
		private double minimum;
		private double maximum;

		private double cache;
		public double Value {
			get { return this.cache; }
			set {
				this.cache = Math.Max(this.minimum, Math.Min(value, this.maximum));
				this.settings[this.key] = this.cache.ToString(CultureInfo.InvariantCulture);
			}
		}

		public SettingsDoubleCache(
			Settings settings,
			string key,
			double minimum,
			double maximum,
			double defaultValue
		) {
			this.settings = settings;
			this.key = key;
			this.minimum = minimum;
			this.maximum = maximum;
			string text = this.settings[this.key];
			if(string.IsNullOrEmpty(text) || !double.TryParse(text, out this.cache)) {
				this.cache = Math.Max(this.minimum, Math.Min(defaultValue, this.maximum));;
			}
		}
	}

	internal class SettingsEnumCache<T> {
		private Settings settings;
		private string key;
		private T defaultValue;

		private T cache;
		public T Value {
			get { return this.cache; }
			set {
				this.cache = Enum.IsDefined(typeof(T), value) ? value : this.defaultValue;
				this.settings[this.key] = this.cache.ToString();
			}
		}

		public SettingsEnumCache(
			Settings settings,
			string key,
			T defaultValue
		) {
			this.settings = settings;
			this.key = key;
			if(!Enum.IsDefined(typeof(T), defaultValue)) {
				defaultValue = (T)Enum.GetValues(typeof(T)).GetValue(0);
			}
			this.defaultValue = defaultValue;
			string text = this.settings[this.key];
			if(!string.IsNullOrEmpty(text)) {
				try {
					this.cache = (T)Enum.Parse(typeof(T), text);
				} catch(ArgumentException) {
					this.cache = this.defaultValue;
				}
			} else {
				this.cache = this.defaultValue;
			}
		}
	}

	internal class SettingsStringCache {
		private Settings settings;
		private string key;
		private string[] constraint;
		private string defaultValue;

		private string cache;
		public string Value {
			get { return this.cache; }
			set {
				this.cache = this.Normalize(value);
				this.settings[this.key] = this.cache;
			}
		}

		public SettingsStringCache(
			Settings settings,
			string key,
			string defaultValue,
			params string[] constraint
		) {
			this.settings = settings;
			this.key = key;
			this.constraint = (constraint == null || constraint.Length == 0) ? null : constraint;
			this.defaultValue = string.Empty;
			this.defaultValue = this.Normalize(defaultValue);
			this.cache = this.Normalize(this.settings[this.key]);
		}

		private string Normalize(string value) {
			string text = string.IsNullOrEmpty(value) ? null : value.Trim();
			if(this.constraint != null) {
				if(Array.IndexOf(this.constraint, text) < 0) {
					text = null;
				}
			}
			return string.IsNullOrEmpty(text) ? this.defaultValue : text;
		}
	}

	public class SettingsWindowLocationCache {
		private SettingsDoubleCache x;
		private SettingsDoubleCache y;
		private SettingsDoubleCache width;
		private SettingsDoubleCache height;
		private SettingsEnumCache<WindowState> state;

		public SettingsWindowLocationCache(Settings settings, string windowName) {
			this.x = new SettingsDoubleCache(settings, windowName + ".X", 0, SystemParameters.VirtualScreenWidth - 30, 0);
			this.y = new SettingsDoubleCache(settings, windowName + ".Y", 0, SystemParameters.VirtualScreenHeight - 30, 0);
			this.width = new SettingsDoubleCache(settings, windowName + ".Width", 0, SystemParameters.VirtualScreenWidth, 0);
			this.height = new SettingsDoubleCache(settings, windowName + ".Height", 0, SystemParameters.VirtualScreenHeight, 0);
			this.state = new SettingsEnumCache<WindowState>(settings, windowName + ".WindowState", WindowState.Normal);
		}

		public SettingsWindowLocationCache(Window window) : this(Settings.User, window.GetType().Name) {
		}

		public double X {
			get { return this.x.Value; }
			set { this.x.Value = value; }
		}

		public double Y {
			get { return this.y.Value; }
			set { this.y.Value = value; }
		}

		public double Width {
			get { return this.width.Value; }
			set { this.width.Value = value; }
		}

		public double Height {
			get { return this.height.Value; }
			set { this.height.Value = value; }
		}

		private WindowState Normalize(WindowState state) {
			switch(state) {
			case WindowState.Normal:
			case WindowState.Maximized:
				return state;
			default:
				return WindowState.Normal;
			}
		}

		public WindowState WindowState {
			get { return this.Normalize(this.state.Value); }
			set { this.state.Value = this.Normalize(value); }
		}
	}
}
