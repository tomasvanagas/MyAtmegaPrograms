//#define DebugTransaction

using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace LogicCircuit {

	/// <summary>
	/// Marker of transactions (undo/redo) operations.
	/// Each undo/redo item must be enclosed in pair of linked sentinels.
	/// But every pair can contain bunch of undo/redo items.
	/// </summary>
	public abstract class Transaction {
		private Transaction open;
		/// <summary>
		/// Gets transaction that starts the batch
		/// </summary>
		public Transaction Open { get { return this.open; } }

		#if DebugTransaction
			private string stackTrace;
		#endif

		/// <summary>
		/// Crates new start transaction's sentinel
		/// </summary>
		protected Transaction() {
			//this.open = null;
			#if DebugTransaction
				this.stackTrace = Environment.StackTrace;
			#endif
		}
		/// <summary>
		/// Creates new end transaction's sentinel. This end sentinel ends batch of undo/redo items started by provided open sentinel
		/// </summary>
		/// <param name="open">Transaction that was open the batch</param>
		protected Transaction(Transaction open) {
			this.open = open;
			#if DebugTransaction
				this.stackTrace = Environment.StackTrace;
			#endif
		}
	}

	/// <summary>
	/// Holds history of all changes made to the store. Can Undo changes surraunded by two sentinels
	/// </summary>
	public class TransactionalStore : Store {
		/// <summary>
		/// Occurs when all edit operatoins have ended and no open transactions remainig.
		/// </summary>
		public event EventHandler EditEnded;

		private Stack undo;
		private Stack redo;
		private Stack log;
		private Stack<Transaction> transactionStack;

		private void Init() {
			this.undo = new Stack(1024);
			this.redo = new Stack(128);
			this.transactionStack = new Stack<Transaction>();
			this.ClearLog();
			foreach(Store.Table table in this) {
				table.TableChanged += new Store.TableChangedEventHandler(this.table_TableChanged);
			}
		}

		public TransactionalStore(XmlDocument schema) : base(schema) {
			this.Init();
		}
		public TransactionalStore(string schemaXmlText) : base(schemaXmlText) {
			this.Init();
		}

		public override void Load(XmlDocument xml) {
			this.BeginTransaction();
			try {
				base.Load(xml);
			} finally {
				this.ClearLog();
			}
		}

		/// <summary>
		/// Clears the buffer.
		/// </summary>
		public void ClearLog() {
			this.undo.Clear();
			this.redo.Clear();
			this.transactionStack.Clear();
			this.log = this.undo;
			this.NotifyEditEnded();
		}

		/// <summary>
		/// Gets true if Undo history contains any items and false otherwise
		/// </summary>
		public bool HasUndo { get { return this.undo.Count > 0; } }
		/// <summary>
		/// Gets true if Redo history contains any items and false otherwise
		/// </summary>
		public bool HasRedo { get { return this.redo.Count > 0; } }

		/// <summary>
		/// Begin edit batch that can be commited or rolled back
		/// </summary>
		/// <returns></returns>
		public Transaction BeginTransaction() {
			Transaction transaction = new TransactionItem();
			this.transactionStack.Push(transaction);
			this.Push(transaction);
			return transaction;
		}
		/// <summary>
		/// Commit transaction.
		/// </summary>
		/// <param name="start"></param>
		public void Commit(Transaction start) {
			if(this.transactionStack.Count <= 0 || start != this.transactionStack.Pop()) {
				this.ClearLog();
				Tracer.Fail(StoreMessage.WrongCommit);
			}
			int count = this.undo.Count;
			this.Push(new TransactionItem(start));
			if(count < this.undo.Count) {
				this.redo.Clear();
			}
			this.NotifyEditEnded();
		}
		/// <summary>
		/// Undoes all changes till start sentinel. Erases undone changes from redo buffer.
		/// </summary>
		/// <param name="start"></param>
		public void Rollback(Transaction start) {
			if(this.transactionStack.Count <= 0 || start != this.transactionStack.Pop()) {
				this.ClearLog();
				Tracer.Fail(StoreMessage.WrongRollback);
			}
			int count = this.undo.Count;
			this.Push(new TransactionItem(start));
			if(count < this.undo.Count) {
				this.log = null;
				try {
					this.Undo(this.undo);
				} finally {
					this.log = this.undo;
					this.NotifyEditEnded();
				}
			}
		}
		/// <summary>
		/// Ends and skip changes started with start sentinel
		/// </summary>
		/// <param name="start"></param>
		public void Omit(Transaction start) {
			if(this.transactionStack.Count <= 0 || start != this.transactionStack.Pop()) {
				this.ClearLog();
				Tracer.Fail(StoreMessage.WrongOmit);
			}
			while(start != this.undo.Pop());
			this.NotifyEditEnded();
		}

		/// <summary>
		/// Undoes top change batch
		/// </summary>
		public void Undo() {
			if(this.transactionStack.Count > 0) {
				this.ClearLog();
				Tracer.Fail(StoreMessage.WrongUndo);
			}
			this.log = this.redo;
			try {
				this.Undo(this.undo);
			} finally {
				this.log = this.undo;
				this.NotifyEditEnded();
			}
		}
		/// <summary>
		/// Redoes previously undone batch.
		/// </summary>
		public void Redo() {
			if(this.transactionStack.Count > 0) {
				this.ClearLog();
				Tracer.Fail(StoreMessage.WrongRedo);
			}
			try {
				this.Undo(this.redo);
			} finally {
				this.NotifyEditEnded();
			}
		}

		/// <summary>
		/// Returns true if any transaction is still not closed.
		/// </summary>
		/// <returns></returns>
		public bool IsTransactionOpen() {
			return this.transactionStack.Count > 0;
		}

		//---------------------------------------------------------------------

		/// <summary>
		/// Fires EditEnded event if all begin operations have ended.
		/// </summary>
		private void NotifyEditEnded() {
			if(this.transactionStack.Count <= 0 && this.EditEnded != null) {
				this.EditEnded(this, EventArgs.Empty);
			}
		}

		/// <summary>
		/// Pushes entry to the current log
		/// </summary>
		/// <param name="value">value to push</param>
		private void Push(object value) {
			if(this.log.Count > 0) {
				Entry entry = value as Entry;
				if(entry != null) {
					Entry top = this.log.Peek() as Entry; //this should be possible because stack is not empty here
					if(top != null && top.Row == entry.Row && top.Action == entry.Action) {
						//Editing the same row, just leave the topmost value
						//it is possible to improove it here by analizing both actions and save more stack space
						//but its may be not worth it because this one is better performer.
						return;
					}
				} else {
					Transaction transaction = value as Transaction;
					if(transaction != null) {
						Transaction top = this.log.Peek() as Transaction; //this should be possible because stack is not empty here
						if(top != null && top == transaction.Open) {
							//Closing an empty sequence
							this.log.Pop();
							return;
						}
					}
				}
			}
			this.log.Push(value);
		}

		/// <summary>
		/// Undoes top batch from specified log.
		/// </summary>
		/// <param name="undoLog">log to undo entries from</param>
		private void Undo(Stack undoLog) {
			try {
				if(undoLog.Count > 0) {
					Transaction start = (Transaction)undoLog.Pop();
					Transaction terminal = start.Open;
					if(this.log != null) {
						this.Push(terminal);
					}
					this.transactionStack.Push(terminal);
					this.Undo(undoLog, terminal);
					if(this.log != null) {
						this.Push(start);
					}
					this.transactionStack.Pop();
				}
			} catch {
				this.ClearLog();
				throw;
			}
		}

		/// <summary>
		/// Undoes all entries from provided log till terminal inclusive.
		/// </summary>
		/// <param name="undoLog"></param>
		/// <param name="terminal"></param>
		private void Undo(Stack undoLog, Transaction terminal) {
			object top = undoLog.Pop();
			while(top != terminal) {
				Entry entry = top as Entry;
				if(entry != null) {
					switch(entry.Action) {
					case Store.RowAction.Added:
						//the row can be already deleted by cascade constraint of previous undo entry
						//Actually... is it possible?
						//try to remove this if
						if(entry.Row.State != Store.RowState.Deleted) {
							entry.Row.Delete();
						}
						break;
					case Store.RowAction.Modified:
						entry.Row.ItemArray = entry.Values;
						break;
					case Store.RowAction.Deleted:
						//entry.Row.ItemArray = entry.Values;
						entry.Row.Add();
						break;
					default:
						break;
					}
				} else {
					Transaction start = (Transaction)top;
					if(this.log != null) {
						this.Push(start.Open);
					}
					this.Undo(undoLog, start.Open);
					if(this.log != null) {
						this.Push(start);
					}
				}
				top = undoLog.Pop();
			}
		}

		private void table_TableChanged(Store.RowAction action, Store.Table.Row row, object[] old) {
			if(this.transactionStack.Count <= 0) {
				Tracer.Fail(StoreMessage.BeginTransactionMissing);
			}
			//Tracer.FullInfo("TransactionalStore.table_TableChanged", "table={0}", row.Table.Name);
			if(this.log != null) {
				this.Push(new Entry(action, row, old));
			}
		}

		//---------------------------------------------------------------------

		private class TransactionItem : Transaction {
			public TransactionItem() : base() {
			}
			public TransactionItem(Transaction open) : base(open) {
			}
		}

		//---------------------------------------------------------------------

		/// <summary>
		/// Keeps all the information about single change action
		/// </summary>
		private class Entry {
			private Store.RowAction action;
			public  Store.RowAction Action { get { return this.action; } }

			private Store.Table.Row row;
			public  Store.Table.Row Row { get { return this.row; } }

			private object[] values;
			public  object[] Values {
				get { return this.values; }
			}

			public Entry(Store.RowAction action, Store.Table.Row row, object[] old) {
				this.action = action;
				this.row = row;
				//it is look like this is redundant
				//if(action != Store.RowAction.Added) {
				//    this.values = (old != null) ? old : row.ItemArray;
				//}
				//so just
				this.values = old;
			}
		}

		//---------------------------------------------------------------------

		#if DEBUG1
			public void Dump(TreeView undoTree, TreeView redoTree) {
				this.Dump(undoTree, this.undo);
				this.Dump(redoTree, this.redo);
			}
			private void Dump(TreeView tree, Stack stack) {
				TreeNode root = new TreeNode(string.Format(Store.DataCulture, "Total depth={0}", stack.Count));
				this.Dump(root, stack.ToArray(), 0, null);
				tree.Nodes.Add(root);
			}
			private int Dump(TreeNode parent, object[] stack, int current, Transaction terminal) {
				while(current < stack.Length) {
					if(stack[current] is Transaction) {
						if(stack[current] != terminal) {
							Transaction transaction = (Transaction)stack[current];
							TreeNode node = new TreeNode(transaction.GetHashCode().ToString(Store.DataCulture));
							parent.Nodes.Add(node);
							current = this.Dump(node, stack, current + 1, transaction.Open);
						} else {
							break;
						}
					} else if(stack[current] is Entry) {
						Entry entry = (Entry)stack[current];
						TreeNode node = new TreeNode(
							string.Format(Store.DataCulture,
								"{0} {1} {2}",
								entry.Action.ToString(),
								entry.Row.Table.Name,
								entry.Row.Dump()
							)
						);
						if(entry.Values != null) {
							node.Tag = entry.Row.Dump(entry.Values);
						}
						parent.Nodes.Add(node);
					} else {
						object o = stack[current];
						TreeNode node = new TreeNode(o == null ? "null" : o.ToString());
						parent.Nodes.Add(node);
					}
					current++;
				}
				return current;
			}
		#endif
	}
}
