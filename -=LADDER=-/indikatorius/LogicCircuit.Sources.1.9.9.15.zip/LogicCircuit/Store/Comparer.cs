using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;

namespace LogicCircuit {
	partial class Store {
		partial class Table {
			partial class Row {
				public static Comparer CreateComparer(Column column) {
					if(column == null) {
						return SequenceComparer.Comparer;
					} else {
						Type type = column.Type;
						if(type == typeof(Guid)) {
							return new GuidComparer(column);
						} else if(type == typeof(int)) {
							return new IntComparer(column);
						} else if(type == typeof(string)) {
							return new StringComparer(column);
						} else if(type == typeof(bool)) {
							return new BoolComparer(column);
						} else if(type == typeof(double)) {
							return new DoubleComparer(column);
						} else {
							Tracer.Fail();
							return null;
						}
					}
				}
				//public static Comparer CreateComparer() {
				//	return Row.CreateComparer(null);
				//}
				public static Comparer RowComparer() {
					return SequenceComparer.Comparer;
				}

				public abstract class Comparer : IComparer<Row> {
					public abstract int Compare(Row x, Row y);
					public abstract int Compare(Row x, object y);
					public abstract int Compare(object x, object y);
				}

				private class SequenceComparer : Comparer {
					public static readonly Comparer Comparer = new SequenceComparer();

					private SequenceComparer() {}

					public override int Compare(Row x, Row y) {
						return x.sequence - y.sequence;
					}
					public override int Compare(Row x, object y) {
						Tracer.Fail();
						return 0;
					}
					public override int Compare(object x, object y) {
						Tracer.Fail();
						return 0;
					}
				}
				private class IntComparer : Comparer {
					private int ordinal;
					public IntComparer(Column column) {
						this.ordinal = column.Ordinal;
					}
					public override int Compare(Row x, Row y) {
						return (int)x[this.ordinal] - (int)y[this.ordinal];
					}
					public override int Compare(Row x, object y) {
						return (int)x[this.ordinal] - (int)y;
					}
					public override int Compare(object x, object y) {
						return (int)x - (int)y;
					}
				}
				private class StringComparer : Comparer {
					private int ordinal;
					public StringComparer(Column column) {
						this.ordinal = column.Ordinal;
					}
					public override int Compare(Row x, Row y) {
						return Store.StringComparer.Compare((string)x[this.ordinal], (string)y[this.ordinal]);
					}
					public override int Compare(Row x, object y) {
						return Store.StringComparer.Compare((string)x[this.ordinal], (string)y);
					}
					public override int Compare(object x, object y) {
						return Store.StringComparer.Compare((string)x, (string)y);
					}
				}
				private class GuidComparer : Comparer {
					private int ordinal;
					public GuidComparer(Column column) {
						this.ordinal = column.Ordinal;
					}
					public override int Compare(Row x, Row y) {
						return ((Guid)x[this.ordinal]).CompareTo((Guid)y[this.ordinal]);
					}
					public override int Compare(Row x, object y) {
						return ((Guid)x[this.ordinal]).CompareTo((Guid)y);
					}
					public override int Compare(object x, object y) {
						return ((Guid)x).CompareTo((Guid)y);
					}
				}
				private class BoolComparer : Comparer {
					private int ordinal;
					public BoolComparer(Column column) {
						this.ordinal = column.Ordinal;
					}
					public override int Compare(Row x, Row y) {
						return (((bool)x[this.ordinal]) ? 1 : 0) - (((bool)y[this.ordinal]) ? 1 : 0);
					}
					public override int Compare(Row x, object y) {
						return (((bool)x[this.ordinal]) ? 1 : 0) - (((bool)y) ? 1 : 0);
					}
					public override int Compare(object x, object y) {
						return (((bool)x) ? 1 : 0) - (((bool)y) ? 1 : 0);
					}
				}
				private class DoubleComparer : Comparer {
					private int ordinal;
					public DoubleComparer(Column column) {
						this.ordinal = column.Ordinal;
					}
					public override int Compare(Row x, Row y) {
						return Math.Sign((double)x[this.ordinal] - (double)y[this.ordinal]);
					}
					public override int Compare(Row x, object y) {
						return Math.Sign((double)x[this.ordinal] - (double)y);
					}
					public override int Compare(object x, object y) {
						return Math.Sign((double)x - (double)y);
					}
				}
			}
		}
	}
}
