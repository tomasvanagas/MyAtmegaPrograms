using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;

namespace LogicCircuit {
	partial class Store {
		partial class Table {
			private class Index {
				private string name;
				public string Name { get { return this.name; } }

				private Column[] column;
				public int ColumnCount { get { return this.column.Length; } }
				public Column Column(int i) {
					return this.column[i];
				}
				public Table Table { get { return this.column[0].Table; } }

				private int ordinal0; //Ordinal number of the first or only column

				private bool unique;
				//public bool Unique { get { return this.unique; } }

				private Row.Comparer rowComparer;

				private Dictionary<object, List<Row>> index;

				public Index(string name, Column column, bool unique) {
					if(!column.Mandatory) {
						this.FailIndexColumnNull(column);
					}
					this.name = name;
					this.column = new Column[] { column };
					this.ordinal0 = column.Ordinal;
					this.unique = unique;
					this.index = new Dictionary<object, List<Row>>();
					this.rowComparer = Row.RowComparer();
				}
				public Index(string name, Column column1, Column column2) {
					if(!column1.Mandatory) {
						this.FailIndexColumnNull(column1);
					}
					if(!column2.Mandatory) {
						this.FailIndexColumnNull(column2);
					}
					Tracer.Assert(column1.Table == column2.Table);
					this.name = name;
					this.column = new Column[] { column1, column2 };
					this.ordinal0 = column1.Ordinal;
					this.unique = true; //All indexes with two columns are unique.
					this.index = new Dictionary<object, List<Row>>();
					this.rowComparer = column2.Comparer;
				}

				private void FailIndexColumnNull(Table.Column column) {
					Tracer.Fail(StoreMessage.IndexColumnNull(column.Name, this.Name));
				}
				private void FailOneColumnIndex() {
					Tracer.Fail(StoreMessage.OneColumnIndex(this.Name));
				}

				public Row[] Find(object value) {
					List<Row> list;
					if(value != null && this.index.TryGetValue(value, out list)) {
						return list.ToArray();
					}
					return null;
				}
				public Row FindUnique(object value) {
					Tracer.Assert(this.unique);
					List<Row> list;
					if(value != null && this.index.TryGetValue(value, out list)) {
						return list[0];
					}
					return null;
				}
				public Row Find(object value1, object value2) {
					if(this.column.Length <= 1) {
						this.FailOneColumnIndex();
					}
					List<Row> list;
					if(value1 != null && this.index.TryGetValue(value1, out list)) {
						int i = Store.BinarySearch(list, value2, this.rowComparer);
						if(i >= 0) {
							return list[i];
						}
					}
					return null;
				}
				public bool Exists(object value) {
					return value != null && this.index.ContainsKey(value);
				}
				public bool Exists(object value1, object value2) {
					if(this.column.Length <= 1) {
						this.FailOneColumnIndex();
					}
					List<Row> list;
					if(value1 != null && this.index.TryGetValue(value1, out list)) {
						return Store.BinarySearch(list, value2, this.rowComparer) >= 0;
					}
					return false;
				}

				public void Add(Row row) {
					object value = row[this.ordinal0];
					List<Row> list = null;
					if(!this.index.TryGetValue(value, out list)) {
						list = new List<Row>();
						this.index.Add(value, list);
					}
					if(list.Count > 0 && this.unique && this.column.Length == 1) {
						throw Store.UniqueViolation(this.Name, this.column, value);
					}
					int i = list.BinarySearch(row, this.rowComparer);
					if(i < 0) {
						list.Insert(~i, row);
					} else if(this.unique) {
						if(this.column.Length > 1) {
							throw Store.UniqueViolation(
								this.Name, this.column, row[this.ordinal0], row[this.column[1].Ordinal]
							);
						} else {
							throw Store.UniqueViolation(this.Name, this.column, row[this.ordinal0]);
						}
					} else {
						Tracer.Fail(StoreMessage.IvalidIndexOperation(this.Name, row.ToString()));
					}
				}

				public void Delete(Row row) {
					object value = row[this.ordinal0];
					List<Row> list = null;
					if(this.index.TryGetValue(value, out list)) {
						int i = list.BinarySearch(row, this.rowComparer);
						if(i >= 0) {
							if(!row.Equals(list[i])) {
								int j = i - 1;
								while(j >= 0 && this.rowComparer.Compare(row, list[j]) == 0 && !row.Equals(list[j])) {
									j--;
								}
								if(j < 0 || !row.Equals(list[j])) {
									j = i + 1;
									while(j < list.Count && this.rowComparer.Compare(row, list[j]) == 0 && !row.Equals(list[j])) {
										j++;
									}
								}
								i = j;
							}
							if(0 <= i && i < list.Count && row.Equals(list[i])) {
								list.RemoveAt(i);
							}
							if(list.Count <= 0) {
								this.index.Remove(value);
							}
						}
					}
				}
			}
		}
	}
}
