using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;

namespace LogicCircuit {
	partial class Store {
		partial class Table {
			/// <summary>
			/// Column of the table
			/// </summary>
			public abstract class Column {
				private Table table;
				/// <summary>
				/// Gets the table this column belongs to
				/// </summary>
				public Table Table { get { return this.table; } }

				private string name;
				/// <summary>
				/// Gets column name
				/// </summary>
				public string Name { get { return this.name; } }

				private string fullName;
				/// <summary>
				/// Get column's full name: {Table Name}.{Column Name}
				/// </summary>
				public string FullName { get { return this.fullName; } }

				private int ordinal;
				/// <summary>
				/// Gets ordinal number of the column
				/// </summary>
				public int Ordinal { get { return this.ordinal; } }

				private bool mandatory;
				/// <summary>
				/// True if column accepts nulls
				/// </summary>
				public bool Mandatory { get { return this.mandatory; } }

				private Type type;
				/// <summary>
				/// Gets data type of column's values
				/// </summary>
				public Type Type { get { return this.type; } }

				private Row.Comparer comparer;
				/// <summary>
				/// Gets comparer of column's values
				/// </summary>
				public Row.Comparer Comparer { get { return this.comparer; } }

				private object defaultValue;
				/// <summary>
				/// Gets or sets default value for column
				/// </summary>
				public object DefaultValue {
					get { return this.defaultValue; }
					set {
						this.Validate(value);
						this.defaultValue = value;
					}
				}

				protected Column(Table table, string name, bool mandatory, Type type) {
					Tracer.Assert(table != null);
					Tracer.Assert(!string.IsNullOrEmpty(name));
					Tracer.Assert(type != null);
					this.table = table;
					this.name = name;
					this.fullName = string.Format(Store.DataCulture, "{0}.{1}", table.Name, name);
					this.ordinal = this.table.ColumnCount;
					this.mandatory = mandatory;
					this.type = type;
					this.comparer = Row.CreateComparer(this);
				}

				/// <summary>
				/// Validates values against column. If value doesn't fit to column throws an exception
				/// </summary>
				/// <param name="value">value to be validated</param>
				/// <returns>value if validation passed</returns>
				public object Validate(object value) {
					if(value != null) {
						Tracer.Assert(this.type == value.GetType());
					} else if(this.mandatory) {
						throw Store.NullViolation(this);
					}
					return value;
				}
			}

			private class ColumnItem : Column {
				public ColumnItem(Table table, string name, bool mandatory, Type type) : base(
					table, name, mandatory, type
				) {
				}
			}
		}
	}
}
