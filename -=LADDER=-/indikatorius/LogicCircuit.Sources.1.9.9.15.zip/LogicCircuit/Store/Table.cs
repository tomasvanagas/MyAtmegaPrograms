using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace LogicCircuit {
	partial class Store {

		/// <summary>
		/// Row action used in TableChanged event
		/// </summary>
		public enum RowAction {
			Added,
			Modified,
			Deleted
		}

		public delegate void TableChangedEventHandler(Store.RowAction action, Store.Table.Row row, object[] old);

		public abstract partial class Table : IEnumerable<Table.Row> {

			private object tag;
			/// <summary>
			/// Any additional data associated with the table
			/// </summary>
			public object Tag {
				get { return this.tag; }
				set { this.tag = value; }
			}

			/// <summary>
			/// Gets or sets flag if the table should be serialiezed and deserialized
			/// </summary>
			public bool Persistent { get; set; }

			/// <summary>
			/// Occurs when table's content is changed
			/// </summary>
			public event TableChangedEventHandler TableChanged;

			private Store store;
			/// <summary>
			/// Gets the store the table belongs to
			/// </summary>
			public Store Store { get { return this.store; } }
			protected void Detach() {
				this.store = null;
			}

			private string name;
			/// <summary>
			/// Gets the table name
			/// </summary>
			public string Name { get { return this.name; } }

			/// <summary>
			/// Gets the ordinal number of the table in the store
			/// </summary>
			public int Ordinal { get { return this.store.table.IndexOf(this); } }

			//-----------------------------------------------------------------

			//Table columns
			private List<Column> column;
			/// <summary>
			/// Gets number of column in the table
			/// </summary>
			public int ColumnCount { get { return this.column.Count; } }
			/// <summary>
			/// Gets column by index
			/// </summary>
			/// <param name="i">Zero based index of column tobe retrieved</param>
			/// <returns>Column</returns>
			public Column TableColumn(int i) {
				return this.column[i];
			}

			private Dictionary<string, Column> columnName;
			/// <summary>
			/// Gets column by name
			/// </summary>
			/// <param name="name">Name of column to be retrieved</param>
			/// <returns>Column</returns>
			public Column TableColumn(string name) {
				return this.columnName[name];
			}
			/// <summary>
			/// Checks if table contains column
			/// </summary>
			/// <param name="name">Name of column to check</param>
			/// <returns>true if table contains the column.</returns>
			public bool HasColumn(string name) {
				return this.columnName.ContainsKey(name);
			}

			/// <summary>
			/// Returns ordinal number of column with specified name
			/// if column with such name doesn't exist in the table throws an Exception
			/// </summary>
			/// <param name="columnName">Name of column</param>
			/// <returns>Ordinal number of column</returns>
			public int ColumnOrdinal(string columnName) {
				Column column = this.TableColumn(columnName);
				return column.Ordinal;
			}

			public Column AddColumn(string name, bool mandatory, Type type) {
				if(this.version > 0 || this.store == null) {
					Tracer.Fail(StoreMessage.TableNotFresh(name, this.Name));
				}
				Column column = new ColumnItem(this, name, mandatory, type);
				this.column.Add(column);
				this.columnName.Add(name, column);
				this.index.Add(null);
				this.depend.Add(null);
				this.parentIndex.Add(null);
				return column;
			}

			private void CheckMyColumn(Column column) {
				if(column.Table != this) {
					Tracer.Fail(StoreMessage.WrongColumn(column.FullName, this.Name));
				}
			}

			//-----------------------------------------------------------------

			//Indexes
			/// <summary>
			/// Holds all indexes of the table.
			/// Position of each index in this list is defined by odrinal number of it's first column.
			/// This means that it is possible to have only one index with any column as it's first column.
			/// </summary>
			private List<Index> index;

			/// <summary>
			/// Holds all indexes that depend on column value so
			/// every time the value of column changed all this indexes will be updated
			/// </summary>
			private List<List<Index>> depend;

			private void AddDependant(int ordinal, Index index) {
				if(this.depend[ordinal] == null) {
					this.depend[ordinal] = new List<Index>();
				}
				this.depend[ordinal].Add(index);
			}
			private void CheckColumnForIndex(Column column, bool firstColumn) {
				this.CheckMyColumn(column);
				if(firstColumn && this.index[column.Ordinal] != null) {
					Tracer.Fail(StoreMessage.DuplicatedIndex(column.FullName, this.index[column.Ordinal].Name));
				}
			}

			private Index CreateIndex(string name, Column column, bool unique) {
				this.CheckColumnForIndex(column, true);
				Index i = new Index(name, column, unique);
				this.store.AddIndex(name, this);
				this.index[column.Ordinal] = i;
				this.AddDependant(column.Ordinal, i);
				return i;
			}
			private Index CreateIndex(string name, Column column1, Column column2) {
				this.CheckColumnForIndex(column1, true);
				this.CheckColumnForIndex(column2, false);
				Index i = new Index(name, column1, column2);
				this.store.AddIndex(name, this);
				this.index[column1.Ordinal] = i;
				this.AddDependant(column1.Ordinal, i);
				this.AddDependant(column2.Ordinal, i);
				return i;
			}

			//-----------------------------------------------------------------

			//Unique constraint
			public void Unique(string name, Column column) {
				this.CreateIndex(name, column, true);
			}
			public void Unique(string name, Column column1, Column column2) {
				this.CreateIndex(name, column1, column2);
			}

			//-----------------------------------------------------------------

			//Primary keys
			/// <summary>
			/// Contains ordinal number of primary key column for tables with one column primary keys
			/// Contains -1 for tables without primary key or with multy columns primary keys
			/// </summary>
			private int firstPKColumnOrdinal;
			/// <summary>
			/// Unique index for the primary key
			/// </summary>
			private Index primaryKey;
			/// <summary>
			/// Gets array of columns of primary key
			/// </summary>
			public Column[] PrimaryKey {
				get {
					Column[] column = new Column[(this.primaryKey != null) ? this.primaryKey.ColumnCount : 0];
					for(int i = 0; i < column.Length; i++) {
						column[i] = this.primaryKey.Column(i);
					}
					return column;
				}
			}

			private void CheckPrimaryKey() {
				if(this.primaryKey != null) {
					Tracer.Fail(StoreMessage.DublicatePrimaryKey(this.Name));
				}
			}
			public void SetPrimaryKey(string name, Column column) {
				this.CheckPrimaryKey();
				this.primaryKey = this.CreateIndex(name, column, true);
				this.firstPKColumnOrdinal = column.Ordinal;
			}
			public void SetPrimaryKey(string name, Column column1, Column column2) {
				this.CheckPrimaryKey();
				this.primaryKey = this.CreateIndex(name, column1, column2);
				//this.firstPKColumnOrdinal = -1; //its already -1
			}

			//-----------------------------------------------------------------

			//Foreign key
			/// <summary>
			/// Contains indexes of child tables to restrict deleting from this table
			/// </summary>
			private List<Index> restrictChild;
			/// <summary>
			/// Contains indexes of child table to delete cascade when deleting from this table
			/// </summary>
			private List<Index> cascadeChild;
			/// <summary>
			/// Each entry holds the index of parent's primary key if correspondent column is a foreign key
			/// and null if not
			/// </summary>
			private List<Index> parentIndex;

			protected void AddReference(string name, Table parent, Column childColumn, bool cascadeDelete) {
				this.CheckMyColumn(childColumn);
				Index parentIndex = parent.primaryKey;
				if(parentIndex == null) {
					Tracer.Fail(StoreMessage.PrimaryKeyMissing(name, parent.Name));
				}
				if(parentIndex.ColumnCount > 1) {
					Tracer.Fail(StoreMessage.PrimaryKeyMulticolumn(name, parent.Name));
				}
				if(parentIndex.Column(0).Type != childColumn.Type) {
					Tracer.Fail(
						StoreMessage.TypeMismatch(name, parentIndex.Column(0).FullName, childColumn.FullName)
					);
				}
				if(this.parentIndex[childColumn.Ordinal] != null) {
					Tracer.Fail(StoreMessage.DublicateForeignKey(
						name, this.parentIndex[childColumn.Ordinal].Name, childColumn.FullName
					));
				}
				Index childIndex = this.index[childColumn.Ordinal];
				if(childIndex == null) {
					childIndex = this.CreateIndex(name, childColumn, false);
				}
				if(cascadeDelete) {
					parent.cascadeChild.Add(childIndex);
				} else {
					parent.restrictChild.Add(childIndex);
				}
				this.parentIndex[childColumn.Ordinal] = parentIndex;
			}
			private void CheckForeignKey(int foreignColumOrdinal, object value) {
				if(value != null) {
					Index index = this.parentIndex[foreignColumOrdinal];
					if(index != null && !index.Exists(value)) {
						throw Store.ForeignKeyViolation(index.Name, this.column[foreignColumOrdinal], value, index.Column(0));
					}
				}
			}
			private void CheckForeignKey(object[] row) {
				int length = this.column.Count;
				for(int i = 0; i < length; i++) {
					this.CheckForeignKey(i, row[i]);
				}
			}
			public void CheckForeignKey() {
				foreach(RowItem row in this.row) {
					this.CheckForeignKey(row.Values);
				}
			}
			private void RestrictChild(List<Index> childIndex, Row row) {
				if(this.firstPKColumnOrdinal >= 0) {
					object pk = row[this.firstPKColumnOrdinal];
					foreach(Index index in childIndex) {
						if(index.Exists(pk)) {
							throw Store.ForeignKeyRestriction(row.Table, index.Table, pk, index.Column(0));
						}
					}
				}
			}
			private void RestrictChild(Row row) {
				this.RestrictChild(this.restrictChild, row);
			}
			private void CascadeChid(Row row) {
				if(this.firstPKColumnOrdinal >= 0) {
					object pk = row[this.firstPKColumnOrdinal];
					foreach(Index index in this.cascadeChild) {
						Row[] child = index.Find(pk);
						if(child != null) {
							for(int i = 0; i < child.Length; i++) {
								child[i].Delete();
							}
						}
					}
				}
			}
			private void TryDelete(Row row) {
				//This can run to stack overflow if cascade is circle between two or more tables
				if(this.firstPKColumnOrdinal >= 0) {
					this.RestrictChild(row);
					object pk = row[this.firstPKColumnOrdinal];
					foreach(Index index in this.cascadeChild) {
						Row[] child = index.Find(pk);
						if(child != null && child.Length > 0) {
							Table table = child[0].Table;
							foreach(Row r in child) {
								table.TryDelete(r);
							}
						}
					}
				}
			}

			//-----------------------------------------------------------------

			//Table rows
			private int version;
			/// <summary>
			/// Gets current version of the table. Each time the table gets modified it's version increasing.
			/// </summary>
			public int Version { get { return this.version; } }

			private List<Row> row;
			/// <summary>
			/// Get number of row in the table
			/// </summary>
			public int Count { get { return this.row.Count; } }
			/// <summary>
			/// Gets the row by zero based index
			/// </summary>
			public Row this[int i] { get { return this.row[i]; } }
			/// <summary>
			/// Creates new row
			/// </summary>
			/// <returns>Row created</returns>
			public Row NewRow() {
				return new RowItem(this);
			}

			public IEnumerator<Table.Row> GetEnumerator() {
				return this.row.GetEnumerator();
			}
			System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() {
				return this.row.GetEnumerator();
			}

			/// <summary>
			/// Gets array of all rows in the table
			/// </summary>
			/// <returns></returns>
			public Row[] Rows() {
				return this.row.ToArray();
			}

			private void AddAllIndex(Row row) {
				try {
					foreach(Index index in this.index) {
						if(index != null) {
							index.Add(row);
						}
					}
				} catch(Exception exception) {
					Tracer.Report("Store.Table.AddAllIndex", exception);
					this.DeleteAllIndex(row);
					throw;
				}
			}
			private void DeleteAllIndex(Row row) {
				foreach(Index index in this.index) {
					if(index != null) {
						index.Delete(row);
					}
				}
			}

			//-----------------------------------------------------------------

			protected Table(Store store, string name) {
				//this.version = 0;
				this.store = store;
				this.name = name;
				this.column = new List<Column>();
				this.columnName = new Dictionary<string, Column>();
				this.row = new List<Row>();
				this.index = new List<Index>();
				this.depend = new List<List<Index>>();
				//this.primaryKey = null;
				this.firstPKColumnOrdinal = -1;
				this.restrictChild = new List<Index>();
				this.cascadeChild = new List<Index>();
				this.parentIndex = new List<Index>();
			}

			//-----------------------------------------------------------------

			public void Sort(Row.Comparer comparer) {
				this.row.Sort(comparer);
			}
			protected internal void SortByRowOrder() {
				this.Sort(Row.RowComparer());
			}

			//-----------------------------------------------------------------

			/// <summary>
			/// Perform search over the table and retrieves all rows where values of specified column
			/// are equal to specified value
			/// </summary>
			/// <param name="searchColumn">Index of column to perform search against from</param>
			/// <param name="value">Value to test</param>
			/// <param name="sortColumn">Index of column to sort result by. If negative sort is ommited.</param>
			/// <returns>Array of rows where value of searchColumn is equal to specified value</returns>
			public Row[] Select(int searchColumn, object value, int sortColumn) {
				Index index = this.index[searchColumn];
				Row[] row;
				if(index != null) {
					row = index.Find(value);
					if(index.ColumnCount == 2 && index.Column(1).Ordinal == sortColumn) {
						return row;
					}
				} else {
					List<Row> list = new List<Row>();
					Row.Comparer comparer = this.column[searchColumn].Comparer;
					foreach(Row r in this.row) {
						if(comparer.Compare(r, value) == 0) {
							list.Add(r);
						}
					}
					if(list.Count > 0) {
						row = list.ToArray();
					} else {
						return null;
					}
				}
				if(sortColumn >= 0 && row != null) {
					Array.Sort<Row>(row, this.column[sortColumn].Comparer);
				}
				return row;
			}

			/// <summary>
			/// Perform search over the table and retrieves all rows where values of specified column
			/// are equal to specified value
			/// </summary>
			/// <param name="searchColumn">Index of column to perform search against from</param>
			/// <param name="value">Value to test</param>
			/// <returns>Array of rows where value of searchColumn is equal to specified value</returns>
			public Row[] Select(int searchColumn, object value) {
				return this.Select(searchColumn, value, -1);
			}

			private Row[] Select(Index index, object value1, int extraColumn, object value2) {
				if(index.ColumnCount == 2 && index.Column(1).Ordinal == extraColumn) {
					Row row = index.Find(value1, value2);
					if(row != null) {
						return new Row[] { row };
					}
				} else {
					Row[] primary = index.Find(value1);
					if(primary != null) {
						List<Row> list = new List<Row>();
						Row.Comparer comparer = this.column[extraColumn].Comparer;
						foreach(Row row in primary) {
							if(comparer.Compare(row, value2) == 0) {
								list.Add(row);
							}
						}
						if(list.Count > 0) {
							return list.ToArray();
						}
					}
				}
				return null;
			}

			/// <summary>
			/// Perform search over the table and retrieves all rows where values of specified columns
			/// are equal to specified values
			/// </summary>
			/// <param name="searchColumn1">Index of the first column to perform search against from</param>
			/// <param name="value1">Value to test in the first column</param>
			/// <param name="searchColumn2">Index of the second column to perform search against from</param>
			/// <param name="value2">Value to test in the second column</param>
			/// <param name="sortColumn">Index of column to sort result by. If negative sort is ommited.</param>
			/// <returns>Array of rows where value of searchColumn1 == value1 && searchColumn2 == value2</returns>
			public Row[] Select(int searchColumn1, object value1, int searchColumn2, object value2, int sortColumn) {
				Row[] row = null;
				Index index1 = this.index[searchColumn1];
				Index index2 = this.index[searchColumn2];
				if(index1 != null && index2 != null) {
					if(index1.ColumnCount == 2 && index1.Column(1).Ordinal == searchColumn2) {
						Row r = index1.Find(value1, value2);
						if(r != null) {
							return new Row[] { r };
						}
					} else if(index2.ColumnCount == 2 && index2.Column(1).Ordinal == searchColumn1) {
						Row r = index2.Find(value2, value1);
						if(r != null) {
							return new Row[] { r };
						}
					} else {
						row = Store.Intersect(index1.Find(value1), index2.Find(value2));
					}
				} else if(index1 != null) {
					row = this.Select(index1, value1, searchColumn2, value2);
				} else if(index2 != null) {
					row = this.Select(index2, value2, searchColumn1, value1);
				} else {
					List<Row> list = new List<Row>();
					Row.Comparer comparer1 = this.column[searchColumn1].Comparer;
					Row.Comparer comparer2 = this.column[searchColumn2].Comparer;
					foreach(Row r in this.row) {
						if(comparer1.Compare(r, value1) == 0 && comparer2.Compare(r, value2) == 0) {
							list.Add(r);
						}
					}
					if(list.Count > 0) {
						row = list.ToArray();
					}
				}
				if(sortColumn >= 0 && row != null) {
					Array.Sort<Row>(row, this.column[sortColumn].Comparer);
				}
				return row;
			}

			/// <summary>
			/// Perform search over the table and retrieves all rows where values of specified columns
			/// are equal to specified values
			/// </summary>
			/// <param name="searchColumn1">Index of the first column to perform search against from</param>
			/// <param name="value1">Value to test in the first column</param>
			/// <param name="searchColumn2">Index of the second column to perform search against from</param>
			/// <param name="value2">Value to test in the second column</param>
			/// <returns>Array of rows where value of searchColumn1 == value1 && searchColumn2 == value2</returns>
			public Row[] Select(int searchColumn1, object value1, int searchColumn2, object value2) {
				return this.Select(searchColumn1, value1, searchColumn2, value2, -1);
			}

			/// <summary>
			/// Perform search over the table and retrieves all rows where values of specified columns
			/// are equal to specified values
			/// </summary>
			/// <param name="searchColumn1">Index of the first column to perform search against from</param>
			/// <param name="value1">Value to test in the first column</param>
			/// <param name="searchColumn2">Index of the second column to perform search against from</param>
			/// <param name="value2">Value to test in the second column</param>
			/// <param name="sortColumn">Index of column to sort result by. If negative sort is ommited.</param>
			/// <returns>Array of rows where value of searchColumn1 == value1 || searchColumn2 == value2</returns>
			public Row[] SelectOr(int searchColumn1, object value1, int searchColumn2, object value2, int sortColumn) {
				Row[] row = Store.Union(this.Select(searchColumn1, value1), this.Select(searchColumn2, value2));
				if(sortColumn >= 0 && row != null) {
					Array.Sort<Row>(row, this.column[sortColumn].Comparer);
				}
				return row;
			}

			/// <summary>
			/// Perform search over the table and retrieves all rows where values of specified columns
			/// are equal to specified values
			/// </summary>
			/// <param name="searchColumn1">Index of the first column to perform search against from</param>
			/// <param name="value1">Value to test in the first column</param>
			/// <param name="searchColumn2">Index of the second column to perform search against from</param>
			/// <param name="value2">Value to test in the second column</param>
			/// <returns>Array of rows where value of searchColumn1 == value1 || searchColumn2 == value2</returns>
			public Row[] SelectOr(int searchColumn1, object value1, int searchColumn2, object value2) {
				return SelectOr(searchColumn1, value1, searchColumn2, value2, -1);
			}

			/// <summary>
			/// Checks if the row where value of column == value exists
			/// </summary>
			/// <param name="column">Index of the column to perform search against from</param>
			/// <param name="value">Value to test</param>
			/// <returns>True if exists</returns>
			public bool Exists(int column, object value) {
				Index index = this.index[column];
				if(index != null) {
					return index.Exists(value);
				} else {
					Row.Comparer comparer = this.column[column].Comparer;
					foreach(Row row in this.row) {
						if(comparer.Compare(row, value) == 0) {
							return true;
						}
					}
					return false;
				}
			}

			/// <summary>
			/// Checks if the row where value of column1 == value1 and value of column2 == value2 exists
			/// </summary>
			/// <param name="column1">Index of the first column to perform search against from</param>
			/// <param name="value1">The first value to test</param>
			/// <param name="column2">Index of the second column to perform search against from</param>
			/// <param name="value2">The second value to test</param>
			/// <returns>True if exists</returns>
			public bool Exists(int column1, object value1, int column2, object value2) {
				//!!!!!!!!!!!!Revisit for more clear code!!!!!!!!!!!
				Row[] row = null;
				Index index1 = this.index[column1];
				Index index2 = this.index[column2];
				if(index1 != null && index2 != null) {
					if(index1.ColumnCount == 2 && index1.Column(1).Ordinal == column2) {
						return index1.Exists(value1, value2);
					} else if(index2.ColumnCount == 2 && index2.Column(1).Ordinal == column1) {
						return index2.Exists(value2, value1);
					} else {
						row = Store.Intersect(index1.Find(value1), index2.Find(value2));
					}
				} else if(index1 != null) {
					row = this.Select(index1, value1, column2, value2);
				} else if(index2 != null) {
					row = this.Select(index2, value2, column1, value1);
				} else {
					Row.Comparer comparer1 = this.column[column1].Comparer;
					Row.Comparer comparer2 = this.column[column2].Comparer;
					foreach(Row r in this.row) {
						if(comparer1.Compare(r, value1) == 0 && comparer2.Compare(r, value2) == 0) {
							return true;
						}
					}
				}
				return (row != null) && row.Length > 0;
			}

			/// <summary>
			/// Perform selection based on primary key
			/// </summary>
			/// <param name="value">value to be searching</param>
			/// <returns>row with primary key equals to value</returns>
			public Row Select(object value) {
				Tracer.Assert(this.primaryKey != null && this.primaryKey.ColumnCount == 1);
				Tracer.Assert(value != null && value.GetType() == this.primaryKey.Column(0).Type);
				Row[] row = this.primaryKey.Find(value);
				if(row != null && row.Length > 0) {
					Tracer.Assert(row.Length == 1);
					return row[0];
				}
				return null;
			}

			/// <summary>
			/// Perform search based on primary key
			/// </summary>
			/// <param name="value1">value in the first column of the primary key</param>
			/// <param name="value2">value in the second column of the primary key</param>
			/// <returns>Row that sutisfy condition</returns>
			public Row Select(object value1, object value2) {
				Tracer.Assert(this.primaryKey != null && this.primaryKey.ColumnCount == 2);
				Tracer.Assert(value1 != null && value1.GetType() == this.primaryKey.Column(0).Type);
				Tracer.Assert(value2 != null && value2.GetType() == this.primaryKey.Column(1).Type);
				return this.primaryKey.Find(value1, value2);
			}

			/// <summary>
			/// Perform search over the table base on list of column names provided and regular expression.
			/// So the is selected if string representation of the value in the field match to regex.
			/// </summary>
			/// <param name="regex"></param>
			/// <param name="columnName"></param>
			/// <returns></returns>
			public Row[] Select(Regex regex, params string[] columnName) {
				if(this.row.Count > 0) {
					List<int> column = new List<int>();
					foreach(string name in columnName) {
						if(this.HasColumn(name)) {
							column.Add(this.columnName[name].Ordinal);
						}
					}
					if(column.Count > 0) {
						List<Row> list = new List<Row>();
						foreach(Row row in this.row) {
							foreach(int c in column) {
								if(row[c] != null && regex.IsMatch(row[c].ToString())) {
									list.Add(row);
									break;
								}
							}
						}
						if(list.Count > 0) {
							return list.ToArray();
						}
					}
				}
				return null;
			}

			public Row Copy(Row source) {
				if(this.store.NameSpaceUri != source.Table.Store.NameSpaceUri) {
					throw Store.IncompatibleNamespace(this.store.NameSpaceUri, source.Table.Store.NameSpaceUri);
				}
				if(this.Ordinal != source.Table.Ordinal) {
					Tracer.Fail(StoreMessage.BadRowForCopy(source.ToString(), source.Table.Name, this.Name));
				}
				Column[] pk = this.PrimaryKey;
				Row row = null;
				switch(pk.Length) {
				case 1:
					{
						Row[] list = this.index[pk[0].Ordinal].Find(source[pk[0].Ordinal]);
						if(list != null && list.Length > 0) {
							Tracer.Assert(list.Length == 1);
							row = list[0];
						}
					}
					break;
				case 2:
					row = this.index[pk[0].Ordinal].Find(source[pk[0].Ordinal], source[pk[1].Ordinal]);
					break;
				case 0:
					break;
				default:
					Tracer.Fail();
					break;
				}
				if(row == null) {
					row = this.NewRow();
					row.ItemArray = source.ItemArray;
					row.Add();
				}
				return row;
			}

			public void DeleteAllRows() {
				while(this.Count > 0) {
					this[this.Count - 1].Delete();
				}
			}
		}

		private class TableItem : Table {
			public TableItem(Store store, string name) : base(store, name) {
			}
			public new void Detach() {
				base.Detach();
			}
			public new void AddReference(string name, Table parent, Column childColumn, bool cascadeDelete) {
				base.AddReference(name, parent, childColumn, cascadeDelete);
			}
			public new void SortByRowOrder() {
			    base.SortByRowOrder();
			}
		}
	}
}
