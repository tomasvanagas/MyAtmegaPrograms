using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace LogicCircuit {
	partial class Store {
		private class SchemaParser {

			private Store store;
			public SchemaParser(Store store) {
				this.store = store;
			}

			private static Type ParseType(string typeName) {
				Type type = Type.GetType(typeName);
				if(	type != typeof(Guid) &&
					type != typeof(string) &&
					type != typeof(int) &&
					type != typeof(double) &&
					type != typeof(bool)
				) {
					Store.FailUnsupportedType(typeName);
				}
				return type;
			}

			private static string Name(XmlNode node) {
				return node.Attributes["name"].Value;
			}
			private static bool Flag(XmlNode node, string flagName, bool defaultValue) {
				XmlAttribute xmlAttribute = node.Attributes[flagName];
				if(xmlAttribute != null) {
					return bool.Parse(xmlAttribute.Value);
				}
				return defaultValue;
			}
			private static bool WithOriginal(XmlNode node, bool defaultValue) {
				return SchemaParser.Flag(node, "withOriginal", defaultValue);
			}
			private static bool Mandatory(XmlNode node, bool defaultValue) {
				return SchemaParser.Flag(node, "mandatory", defaultValue);
			}
			private static bool Persistent(XmlNode node, bool defaultValue) {
				return SchemaParser.Flag(node, "persistent", defaultValue);
			}

			[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
			public void CreateSchema(XmlDocument schema) {
				if(schema == null) {
					this.store.name = "EmptyStore";
					this.store.nameSpaceUri = "http://LogicCircuit.net/EmptyStore.xsd";
					this.store.prefix = "tbd";
				} else {
					XmlNamespaceManager nsmgr = new XmlNamespaceManager(schema.NameTable);
					nsmgr.AddNamespace("lcp", "http://LogicCircuit.net/MetaModel/Model.xml");
					this.store.name = SchemaParser.Name(schema.DocumentElement);
					Tracer.Assert(this.store.name != null && this.store.name.Length > 0);
					this.store.nameSpaceUri = schema.DocumentElement.GetAttribute("targetNamespace");
					Tracer.Assert(this.store.nameSpaceUri != null && this.store.nameSpaceUri.Length > 0);
					this.store.prefix = schema.DocumentElement.GetAttribute("prefix");
					Tracer.Assert(this.store.prefix != null && this.store.prefix.Length > 0);
					bool storeWithOriginal = SchemaParser.WithOriginal(schema.DocumentElement, false);
					bool storeMandatory = SchemaParser.Mandatory(schema.DocumentElement, false);

					List<Store.Table.Column> keyMember = new List<Store.Table.Column>();
					XmlNodeList tableList = schema.DocumentElement.SelectNodes("lcp:Table", nsmgr);
					foreach(XmlNode tableNode in tableList) {
						bool tableWithOriginal = SchemaParser.WithOriginal(tableNode, storeWithOriginal);
						bool tableMandatory = SchemaParser.Mandatory(tableNode, storeMandatory);
						Store.Table table = this.store.CreateTable(SchemaParser.Name(tableNode));
						table.Persistent = SchemaParser.Persistent(tableNode, true);
						XmlNodeList attributeList = tableNode.SelectNodes("lcp:Column", nsmgr);
						foreach(XmlNode attribute in attributeList) {
							Table.Column column = table.AddColumn(
								SchemaParser.Name(attribute),
								SchemaParser.Mandatory(attribute, tableMandatory),
								SchemaParser.ParseType(attribute.Attributes["type"].Value)
							);
							XmlAttribute nodeDefault = attribute.Attributes["default"];
							if(nodeDefault != null) {
								column.DefaultValue = Store.ParseValue(column, nodeDefault.Value);
							}
						}
						foreach(XmlNode attribute in attributeList) {
							if(SchemaParser.WithOriginal(attribute, tableWithOriginal)) {
								table.AddColumn(
									"Original" + SchemaParser.Name(attribute), false, typeof(string)
								);
							}
						}
						foreach(XmlNode keyNode in tableNode.SelectNodes("lcp:Key", nsmgr)) {
							string keyType = keyNode.Attributes["type"].Value;
							if(keyType == "primary" || keyType == "unique") {
								keyMember.Clear();
								foreach(XmlNode member in keyNode.SelectNodes("lcp:Column", nsmgr)) {
									keyMember.Add(table.TableColumn(SchemaParser.Name(member)));
								}
								Tracer.Assert(1 <= keyMember.Count && keyMember.Count <= 2);
								bool primary = (keyType == "primary");
								string name;
								XmlAttribute xmlName = keyNode.Attributes["name"];
								if(xmlName != null) {
									name = xmlName.Value;
								} else {
									if(primary) {
										name = "PK_" + table.Name;
									} else {
										name = "UK_" + table.Name + keyMember[0].Name;
										if(keyMember.Count > 1) {
											name += keyMember[1].Name;
										}
									}
								}
								if(primary) {
									if(keyMember.Count == 1) {
										table.SetPrimaryKey(name, keyMember[0]);
									} else {
										table.SetPrimaryKey(name, keyMember[0], keyMember[1]);
									}
								} else {
									if(keyMember.Count == 1) {
										table.Unique(name, keyMember[0]);
									} else {
										table.Unique(name, keyMember[0], keyMember[1]);
									}
								}
							}
						}
					}
					foreach(XmlNode tableNode in tableList) {
						TableItem table = (TableItem)this.store[SchemaParser.Name(tableNode)];
						foreach(XmlNode keyNode in tableNode.SelectNodes("lcp:Key", nsmgr)) {
							if(keyNode.Attributes["type"].Value == "foreign") {
								Store.Table parent = this.store[keyNode.Attributes["parent"].Value];
								bool cascade = (Store.StringComparer.Compare(keyNode.Attributes["cascade"].Value, "true") == 0);
								XmlNodeList list = keyNode.SelectNodes("lcp:Column", nsmgr);
								Tracer.Assert(list.Count == 1);
								Store.Table.Column column = table.TableColumn(SchemaParser.Name(list[0]));
								string name;
								XmlAttribute xmlName = keyNode.Attributes["name"];
								if(xmlName != null) {
									name = xmlName.Value;
								} else {
									name = "FK_" + parent.Name + "_" + table.Name;
								}
								table.AddReference(name, parent, column, cascade);
							}
						}
					}
				}
			}
		}
	}
}
