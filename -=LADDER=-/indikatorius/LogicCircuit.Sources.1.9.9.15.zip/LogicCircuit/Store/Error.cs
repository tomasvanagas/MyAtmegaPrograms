using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;

namespace LogicCircuit {
	partial class Store {
		public class Error : CircuitException {
			private Store.Table.Column column;
			public Store.Table.Column Column { get { return this.column; } }

			private Store.Table.Column column2;
			public Store.Table.Column Column2 { get { return this.column2; } }

			public Error(Cause cause, string message) : base(cause, message) { }
			public Error(Cause cause, Store.Table.Column column, string message) : base(cause, message) {
			    this.column = column;
			}
			public Error(
			    Cause cause, Store.Table.Column column, Store.Table.Column column2, string message
			) : base(cause, message) {
			    this.column = column;
			    this.column2 = column2;
			}

			//public static string Format(string format, params object[] args) {
			//	return string.Format(StoreMessage.Culture, format, args);
			//}
		}

		private static Error NullViolation(Table.Column column) {
			return new Error(
				Cause.NullViolation, column, StoreMessage.NullViolation(column.FullName)
			);
		}
		private static Error UniqueViolation(string indexName, Table.Column[] column, params object[] value) {
			if(column.Length == 1) {
				return new Error(Cause.UniqueViolation, column[0],
					StoreMessage.UniqueViolation1(
						indexName,
						column[0].FullName,
						(value != null && value.Length > 0) ? value[0] : string.Empty
					)
				);
			} else {
				return new Error(Cause.UniqueViolation, column[0], column[1],
					StoreMessage.UniqueViolation2(
						indexName, column[0].FullName, column[1].FullName,
						(value != null && value.Length > 0) ? value[0] : string.Empty,
						(value != null && value.Length > 1) ? value[1] : string.Empty
					)
				);
			}
		}
		private static Error ForeignKeyViolation(string indexName,
			Table.Column childColumn, object value, Table.Column parentColumn
		) {
			return new Error(Cause.ForeignKeyViolation, childColumn, parentColumn,
				StoreMessage.ForeignKeyViolation(
					indexName, value, childColumn.FullName, parentColumn.FullName
				)
			);
		}
		private static Error ForeignKeyRestriction(
			Table parentTable, Table childTable, object value, Table.Column childColumn
		) {
			return new Error(Cause.ForeignKeyViolation, childColumn,
				StoreMessage.ForeignKeyRestriction(
					parentTable.Name, childTable.Name, value, childColumn.Name
				)
			);
		}

		private static Error IncompatibleNamespace(string expectedNamespace, string actualNamespace) {
			return new Error(Cause.IncompatibleNamespace,
				StoreMessage.IncompatibleNamespace(expectedNamespace, actualNamespace)
			);
		}
	}
}
