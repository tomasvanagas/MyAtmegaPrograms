using System;
using System.Collections.Generic;
using System.Text;

namespace LogicCircuit {
	partial class Store {
		public abstract class View {
			private Table table;
			/// <summary>
			/// Gets the table of the view
			/// </summary>
			public  Table Table { get { return this.table; } }

			private int searchColumn1;
			private object val1;
			private bool and;
			private int searchColumn2;
			private object val2;
			private int sortColumn;

			public Table.Row[] Select() {
				if(this.searchColumn2 >= 0) {
					if(this.and) {
						return this.table.Select(
							this.searchColumn1, this.val1, this.searchColumn2, this.val2, this.sortColumn
						);
					} else {
						return this.table.SelectOr(
							this.searchColumn1, this.val1, this.searchColumn2, this.val2, this.sortColumn
						);
					}
				} else {
					return this.table.Select(this.searchColumn1, this.val1, this.sortColumn);
				}
			}

			protected View(
				Table table,
				int searchColumn1,
				object searchValue1,
				bool and,
				int searchColumn2,
				object searchValue2,
				int sortColumn
			) {
				this.table = table;
				this.searchColumn1 = searchColumn1;
				this.val1 = searchValue1;
				this.and = and;
				this.searchColumn2 = searchColumn2;
				this.val2 = searchValue2;
				this.sortColumn = sortColumn;
			}
		}

		private class ViewItem : View {
			public ViewItem(
				Table table,
				int searchColumn1,
				object searchValue1,
				bool and,
				int searchColumn2,
				object searchValue2,
				int sortColumn
			) : base(table, searchColumn1, searchValue1, and, searchColumn2, searchValue2, sortColumn) {
			}
		}

		partial class Table {
			//View
			public View CreateView(Column column, object value) {
				this.CheckMyColumn(column);
				column.Validate(value);
				return new ViewItem(this, column.Ordinal, value, true, -1, null, -1);
			}
			public View CreateView(Column column, object value, Column sortColumn) {
				this.CheckMyColumn(column);
				column.Validate(value);
				this.CheckMyColumn(sortColumn);
				return new ViewItem(this, column.Ordinal, value, true, -1, null, sortColumn.Ordinal);
			}
			public View CreateView(Column column1, object value1, Column column2, object value2, Column sortColumn) {
				this.CheckMyColumn(column1);
				column1.Validate(value1);
				this.CheckMyColumn(column2);
				column2.Validate(value2);
				this.CheckMyColumn(sortColumn);
				return new ViewItem(this, column1.Ordinal, value1, true, column2.Ordinal, value2, sortColumn.Ordinal);
			}
			public View CreateOrView(Column column1, object value1, Column column2, object value2, Column sortColumn) {
				this.CheckMyColumn(column1);
				column1.Validate(value1);
				this.CheckMyColumn(column2);
				column2.Validate(value2);
				this.CheckMyColumn(sortColumn);
				return new ViewItem(this, column1.Ordinal, value1, false, column2.Ordinal, value2, sortColumn.Ordinal);
			}
			public View CreateView(Column column1, object value1, Column column2, object value2) {
				this.CheckMyColumn(column1);
				column1.Validate(value1);
				this.CheckMyColumn(column2);
				column2.Validate(value2);
				return new ViewItem(this, column1.Ordinal, value1, true, column2.Ordinal, value2, -1);
			}
			public View CreateOrView(Column column1, object value1, Column column2, object value2) {
				this.CheckMyColumn(column1);
				column1.Validate(value1);
				this.CheckMyColumn(column2);
				column2.Validate(value2);
				return new ViewItem(this, column1.Ordinal, value1, false, column2.Ordinal, value2, -1);
			}
		}
	}
}
