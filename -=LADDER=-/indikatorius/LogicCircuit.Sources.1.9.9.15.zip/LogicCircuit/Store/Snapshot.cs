using System;
using System.Collections.Generic;
using System.Text;

namespace LogicCircuit {
	partial class Store {
		/// <summary>
		/// Cached select. In order to release cache call Release() function.
		/// </summary>
		public abstract class Snapshot {
			private static readonly Table.Row[] empty = new Table.Row[0];
			private View view;
			/// <summary>
			/// Gets the table of the view
			/// </summary>
			public Table Table { get { return this.view.Table; } }

			private Table.Row[] row;
			/// <summary>
			/// Releases the cache
			/// </summary>
			public void Release() {
				this.row = null;
			}
			/// <summary>
			/// Gets the row set of the snapshot
			/// </summary>
			public Table.Row[] Row {
				get {
					if(this.row == null) {
						this.row = this.view.Select();
						if(this.row == null) {
							this.row = Snapshot.empty;
						}
					}
					return this.row;
				}
			}
			protected Snapshot(View view) {
				this.view = view;
				//this.row = null; //this is done by runtime
			}
		}

		private class SnapshotItem : Snapshot {
			public SnapshotItem(View view) : base(view) {
			}
		}

		partial class Table {
			/// <summary>
			/// Creates Snapshot with unsorted rows based on select from the table with specified column
			/// value is equal to specified value
			/// </summary>
			/// <param name="column">Column to use as restriction</param>
			/// <param name="value">Value to be used as restriction</param>
			/// <returns>Snapshot created</returns>
			public Snapshot CreateSnapshot(Column column, object value) {
				return new SnapshotItem(this.CreateView(column, value));
			}
			/// <summary>
			/// Creates Snapshot based on select from specified column with specified sort order
			/// </summary>
			/// <param name="column">Column to use as restriction</param>
			/// <param name="value">Value to be used as restriction</param>
			/// <param name="sortColumn">Column to use in sort</param>
			/// <returns>Created Snapshot</returns>
			public Snapshot CreateSnapshot(Column column, object value, Column sortColumn) {
				return new SnapshotItem(this.CreateView(column, value, sortColumn));
			}
			/// <summary>
			/// Creates Snapshot based on select from the table with two specified columns and sorting column
			/// </summary>
			/// <param name="column1">Column 1 to use as restriction</param>
			/// <param name="value1">Value 1 to be used as restriction</param>
			/// <param name="column2">Column 2 to use as restriction</param>
			/// <param name="value2">Value 1 to be used as restriction</param>
			/// <param name="sortColumn">Column to use in sort</param>
			/// <returns>Created Snapshot</returns>
			public Snapshot CreateSnapshot(Column column1, object value1, Column column2, object value2, Column sortColumn) {
				return new SnapshotItem(this.CreateView(column1, value1, column2, value2, sortColumn));
			}
			/// <summary>
			/// Creates OR Snapshot based on select from the table with two specified columns and sorting column
			/// </summary>
			/// <param name="column1">Column 1 to use as restriction</param>
			/// <param name="value1">Value 1 to be used as restriction</param>
			/// <param name="column2">Column 2 to use as restriction</param>
			/// <param name="value2">Value 1 to be used as restriction</param>
			/// <param name="sortColumn">Column to use in sort</param>
			/// <returns>Created Snapshot</returns>
			public Snapshot CreateOrSnapshot(Column column1, object value1, Column column2, object value2, Column sortColumn) {
				return new SnapshotItem(this.CreateOrView(column1, value1, column2, value2, sortColumn));
			}
			/// <summary>
			/// Creates unsorted Snapshot based on select from the table with two specified columns
			/// </summary>
			/// <param name="column1">Column 1 to use as restriction</param>
			/// <param name="value1">Value 1 to be used as restriction</param>
			/// <param name="column2">Column 2 to use as restriction</param>
			/// <param name="value2">Value 1 to be used as restriction</param>
			/// <returns>Created Snapshot</returns>
			public Snapshot CreateSnapshot(Column column1, object value1, Column column2, object value2) {
				return new SnapshotItem(this.CreateView(column1, value1, column2, value2));
			}
			/// <summary>
			/// Creates OR Snapshot based on select from the table with two specified columns
			/// </summary>
			/// <param name="column1">Column 1 to use as restriction</param>
			/// <param name="value1">Value 1 to be used as restriction</param>
			/// <param name="column2">Column 2 to use as restriction</param>
			/// <param name="value2">Value 1 to be used as restriction</param>
			/// <returns>Created Snapshot</returns>
			public Snapshot CreateOrSnapshot(Column column1, object value1, Column column2, object value2) {
				return new SnapshotItem(this.CreateOrView(column1, value1, column2, value2));
			}
		}
	}
}
