using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;

namespace LogicCircuit {
	partial class Store {

		/// <summary>
		/// Row state
		/// </summary>
		public enum RowState {
			New,
			Current,
			Deleted
		}

		partial class Table {
			public abstract partial class Row {
				private int sequence;

				private object tag;
				/// <summary>
				/// Any additional data associated with the row
				/// </summary>
				public object Tag {
					get { return this.tag; }
					set { this.tag = value; }
				}

				private Table table;
				/// <summary>
				/// Gets the table the row belongs to
				/// </summary>
				public Table Table { get { return this.table; } }

				private RowState state;
				/// <summary>
				/// Gets current state of the row
				/// </summary>
				public RowState State { get { return this.state; } }

				/// <summary>
				/// Adds new row to the table
				/// </summary>
				public void Add() {
					Tracer.Assert(this.state != RowState.Current);
					Table table = this.table;
					for(int i = 0; i < table.column.Count; i++) {
						if(this.values[i] == null && table.column[i].Mandatory) {
							throw Store.NullViolation(table.column[i]);
						}
					}
					if(this.table.store.enforceForeignKeys) {
						table.CheckForeignKey(this.values);
					}
					table.AddAllIndex(this);
					table.version++;
					table.row.Add(this);
					this.state = RowState.Current;
					if(table.TableChanged != null) {
						table.TableChanged(RowAction.Added, this, null);
					}
				}

				/// <summary>
				/// Deletes the row from the table
				/// </summary>
				public void Delete() {
					Tracer.Assert(this.state == RowState.Current);
					Table table = this.table;
					if(this.table.store.enforceForeignKeys) {
						table.TryDelete(this);
					}
					table.CascadeChid(this);
					table.version++;
					this.state = RowState.Deleted;
					table.row.Remove(this);
					table.DeleteAllIndex(this);
					if(table.TableChanged != null) {
						table.TableChanged(RowAction.Deleted, this, null);
					}
				}

				private object[] values;

				protected object[] Values { get { return this.values; } }

				/// <summary>
				/// Gets or sets all values of the row
				/// </summary>
				public object[] ItemArray {
					get { return (object[])this.values.Clone(); }
					set {
						if(value == null) {
							Tracer.Fail(StoreMessage.NullItemArray);
						}
						if(value.Length != this.values.Length) {
							Tracer.Fail(StoreMessage.ItemArrayLength);
						}
						Table table = this.table;
						for(int i = 0; i < table.column.Count; i++) {
							if(value[i] == null && table.column[i].Mandatory) {
								throw Store.NullViolation(table.column[i]);
							}
							//Do I need to check for types of items are match to types of columns?
							//Because each row will have it's own wrapper it is not nessesary for LogicCircuit
							//but this will be useful in other applications
						}
						if(this.state == RowState.Current) {
							if(this.table.store.enforceForeignKeys) {
								int pk = table.firstPKColumnOrdinal;
								if(pk >= 0 && table.column[pk].Comparer.Compare(this, value[pk]) != 0) {
									//the primary key get changed and this is one column primary key,
									//so check for children
									table.RestrictChild(table.restrictChild, this);
									table.RestrictChild(table.cascadeChild, this);
								}
								table.CheckForeignKey(value);
							}
							table.DeleteAllIndex(this);
							object[] old = (object[])this.values.Clone();
							Array.Copy(value, this.values, this.values.Length);
							try {
								table.AddAllIndex(this);
							} catch(Exception exception) {
								Tracer.Report("Store.Table.Row.ItemArray", exception);
								Array.Copy(old, this.values, this.values.Length);
								table.AddAllIndex(this);
								throw;
							}
							table.version++;
							if(table.TableChanged != null) {
								table.TableChanged(RowAction.Modified, this, old);
							}
						} else {
							Array.Copy(value, this.values, this.values.Length);
						}
					}
				}

				/// <summary>
				/// Gets or sets value in the column specified by zero based index
				/// </summary>
				public object this[int columnOrdinal] {
					get { return this.values[columnOrdinal]; }
					set {
						Table table = this.table;
						Column column = table.column[columnOrdinal];
						if(value == null && column.Mandatory) {
							throw Store.NullViolation(column);
						}
						//Do I need to check for type of item is match to type of column?
						//Because each row will have it's own wrapper it is not nessesary for LogicCircuit
						//but this will be useful in other applications
						object old = this.values[columnOrdinal];
						//The logic here is
						//if(
						//	(value == null && old != null) ||
						//	(value != null && old == null) ||
						//	(value != null && old != null && column.Comparer.Compare(value, old) != 0)
						//) {
						//but this one is probably faster
						if((value == null ^ old == null) ||
							value != null && old != null && column.Comparer.Compare(value, old) != 0
						) {
							object[] all = (object[])this.values.Clone();
							bool current = (this.state == RowState.Current);
							if(current && this.table.store.enforceForeignKeys) {
								if(table.firstPKColumnOrdinal == columnOrdinal) {
									//the primary key get changed and this is one column primary key,
									//so check for children
									table.RestrictChild(table.restrictChild, this);
									table.RestrictChild(table.cascadeChild, this);
								}
								table.CheckForeignKey(columnOrdinal, value);
							}
							List<Index> index = table.depend[columnOrdinal];
							if(current && index != null) {
								foreach(Index i in index) {
									i.Delete(this);
								}
								this.values[columnOrdinal] = value;
								try {
									foreach(Index i in index) {
										i.Add(this);
									}
								} catch(Exception exception) {
									Tracer.Report("Store.Table.Row.Item", exception);
									foreach(Index i in index) {
										i.Delete(this);
									}
									this.values[columnOrdinal] = old;
									foreach(Index i in index) {
										i.Add(this);
									}
									throw;
								}
							} else {
								this.values[columnOrdinal] = value;
							}
							if(current) {
								table.version++;
								if(table.TableChanged != null) {
									table.TableChanged(RowAction.Modified, this, all);
								}
							}
						}
					}
				}
				/// <summary>
				/// Gets or sets value in the column specified by name
				/// </summary>
				public object this[string column] {
					get { return this.values[this.table.ColumnOrdinal(column)]; }
					#if UnitTest
					set { this[this.table.ColumnOrdinal(column)] = value; }
					#endif
				}

				protected Row(Table table) {
					this.sequence = table.store.sequence++;
					this.table = table;
					this.state = RowState.New;
					this.values = new object[this.table.ColumnCount];
					for(int i = 0; i < table.column.Count; i++) {
						this.values[i] = table.column[i].DefaultValue;
					}
				}

				public Row[] DistinctChild() {
					if(this.state == RowState.Current && this.table.firstPKColumnOrdinal >= 0) {
						Row.Comparer comparer = Row.RowComparer();
						List<Row> list = new List<Row>();
						object pk = this.values[this.table.firstPKColumnOrdinal];
						foreach(Index index in this.table.restrictChild) {
							Store.AddDistinct(list, index.Find(pk), comparer);
						}
						foreach(Index index in this.table.cascadeChild) {
							Store.AddDistinct(list, index.Find(pk), comparer);
						}
						return list.ToArray();
					}
					return null;
				}
				public Row Parent(int column) {
					Index parent = this.table.parentIndex[column];
					if(parent != null) {
						Row row = parent.FindUnique(this.values[column]);
						Tracer.Assert(!this.table.store.EnforceForeignKeys || row != null);
						return row;
					}
					return null;
				}

				public override string ToString() {
					return string.Format(Store.DataCulture, "Row{0}", this.sequence);
				}

				#if DEBUG
					public string Dump() {
						return this.ToString();
					}
					public string Dump(object[] values) {
						StringBuilder text = new StringBuilder();
						for(int i = 0; i < Math.Min(this.Table.column.Count, values.Length); i++) {
							Column column = this.Table.column[i];
							text.AppendFormat(Store.DataCulture,
								"{0}: current={1}, undo={2}\n",
								column.Name,
								this.values[i] == null ? "null" : this.values[i].ToString(),
								values[i] == null ? "null" : values[i].ToString()
							);
						}
						return text.ToString();
					}
				#endif
			}

			private class RowItem : Row {
				public RowItem(Table table) : base(table) {
				}
				public new object[] Values { get { return base.Values; } }
			}
		}
	}
}
