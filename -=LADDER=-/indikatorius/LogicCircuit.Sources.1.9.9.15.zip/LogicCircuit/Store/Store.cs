using System;
using System.Globalization;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace LogicCircuit {
	/// <summary>
	/// Store - provides similar functionality as DataSet but performs faster.
	/// </summary>
	public partial class Store : IEnumerable<Store.Table> {

		public static readonly StringComparer StringComparer = StringComparer.OrdinalIgnoreCase;
		public static readonly CultureInfo DataCulture = CultureInfo.InvariantCulture;
		//public static readonly CultureInfo MessageCulture = StoreMessage.Culture;

		//---------------------------------------------------------------------

		public static int BinarySearch(List<Store.Table.Row> list, object value, Store.Table.Row.Comparer comparer) {
			int i1 = 0;
			int i2 = list.Count - 1;
			while(i1 <= i2) {
				int m = (i1 + i2) / 2;
				int r = comparer.Compare(list[m], value);
				if(r == 0) {
					return m;
				} else if(r < 0) {
					i1 = m + 1;
				} else {
					i2 = m - 1;
				}
			}
			return ~i1;
		}
		#if UnitTest
		public static int BinarySearch(Store.Table.Row[] list, object value, Store.Table.Row.Comparer comparer) {
			int i1 = 0;
			int i2 = list.Length - 1;
			while(i1 <= i2) {
				int m = (i1 + i2) / 2;
				int r = comparer.Compare(list[m], value);
				if(r == 0) {
					return m;
				} else if(r < 0) {
					i1 = m + 1;
				} else {
					i2 = m - 1;
				}
			}
			return ~i1;
		}
		#endif

		public static void AddDistinct(List<Table.Row> list, Table.Row[] row, Table.Row.Comparer comparer) {
			if(row != null && row.Length > 0) {
				foreach(Table.Row r in row) {
					int i = list.BinarySearch(r, comparer);
					if(i < 0) {
						list.Insert(~i, r);
					}
				}
			}
		}
		public static Table.Row[] Intersect(Table.Row[] row1, Table.Row[]row2) {
			if(row1 != null && row2 != null) {
				if(row2.Length < row1.Length) {
					Table.Row[] row = row1;
					row1 = row2;
					row2 = row;
				}
				List<Table.Row> list = new List<Table.Row>();
				Table.Row.Comparer comparer = Table.Row.RowComparer();
				Array.Sort<Table.Row>(row2, comparer);
				foreach(Table.Row row in row1) {
					if(Array.BinarySearch<Table.Row>(row2, row, comparer) >= 0) {
						list.Add(row);
					}
				}
				if(list.Count > 0) {
					return list.ToArray();
				}
			}
			return null;
		}
		public static Table.Row[] Union(Table.Row[] row1, Table.Row[] row2) {
			if(row1 == null) return row2;
			if(row2 == null) return row1;
			if(row2.Length < row1.Length) {
				Table.Row[] row = row1;
				row1 = row2;
				row2 = row;
			}
			List<Table.Row> list = new List<Table.Row>(row2);
			Table.Row.Comparer comparer = Table.Row.RowComparer();
			Array.Sort<Table.Row>(row2, comparer);
			foreach(Table.Row row in row1) {
				if(Array.BinarySearch<Table.Row>(row2, row, comparer) < 0) {
					list.Add(row);
				}
			}
			if(list.Count > 0) {
				return list.ToArray();
			}
			return null;
		}

		//---------------------------------------------------------------------

		/// <summary>
		/// Any additional data associated with the store
		/// </summary>
		public object Tag { get; set; }

		private string name;
		/// <summary>
		/// Gets the name of the store
		/// </summary>
		public string Name { get { return this.name; } }

		private string prefix;
		/// <summary>
		/// Gets the prefix of all nodes in the xmls
		/// </summary>
		public string Prefix { get { return this.prefix; } }

		private string nameSpaceUri;
		/// <summary>
		/// Gets the URI of the store
		/// </summary>
		public string NameSpaceUri { get { return this.nameSpaceUri; } }

		private List<Table> table;
		/// <summary>
		/// Gets number of tables in the store
		/// </summary>
		public int Count { get { return this.table.Count; } }
		/// <summary>
		/// Get table by index
		/// </summary>
		public Table this[int i] {
			get { return this.table[i]; }
		}

		public IEnumerator<Store.Table> GetEnumerator() {
			return this.table.GetEnumerator();
		}
		System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() {
			return this.table.GetEnumerator();
		}

		private Dictionary<string, Table> tableName;
		/// <summary>
		/// Gets table by name
		/// </summary>
		public Table this[string tableName] {
			get { return this.tableName[tableName]; }
		}

		private Dictionary<string, Table> indexName;
		private void AddIndex(string index, Table table) {
			this.indexName.Add(index, table);
		}
		//private Table FindByIndex(string name) {
		//	return this.indexName[name];
		//}
		private void DeleteIndex(Table table) {
			List<string> list = new List<string>();
			foreach(string name in this.indexName.Keys) {
				if(this.indexName[name] == table) {
					list.Add(name);
				}
			}
			foreach(string name in list) {
				this.indexName.Remove(name);
			}
		}

		public Table CreateTable(string name) {
			Table table = new TableItem(this, name);
			this.table.Add(table);
			this.tableName.Add(table.Name, table);
			this.version.Add(0);
			return table;
		}
		public void DropTable(Table table) {
			Tracer.Assert(table.Store == this);
			int ordinal = table.Ordinal;
			this.version.RemoveAt(ordinal);
			this.tableName.Remove(table.Name);
			this.table.RemoveAt(ordinal);
			this.DeleteIndex(table);
			((TableItem)table).Detach();
		}

		private bool enforceForeignKeys;
		/// <summary>
		/// Gets or sets a value indicating whether foreign key rules are followed when attempting any update operation
		/// </summary>
		public bool EnforceForeignKeys {
			get { return this.enforceForeignKeys; }
			set {
				if(value) {
					foreach(TableItem table in this.table) {
						table.CheckForeignKey();
					}
				}
				this.enforceForeignKeys = value;
			}
		}

		private int sequence;

		private List<int> version;
		/// <summary>
		/// Resets HasChanges flag
		/// </summary>
		public void AcceptChanges() {
			for(int i = 0; i < this.table.Count; i++) {
				this.version[i] = this.table[i].Version;
			}
		}
		/// <summary>
		/// True if store was chaged since last AcceptChanges
		/// </summary>
		public bool HasChanges {
			get {
				for(int i = 0; i < this.table.Count; i++) {
					if(this.table[i].Persistent && this.table[i].Version != this.version[i]) {
						return true;
					}
				}
				return false;
			}
		}

		//---------------------------------------------------------------------

		private void Init(XmlDocument schema) {
			this.table = new List<Table>();
			this.tableName = new Dictionary<string, Table>();
			this.indexName = new Dictionary<string, Table>();
			this.sequence = 0;
			this.version = new List<int>();
			SchemaParser parser = new SchemaParser(this);
			parser.CreateSchema(schema);
			this.EnforceForeignKeys = true;
		}
		public Store() {
			this.Init(null);
		}
		public Store(XmlDocument schema) {
			this.Init(schema);
		}
		public Store(string schemaXmlText) {
			XmlDocument xml = new XmlDocument();
			xml.LoadXml(schemaXmlText);
			this.Init(xml);
		}

		//---------------------------------------------------------------------

		private static void FailUnsupportedType(string type) {
			Tracer.Fail(StoreMessage.UnsupportedType(type));
		}

		private static object ParseValue(Table.Column column, string columnValue) {
			Type type = column.Type;
			if(type == typeof(Guid)) {
				return new Guid(columnValue);
			} else if(type == typeof(int)) {
				return int.Parse(columnValue, Store.DataCulture);
			} else if(type == typeof(string)) {
				return columnValue;
			} else if(type == typeof(bool)) {
				return bool.Parse(columnValue);
			} else if(type == typeof(double)) {
				return double.Parse(columnValue, Store.DataCulture);
			} else {
				Store.FailUnsupportedType(type.Name);
				return null;
			}
		}

		//---------------------------------------------------------------------

		/// <summary>
		/// Loads data from xml document according to curent scheema
		/// </summary>
		/// <param name="xml">Xml document to load</param>
		public virtual void Load(XmlDocument xml) {
			bool enforce = this.EnforceForeignKeys;
			this.EnforceForeignKeys = false;
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(xml.NameTable);
			nsmgr.AddNamespace(this.Prefix, this.NameSpaceUri);
			foreach(Table table in this.table) {
				if(table.Persistent) {
					string xpath = string.Format(Store.DataCulture,
						"/{0}:{1}/{0}:{2}", this.Prefix, this.Name, table.Name
					);
					foreach(XmlNode nodeRow in xml.SelectNodes(xpath, nsmgr)) {
						Table.Row row = table.NewRow();
						foreach(XmlNode nodeField in nodeRow.ChildNodes) {
							if(table.HasColumn(nodeField.LocalName)) {
								Table.Column column = table.TableColumn(nodeField.LocalName);
								row[column.Ordinal] = Store.ParseValue(column, nodeField.InnerText);
							}
						}
						row.Add();
					}
				}
			}
			this.EnforceForeignKeys = enforce;
		}

		private static bool NeedToSave(object value, Table.Column column) {
			if(value == null) {
				return false;
			}
			if(column.DefaultValue == null) {
				return true;
			}
			return column.Comparer.Compare(value, column.DefaultValue) != 0;
		}

		/// <summary>
		/// Store data into XmlDocument
		/// </summary>
		/// <returns>XmlDocument containig all the data</returns>
		public XmlDocument Save() {
			XmlDocument xml = new XmlDocument();
			xml.LoadXml(
				string.Format(Store.DataCulture,
					"<?xml version=\"1.0\" standalone=\"yes\"?>\n<{0}:{1} xmlns:{0}=\"{2}\"/>",
					this.Prefix, this.Name, this.NameSpaceUri
				)
			);
			XmlNode root = xml.DocumentElement;
			foreach(TableItem table in this.table) {
				if(table.Persistent) {
					table.SortByRowOrder();
					for(int i = 0; i < table.Count; i++) {
						XmlNode nodeRow = xml.CreateElement(this.Prefix, table.Name, this.NameSpaceUri);
						root.AppendChild(nodeRow);
						Table.Row row = table[i];
						for(int j = 0; j < table.ColumnCount; j++) {
							object val = row[j];
							Table.Column column = table.TableColumn(j);
							if(Store.NeedToSave(val, column)) {
								XmlNode nodeColumn = xml.CreateElement(this.Prefix, column.Name, this.NameSpaceUri);
								string text = string.Format(Store.DataCulture, "{0}", val);
								if(text.Length > 0) {
									if(column.Type == typeof(bool)) { //Special case for support DataSet compatibility
										text = text.ToLower(Store.DataCulture);
									}
									nodeColumn.AppendChild(xml.CreateTextNode(text));
								}
								nodeRow.AppendChild(nodeColumn);
							}
						}
					}
				}
			}
			return xml;
		}

		//---------------------------------------------------------------------

		/// <summary>
		/// Defines standart way of formatting xml files
		/// </summary>
		/// <param name="writer">XmlTextWriter to apply formatting to</param>
		public static void DefineFormatting(XmlTextWriter writer) {
			writer.Formatting = Formatting.Indented;
			writer.Indentation = 1;
			writer.IndentChar = '\t';
		}
		/// <summary>
		/// Writes XmlDocument to provided file
		/// </summary>
		/// <param name="xml">XmlDocument to write into file</param>
		/// <param name="fileName">File name to write xml to</param>
		/// <param name="encoding">Encoding of the writing file</param>
		public static void WriteXml(XmlDocument xml, string fileName, Encoding encoding) {
			XmlTextWriter writer = null;
			try {
				writer = new XmlTextWriter(fileName, encoding);
				Store.DefineFormatting(writer);
				xml.Save(writer);
			} finally {
				if(writer != null) {
					writer.Close();
				}
			}
		}

		//---------------------------------------------------------------------

		/// <summary>
		/// Adds content of the row to appropriate table of the store
		/// </summary>
		/// <param name="row">Row to be added</param>
		public void Copy(Table.Row row) {
			TableItem table = (TableItem)this[row.Table.Ordinal];
			table.Copy(row);
		}
		/// <summary>
		/// Adds content of each row in array to appropriate tables of the store
		/// </summary>
		/// <param name="row"></param>
		public void Copy(Table.Row[] row) {
			foreach(Table.Row r in row) {
				this.Copy(r);
			}
		}
	}
}
