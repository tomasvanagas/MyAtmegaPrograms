﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;

namespace LogicCircuit {
	partial class CircuitEditor {

		// use process specific id in order to prevent dragging and dropping between processes.
		private readonly string CircuitDescriptorDataFormat = "LogicCircuit.CircuitDescriptor." + Process.GetCurrentProcess().Id;
		private readonly double DragSize = 3;

		private Point dragStart;
		private FrameworkElement dragSource;

		public void DescriptorMouseDown(FrameworkElement sender, MouseButtonEventArgs e) {
			if(e.ChangedButton == MouseButton.Left && this.InEditMode) {
				CircuitDescriptor descriptor = sender.Tag as CircuitDescriptor;
				if(descriptor != null) {
					if(1 < e.ClickCount) {
						LogicalCircuitDescriptor logicalCircuitDescriptor = descriptor as LogicalCircuitDescriptor;
						if(logicalCircuitDescriptor != null && !logicalCircuitDescriptor.IsCurrent) {
							this.OpenLogicalCircuit(logicalCircuitDescriptor.LogicalCircuit);
						}
					} else {
						this.dragStart = e.GetPosition(sender);
						this.dragSource = sender;
					}
				}
			}
		}

		public void DescriptorMouseUp(FrameworkElement sender, MouseButtonEventArgs e) {
			this.dragSource = null;
		}

		public void DescriptorMouseMove(FrameworkElement sender, MouseEventArgs e) {
			if(this.InEditMode && this.dragSource != null) {
				Point point = e.GetPosition(this.dragSource);
				double x = point.X - this.dragStart.X;
				double y = point.Y - this.dragStart.Y;
				if(this.DragSize < x * x + y * y) {
					CircuitDescriptor descriptor = (CircuitDescriptor)this.dragSource.Tag;
					this.dragSource = null;
					DragDrop.DoDragDrop(
						descriptor.Glyph,
						new DataObject(this.CircuitDescriptorDataFormat, descriptor),
						DragDropEffects.Copy | DragDropEffects.Scroll
					);
				}
			}
		}

		private void canvas_DragOver(object sender, DragEventArgs e) {
			try {
				if(this.InEditMode && e.Data.GetDataPresent(this.CircuitDescriptorDataFormat, false)) {
					e.Effects = DragDropEffects.Copy | DragDropEffects.Scroll;
				} else {
					e.Effects = DragDropEffects.None;
				}
				e.Handled = true;
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void canvas_DragLeave(object sender, DragEventArgs e) {
			try {
				e.Effects = DragDropEffects.None;
				e.Handled = true;
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void canvas_Drop(object sender, DragEventArgs e) {
			if(this.InEditMode) {
				try {
					CircuitDescriptor descriptor = e.Data.GetData(this.CircuitDescriptorDataFormat, false) as CircuitDescriptor;
					if(descriptor != null) {
						GridPoint point = Plotter.GridPoint(e.GetPosition(this.Canvas));
						Transaction transaction = this.ProjectManager.BeginTransaction();
						bool success = false;
						try {
							Circuit circuit = descriptor.Circuit(this.ProjectManager);
							this.ProjectManager.CircuitSymbolStore.Create(
								circuit, this.LogicalCircuit, point.X, point.Y
							);
							success = true;
						} finally {
							this.ProjectManager.EndTransaction(transaction, success);
						}
					}
				} catch(Exception exception) {
					MainFrame.Report(exception);
				} finally {
					this.Redraw();
				}
			}
			e.Handled = true;
		}
	}
}
