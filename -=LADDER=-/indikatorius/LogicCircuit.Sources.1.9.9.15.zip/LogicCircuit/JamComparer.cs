﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class JamComparer : IComparer<Jam> {
		public static readonly IComparer<Jam> Comparer = new JamComparer();
		public static readonly IComparer<Jam> ByPinComparer = new JamByPinComparer();

		public int Compare(Jam x, Jam y) {
			int result = x.AbsoluteY - y.AbsoluteY;
			if(result == 0) {
				return x.AbsoluteX - y.AbsoluteX;
			}
			return result;
		}

		public int Compare(Jam jam, GridPoint point) {
			int result = jam.AbsoluteY - point.Y;
			if(result == 0) {
				return jam.AbsoluteX - point.X;
			}
			return result;
		}

		public Jam Find(List<Jam> list, GridPoint point) {
			int left = 0;
			int right = list.Count - 1;
			while(left <= right) {
				int index = (left + right) / 2;
				int result = this.Compare(list[index], point);
				if(result == 0) {
					return list[index];
				} else if(result < 0) {
					left = index + 1;
				} else {
					right = index - 1;
				}
			}
			return null;
		}

		private class JamByPinComparer : IComparer<Jam> {

			public int Compare(Jam x, Jam y) {
				return PinComparer.Comparer.Compare(x.Pin, y.Pin);
			}
		}
	}
}
