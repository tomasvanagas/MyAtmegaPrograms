﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Xml;

namespace LogicCircuit {
	public partial class Plotter {
		public const int PinRadius = 3;
		public const int GridSize = Plotter.PinRadius * 5;

		public static Point ScreenPoint(int xGrid, int yGrid) {
			return new Point(xGrid * Plotter.GridSize, yGrid * Plotter.GridSize);
		}

		public static Point ScreenPoint(GridPoint point) {
			return Plotter.ScreenPoint(point.X, point.Y);
		}

		public static GridPoint GridPoint(Point screenPoint) {
			return new GridPoint(
				(int)Math.Round(screenPoint.X / Plotter.GridSize),
				(int)Math.Round(screenPoint.Y / Plotter.GridSize)
			);
		}

		public static Line CreateGlyph(Wire wire) {
			Line line = new Line();
			line.Stroke = Plotter.WireStroke;
			line.StrokeThickness = 1;
			line.ToolTip = Resources.ToolTipWire;
			line.Tag = wire;
			return line;
		}

		public static FrameworkElement CreateGlyph(CircuitSymbol symbol) {
			return Plotter.CreateGlyph(symbol.Circuit, symbol);
		}

		public static FrameworkElement CreateGlyph(Circuit circuit) {
			return Plotter.CreateGlyph(circuit, null);
		}

		//---------------------------------------------------------------------

		/// <summary>
		/// Evaluate relative position of two vectors defined as (p0, p1) and (p0, p2)
		/// </summary>
		/// <param name="p0">Start point of both vectors</param>
		/// <param name="p1">The end point of first vector</param>
		/// <param name="p2">The end point of second vector</param>
		/// <returns>if +1 then vector p0-p1 is clockwise from p0-p2; if -1, it is counterclockwise</returns>
		public static int CrossProductSign(Point p0, Point p1, Point p2) {
			return Math.Sign((p1.X - p0.X) * (p2.Y - p0.Y) - (p2.X - p0.X) * (p1.Y - p0.Y));
		}

		/// <summary>
		/// Checks if two line segments are intersected
		/// </summary>
		/// <param name="p1">First vertex of first line segment</param>
		/// <param name="p2">Second vertex of first line segment</param>
		/// <param name="p3">First vertex of second line segment</param>
		/// <param name="p4">Second vertex of second line segment</param>
		/// <returns>true if line segment (p1, p2) is intersected with line segment (p3, p4)</returns>
		public static bool Intersected(Point p1, Point p2, Point p3, Point p4) {
			//1. Find if bounding rectangles intersected
			double x1 = Math.Min(p1.X, p2.X);
			double y1 = Math.Min(p1.Y, p2.Y);
			double x2 = Math.Max(p1.X, p2.X);
			double y2 = Math.Max(p1.Y, p2.Y);

			double x3 = Math.Min(p3.X, p4.X);
			double y3 = Math.Min(p3.Y, p4.Y);
			double x4 = Math.Max(p3.X, p4.X);
			double y4 = Math.Max(p3.Y, p4.Y);
			if((x2 >= x3) && (x4 >= x1) && (y2 >= y3) && (y4 >= y1)) {
				//2. now, two line segments intersected if each straddles the line containing the other
				// let's use CrossRoductSign for this purpose.
				return(
					(Plotter.CrossProductSign(p1, p2, p3) * Plotter.CrossProductSign(p1, p2, p4) <= 0) &&
					(Plotter.CrossProductSign(p3, p4, p1) * Plotter.CrossProductSign(p3, p4, p2) <= 0)
				);
			}
			return false;
		}

		/// <summary>
		/// Checks if line segment (p1, p2) intersets with rectangle r
		/// </summary>
		/// <param name="p1">First vertex of the line segment</param>
		/// <param name="p2">Second vertex of the line segment</param>
		/// <param name="r">Rectangle</param>
		/// <returns>true if line segment and rectangle have intersection</returns>
		public static bool Intersected(Point p1, Point p2, Rect r) {
			if(r.Contains(p1) || r.Contains(p2)) {
				return true;
			}
			Point r1 = new Point(r.X, r.Y);
			Point r2 = new Point(r.X + r.Width, r.Y);
			Point r3 = new Point(r.X + r.Width, r.Y + r.Height);
			Point r4 = new Point(r.X, r.Y + r.Height);
			return(
				Plotter.Intersected(p1, p2, r1, r2) ||
				Plotter.Intersected(p1, p2, r2, r3) ||
				Plotter.Intersected(p1, p2, r3, r4) ||
				Plotter.Intersected(p1, p2, r4, r1)
			);
		}

		//---------------------------------------------------------------------

		private static FrameworkElement CreateGlyph(Circuit circuit, CircuitSymbol symbol) {
			Tracer.Assert(symbol == null || symbol.Circuit == circuit);
			Gate gate = circuit as Gate;
			if(gate != null) {
				switch(gate.GateType) {
				case GateType.Clock:
					return Plotter.ClockGlyph(circuit, symbol);
				case GateType.Led:
					if(gate.InputCount == 1) {
						return Plotter.LedGlyph(circuit, symbol);
					} else {
						Tracer.Assert(gate.InputCount == 8);
						return Plotter.SevenSegmentGlyph(circuit, symbol);
					}
				case GateType.Probe:
					return Plotter.ProbeGlyph(circuit, symbol);
				default:
					return Plotter.GateGlyph(circuit, symbol);
				}
			}
			if(circuit is LogicalCircuit || circuit is Memory) {
				return Plotter.GateGlyph(circuit, symbol);
			}
			Pin pin = circuit as Pin;
			if(pin != null) {
				if(pin.PinType == PinType.Input) {
					return Plotter.InputPinGlyph(circuit, symbol);
				} else if(pin.PinType == PinType.Output) {
					return Plotter.OutputPinGlyph(circuit, symbol);
				} else {
					Tracer.Fail();
				}
			}
			if(circuit is Constant) {
				return Plotter.ConstantGlyph(circuit, symbol);
			}
			if(circuit is CircuitButton) {
				return Plotter.ButtonGlyph(circuit, symbol);
			}
			if(circuit is Splitter) {
				return Plotter.SplitterGlyph(circuit, symbol);
			}
			Tracer.Fail();
			return null;
		}

		private static FrameworkElement GateGlyph(Circuit circuit, CircuitSymbol symbol) {
			Tracer.Assert(symbol == null || symbol.Circuit == circuit);
			Tracer.Assert(circuit is Gate || circuit is LogicalCircuit || circuit is Memory);
			List<BasePin> left = new List<BasePin>();
			List<BasePin> top = new List<BasePin>();
			List<BasePin> right = new List<BasePin>();
			List<BasePin> bottom = new List<BasePin>();
			for(int i = 0; i < circuit.InputCount; i++) {
				BasePin pin = circuit.Input(i);
				switch(pin.PinSide) {
				case PinSide.Left:
					left.Add(pin);
					break;
				case PinSide.Top:
					top.Add(pin);
					break;
				case PinSide.Right:
					right.Add(pin);
					break;
				case PinSide.Bottom:
					bottom.Add(pin);
					break;
				default:
					Tracer.Fail();
					break;
				}
			}
			for(int i = 0; i < circuit.OutputCount; i++) {
				BasePin pin = circuit.Output(i);
				switch(pin.PinSide) {
				case PinSide.Left:
					left.Add(pin);
					break;
				case PinSide.Top:
					top.Add(pin);
					break;
				case PinSide.Right:
					right.Add(pin);
					break;
				case PinSide.Bottom:
					bottom.Add(pin);
					break;
				default:
					Tracer.Fail();
					break;
				}
			}
			left.Sort(PinComparer.Comparer);
			top.Sort(PinComparer.Comparer);
			right.Sort(PinComparer.Comparer);
			bottom.Sort(PinComparer.Comparer);
			return Plotter.GateGlyph(circuit, symbol, left, top, right, bottom);
		}

		private static Ellipse AddPin(Canvas canvas, GridPoint point, CircuitSymbol symbol, BasePin pin) {
			Jam jam = (symbol != null) ? symbol.ProjectManager.JamStore.Jam(pin, symbol, point) : null;
			Ellipse ellipse = new Ellipse();
			ellipse.Tag = jam;
			ellipse.Width = ellipse.Height = 2 * Plotter.PinRadius;
			Canvas.SetLeft(ellipse, point.X * Plotter.GridSize);
			Canvas.SetTop(ellipse, point.Y * Plotter.GridSize);
			canvas.Children.Add(ellipse);
			if(pin.Inverted) {
				ellipse.Fill = Plotter.JamInvertedFill;
				ellipse.Stroke = Plotter.JamStroke;
				ellipse.StrokeThickness = 1;
				Panel.SetZIndex(ellipse, 1);
			} else {
				ellipse.Fill = Plotter.JamDirectFill;
			}
			ellipse.ToolTip = pin.ToolTip;
			return ellipse;
		}

		private static void AddPin(Canvas canvas, int sideSize, CircuitSymbol symbol, List<BasePin> pin, Func<int, GridPoint> point) {
			if(pin.Count == 1) {
				Plotter.AddPin(canvas, point(sideSize / 2), symbol, pin[0]);
			} else {
				int dy = (sideSize - 2) / (pin.Count - 1);
				for(int i = 0; i < pin.Count; i++) {
					Plotter.AddPin(canvas, point(i * dy + 1), symbol, pin[i]);
				}
			}
		}

		[System.Diagnostics.Conditional("DEBUG")]
		private static void AddPosition(Canvas canvas, CircuitSymbol symbol) {
			#if DEBUG1
				if(symbol != null) {
					TextBlock text = new TextBlock();
					text.FontSize = text.FontSize * 2 / 3;
					text.Padding = new Thickness(5);
					text.TextAlignment = TextAlignment.Center;
					text.Foreground = Brushes.BlueViolet;
					text.Text = symbol.Point.ToString();
					Canvas.SetBottom(text, 0);
					Canvas.SetRight(text, 0);
					canvas.Children.Add(text);
				}
			#endif
		}

		private static FrameworkElement CircuitSkin(Canvas canvas, string skin) {
			FrameworkElement shape = null;
			using(StringReader stringReader = new StringReader(skin)) {
				using(XmlTextReader xmlReader = new XmlTextReader(stringReader)) {
					shape = (FrameworkElement)XamlReader.Load(xmlReader);
				}
			}
			shape.Width = canvas.Width - 2 * Plotter.PinRadius;
			shape.Height = canvas.Height - 2 * Plotter.PinRadius;
			Canvas.SetLeft(shape, Plotter.PinRadius);
			Canvas.SetTop(shape, Plotter.PinRadius);
			canvas.Children.Add(shape);
			return shape;
		}

		private static string GateSkin(Circuit circuit) {
			if(Settings.User.GateShape == GateShape.Rectangular || circuit is LogicalCircuit || circuit is Memory) {
				return GateShapes.Rectangular;
			} else {
				Gate gate = (Gate)circuit;
				switch(gate.GateType) {
				case GateType.Not:
					return GateShapes.ShapedNot;
				case GateType.Or:
					return GateShapes.ShapedOr;
				case GateType.And:
					return GateShapes.ShapedAnd;
				case GateType.Xor:
					return GateShapes.ShapedXor;
				case GateType.Odd:
				case GateType.Even:
					return GateShapes.Rectangular;
				case GateType.TriState:
					return GateShapes.ShapedTriState;
				default:
					Tracer.Fail();
					return null;
				}
			}
		}

		private static FrameworkElement GateGlyph(
			Circuit circuit, CircuitSymbol symbol, List<BasePin> left, List<BasePin> top, List<BasePin> right, List<BasePin> bottom
		) {
			int leftCount = left.Count;
			int topCount = top.Count;
			int rightCount = right.Count;
			int bottomCount = bottom.Count;
			int width = Math.Max(2, Math.Max(topCount, bottomCount)) + 1;
			int height = Math.Max(leftCount, rightCount);
			height = (height < 3) ? Math.Max(2, height) * 2 : height + 1;

			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = width * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = height * Plotter.GridSize + 2 * Plotter.PinRadius;
			if(0 < leftCount) {
				Plotter.AddPin(canvas, height, symbol, left, y => new GridPoint(0, y));
			}
			if(0 < rightCount) {
				Plotter.AddPin(canvas, height, symbol, right, y => new GridPoint(width, y));
			}
			if(0 < topCount) {
				Plotter.AddPin(canvas, width, symbol, top, x => new GridPoint(x, 0));
			}
			if(0 < bottomCount) {
				Plotter.AddPin(canvas, width, symbol, bottom, x => new GridPoint(x, height));
			}

			FrameworkElement shape = Plotter.CircuitSkin(canvas, Plotter.GateSkin(circuit));
			TextBlock text = shape.FindName("Notation") as TextBlock;
			if(text != null) {
				text.Text = circuit.Notation;
			}

			canvas.ToolTip = circuit.ToolTip;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}

		private static FrameworkElement ButtonGlyph(Circuit circuit, CircuitSymbol symbol) {
			CircuitButton button = (CircuitButton)circuit;
			Tracer.Assert(button != null);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			Plotter.AddPin(canvas, new GridPoint(2, 1), symbol, button.Output(0));
			ButtonControl buttonControl = new ButtonControl();
			buttonControl.Content = button.Notation;
			buttonControl.MinWidth = buttonControl.MaxWidth = 2 * Plotter.GridSize;
			buttonControl.MinHeight = buttonControl.MaxHeight = 2 * Plotter.GridSize;
			buttonControl.Margin = new Thickness(0);
			Canvas.SetLeft(buttonControl, Plotter.PinRadius);
			Canvas.SetTop(buttonControl, Plotter.PinRadius);
			canvas.Children.Add(buttonControl);

			if(symbol != null) {
				symbol.ProbeView = buttonControl;
				buttonControl.PreviewMouseLeftButtonDown += new MouseButtonEventHandler(symbol.PreviewMouseDown);
				buttonControl.PreviewMouseLeftButtonUp += new MouseButtonEventHandler(symbol.PreviewMouseUp);
				buttonControl.PreviewKeyDown += new KeyEventHandler(symbol.PreviewKeyDown);
				buttonControl.PreviewKeyUp += new KeyEventHandler(symbol.PreviewKeyUp);
			}

			canvas.ToolTip = button.ToolTip;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}

		private static FrameworkElement ClockGlyph(Circuit circuit, CircuitSymbol symbol) {
			Gate gate = circuit as Gate;
			Tracer.Assert(gate != null && gate.GateType == GateType.Clock && gate.OutputCount == 1);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			Plotter.AddPin(canvas, new GridPoint(2, 1), symbol, gate.Output(0));

			FrameworkElement shape = Plotter.CircuitSkin(canvas, GateShapes.Clock);

			canvas.ToolTip = gate.ToolTip;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}

		private static FrameworkElement LedGlyph(Circuit circuit, CircuitSymbol symbol) {
			Gate gate = circuit as Gate;
			Tracer.Assert(gate != null && gate.GateType == GateType.Led && gate.InputCount == 1);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			Plotter.AddPin(canvas, new GridPoint(0, 1), symbol, gate.Input(0));
			FrameworkElement shape = Plotter.CircuitSkin(canvas, GateShapes.Led);
			if(symbol != null) {
				FrameworkElement probeView = shape.FindName("ProbeView") as FrameworkElement;
				if(probeView != null) {
					symbol.ProbeView = probeView;
				}
			}

			canvas.ToolTip = gate.Name;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}

		private static FrameworkElement SevenSegmentGlyph(Circuit circuit, CircuitSymbol symbol) {
			Gate gate = circuit as Gate;
			Tracer.Assert(gate != null && gate.GateType == GateType.Led && gate.InputCount == 8);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			int width = 3;
			int height = 5;
			canvas.Width = width * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = height * Plotter.GridSize + 2 * Plotter.PinRadius;
			DevicePin[] pinList = circuit.ProjectManager.DevicePinStore.Select(circuit, PinType.Input);
			Array.Sort<BasePin>(pinList, PinComparer.Comparer);
			for(int i = 0; i < pinList.Length; i++) {
				BasePin pin = pinList[i];
				Plotter.AddPin(canvas, new GridPoint(pin.PinSide == PinSide.Left ? 0 : width, i % 4 + 1), symbol, pin);
			}

			FrameworkElement shape = Plotter.CircuitSkin(canvas, GateShapes.SevenSegment);
			if(symbol != null) {
				FrameworkElement probeView = shape.FindName("ProbeView") as FrameworkElement;
				if(probeView != null) {
					symbol.ProbeView = probeView;
				}
			}

			canvas.ToolTip = gate.Name;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}

		private static FrameworkElement ProbeGlyph(Circuit circuit, CircuitSymbol symbol) {
			Gate gate = circuit as Gate;
			Tracer.Assert(gate != null && gate.GateType == GateType.Probe && gate.InputCount == 1);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			Plotter.AddPin(canvas, new GridPoint(0, 1), symbol, gate.Input(0));

			FrameworkElement shape = Plotter.CircuitSkin(canvas, GateShapes.Probe);
			if(symbol != null) {
				FrameworkElement probeView = shape.FindName("ProbeView") as FrameworkElement;
				if(probeView != null) {
					symbol.ProbeView = probeView;
				}
			}

			canvas.ToolTip = gate.ToolTip;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}

		private static FrameworkElement InputPinGlyph(Circuit circuit, CircuitSymbol symbol) {
			Pin pin = circuit as Pin;
			Tracer.Assert(pin != null && pin.PinType == PinType.Input);
			Tracer.Assert(pin.InputCount == 0 && pin.OutputCount == 1);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			Plotter.AddPin(canvas, new GridPoint(2, 1), symbol, pin.Output(0));

			FrameworkElement shape = Plotter.CircuitSkin(canvas, GateShapes.InputPin);
			TextBlock probeView = shape.FindName("ProbeView") as TextBlock;
			if(probeView != null) {
				if(symbol != null) {
					symbol.ProbeView = probeView;
				}
				probeView.Text = Resources.TitlePinInput(pin.Name);
			}

			canvas.ToolTip = pin.ToolTip;

			return canvas;
		}

		private static FrameworkElement OutputPinGlyph(Circuit circuit, CircuitSymbol symbol) {
			Pin pin = circuit as Pin;
			Tracer.Assert(pin != null && pin.PinType == PinType.Output);
			Tracer.Assert(pin.InputCount == 1 && pin.OutputCount == 0);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			Plotter.AddPin(canvas, new GridPoint(0, 1), symbol, pin.Input(0));

			FrameworkElement shape = Plotter.CircuitSkin(canvas, GateShapes.OutputPin);
			TextBlock probeView = shape.FindName("ProbeView") as TextBlock;
			if(probeView != null) {
				if(symbol != null) {
					symbol.ProbeView = probeView;
				}
				probeView.Text = Resources.TitlePinOutput(pin.Name);
			}

			canvas.ToolTip = pin.ToolTip;

			return canvas;
		}

		private static FrameworkElement ConstantGlyph(Circuit circuit, CircuitSymbol symbol) {
			Constant constant = circuit as Constant;
			Tracer.Assert(constant != null && constant.OutputCount == 1 && constant.InputCount == 0);
			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = 2 * Plotter.GridSize + 2 * Plotter.PinRadius;
			Plotter.AddPin(canvas, new GridPoint(2, 1), symbol, constant.Output(0));

			FrameworkElement shape = Plotter.CircuitSkin(canvas, GateShapes.Constant);
			TextBlock probeView = shape.FindName("ProbeView") as TextBlock;
			if(probeView != null) {
				if(symbol != null) {
					symbol.ProbeView = probeView;
				}
				probeView.Text = constant.Notation;
			}
			if(symbol != null) {
				canvas.MouseDown += new MouseButtonEventHandler(symbol.PreviewMouseDown);
			}

			canvas.ToolTip = constant.ToolTip;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}

		private static FrameworkElement SplitterGlyph(Circuit circuit, CircuitSymbol symbol) {
			Splitter splitter = circuit as Splitter;
			Tracer.Assert(splitter != null);

			//TODO: unify with gate glyph
			List<BasePin> left = new List<BasePin>();
			List<BasePin> top = new List<BasePin>();
			List<BasePin> right = new List<BasePin>();
			List<BasePin> bottom = new List<BasePin>();
			DevicePin[] pins = splitter.ProjectManager.DevicePinStore.Select(splitter);
			Array.Sort<BasePin>(pins, PinComparer.Comparer);
			foreach(DevicePin pin in pins) {
				switch(pin.PinSide) {
				case PinSide.Left:
					left.Add(pin);
					break;
				case PinSide.Top:
					top.Add(pin);
					break;
				case PinSide.Right:
					right.Add(pin);
					break;
				case PinSide.Bottom:
					bottom.Add(pin);
					break;
				default:
					Tracer.Fail();
					break;
				}
			}

			int leftCount = left.Count;
			int topCount = top.Count;
			int rightCount = right.Count;
			int bottomCount = bottom.Count;
			int width = Math.Max(topCount, bottomCount) + 1;
			int height = Math.Max(leftCount, rightCount) + 1;
			if(width < height) {
				height = (height < 3) ? Math.Max(2, height) * 2 : height;
			} else {
				width = (width < 3) ? Math.Max(2, width) * 2 : width;
			}

			Canvas canvas = new Canvas();
			canvas.Tag = symbol;
			canvas.Width = width * Plotter.GridSize + 2 * Plotter.PinRadius;
			canvas.Height = height * Plotter.GridSize + 2 * Plotter.PinRadius;
			if(0 < leftCount) {
				Plotter.AddPin(canvas, height, symbol, left, y => new GridPoint(0, y));
			}
			if(0 < rightCount) {
				Plotter.AddPin(canvas, height, symbol, right, y => new GridPoint(width, y));
			}
			if(0 < topCount) {
				Plotter.AddPin(canvas, width, symbol, top, x => new GridPoint(x, 0));
			}
			if(0 < bottomCount) {
				Plotter.AddPin(canvas, width, symbol, bottom, x => new GridPoint(x, height));
			}

			Rectangle rectangle = new Rectangle();
			rectangle.Width = canvas.Width - 4 * Plotter.PinRadius;
			rectangle.Height = canvas.Height - 4 * Plotter.PinRadius;
			Canvas.SetLeft(rectangle, 2 * Plotter.PinRadius);
			Canvas.SetTop(rectangle, 2 * Plotter.PinRadius);
			canvas.Children.Add(rectangle);
			rectangle.Fill = Brushes.Black;

			canvas.ToolTip = splitter.ToolTip;

			Plotter.AddPosition(canvas, symbol);

			return canvas;
		}
	}
}
