﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace LogicCircuit {
	/// <summary>
	/// Interaction logic for DialogProject.xaml
	/// </summary>
	public partial class DialogProject : Window {

		private SettingsWindowLocationCache windowLocation;
		public SettingsWindowLocationCache WindowLocation { get { return this.windowLocation ?? (this.windowLocation = new SettingsWindowLocationCache(this)); } }

		private Project project;

		public DialogProject(Project project) {
			this.DataContext = this;
			this.project = project;
			this.InitializeComponent();
			this.name.Text = project.Name;
			this.description.Text = project.Description;
		}

		private void ButtonOkClick(object sender, RoutedEventArgs e) {
			Transaction transaction = this.project.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				this.project.Name = this.name.Text.Trim();
				this.project.Description = this.description.Text.Trim();
				success = true;
			} catch(Exception exception) {
				MainFrame.Report(exception);
			} finally {
				this.project.ProjectManager.EndTransaction(transaction, success);
			}
			this.Close();
		}
	}
}
