﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Diagnostics;

namespace LogicCircuit {
	public class MarkerPoint {

		public const double Size = 6;

		public Marker Marker { get; private set; }
		public Rectangle Glyph { get; private set; }
		public GridPoint Point { get; private set; }

		public MarkerPoint(Marker marker, GridPoint point) {
			this.Marker = marker;
			this.Glyph = new Rectangle();
			this.Glyph.Tag = this;
			this.Glyph.Width = MarkerPoint.Size;
			this.Glyph.Height = MarkerPoint.Size;
			this.Glyph.Stroke = Plotter.MarkerStroke;
			this.Glyph.StrokeThickness = 1;
			this.Glyph.Fill = Plotter.MarkerFill;
			this.Glyph.ToolTip = Resources.ToolTipWire;
			Canvas.SetZIndex(this.Glyph, int.MaxValue);
			this.MoveTo(point);
			this.Marker.Canvas.Children.Add(this.Glyph);
		}

		public void MoveTo(GridPoint point) {
			this.Point = point;
			Point p = Plotter.ScreenPoint(point);
			p.Offset(Plotter.PinRadius - MarkerPoint.Size / 2, Plotter.PinRadius - MarkerPoint.Size / 2);
			Canvas.SetLeft(this.Glyph, p.X);
			Canvas.SetTop(this.Glyph, p.Y);
			Line line = (Line)this.Marker.Glyph;
			if(line != null) {
				if(this.Marker.Point1 == this) {
					line.X1 = p.X;
					line.Y1 = p.Y;
				} else {
					Debug.Assert(this.Marker.Point2 == this);
					line.X2 = p.X;
					line.Y2 = p.Y;
				}
			}
		}

		public void Move(double x, double y) {
			Canvas.SetLeft(this.Glyph, Canvas.GetLeft(this.Glyph) + x);
			Canvas.SetTop(this.Glyph, Canvas.GetTop(this.Glyph) + y);
		}

		public void Delete() {
			this.Marker.Canvas.Children.Remove(this.Glyph);
			this.Glyph = null;
			this.Marker = null;
		}
	}
}
