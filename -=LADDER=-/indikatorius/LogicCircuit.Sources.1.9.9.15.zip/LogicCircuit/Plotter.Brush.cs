﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace LogicCircuit {
	partial class Plotter {

		private static Dictionary<string, Brush> brush = new Dictionary<string, Brush>();
		public static Brush Brush(string brushName) {
			Brush b;
			if(!Plotter.brush.TryGetValue(brushName, out b)) {
				if(App.Current != null) {
					b = (Brush)App.Current.FindResource(brushName);
				} else {
					Random r = new Random();
					b = new SolidColorBrush(Color.FromArgb(Colors.Black.A, (byte)r.Next(0x100), (byte)r.Next(0x100), (byte)r.Next(0x100)));
				}
				Plotter.brush.Add(brushName, b);
			}
			return b;
		}

		public static Brush CircuitGrid {
			get {
				if(Settings.User.ShowGrid) {
					DrawingGroup drawing = new DrawingGroup();
					drawing.Children.Add(
						new GeometryDrawing(Brushes.White, null,
							new RectangleGeometry(new Rect(0, 0, Plotter.GridSize, Plotter.GridSize))
						)
					);
					drawing.Children.Add(
						new GeometryDrawing(
							new SolidColorBrush(Color.FromArgb(0x55, 0, 0, 0)),
							null,
							new RectangleGeometry(new Rect(Plotter.PinRadius, Plotter.PinRadius, 1, 1))
						)
					);
					DrawingBrush circuitGrid = new DrawingBrush(drawing);
					circuitGrid.Stretch = Stretch.None;
					circuitGrid.TileMode = TileMode.Tile;
					circuitGrid.ViewportUnits = BrushMappingMode.Absolute;
					circuitGrid.Viewport = new Rect(0, 0, Plotter.GridSize, Plotter.GridSize);
					return circuitGrid;
				} else {
					return Brushes.White;
				}
			}
		}

		public static Brush MarkerStroke { get { return Plotter.Brush("MarkerStroke"); } }
		public static Brush MarkerFill { get { return Plotter.Brush("MarkerFill"); } }

		public static Brush LedOffFill { get { return Plotter.Brush("LedOff"); } }
		public static Brush LedStroke { get { return Brushes.Black; } }
		public static Brush Led7SegmentOff { get { return Plotter.Brush("Led7SegmentOff"); } }

		public static Brush WireStroke { get { return Brushes.Black; } }

		public static Brush JamDirectFill { get { return Brushes.Black; } }
		public static Brush JamInvertedFill { get { return Brushes.White; } }
		public static Brush JamStroke { get { return Brushes.Black; } }

		public static Brush GateFill { get { return Brushes.White; } }
		public static Brush GateStroke { get { return Brushes.Black; } }
	}
}
