﻿using System;
using System.Collections.Generic;
using System.Windows.Data;

namespace LogicCircuit {

	[ValueConversion(typeof(int), typeof(double))]
	public class CoordinateConverter : IValueConverter {
		public const int JamRadius = 3;
		public const int JamDiameter = CoordinateConverter.JamRadius * 2;
		public const int GridSize = CoordinateConverter.JamRadius * 5;

		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
			return (int)value * CoordinateConverter.GridSize;
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
			return ((int)(double)value) / CoordinateConverter.GridSize;
		}
	}
}
