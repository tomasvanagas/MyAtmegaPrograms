﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace LogicCircuit {
	public class CircuitRunner : PropertyBag {

		public MainFrame MainFrame { get; private set; }
		public ProjectManager ProjectManager { get; private set; }
		public CircuitState CircuitState { get; private set; }
		private CircuitMap visibleMap;
		private CircuitMap rootMap;
		private object syncRoot = new object();
		private PreciseTimer timer;
		private bool onMaxSpeed;
		private Thread evaluationThread;
		private Thread refreshingThread;
		private AutoResetEvent evaluationGate;
		private AutoResetEvent refreshingGate;
		private volatile bool refreshing = false;
		private int flipCount;

		public DialogOscilloscope DialogOscilloscope { get; set; }
		public bool Oscilloscoping { get; set; }
		public int HistorySize { get; private set; }
		public Oscilloscope Oscilloscope { get; set; }

		public CircuitRunner(ProjectManager projectManager, MainFrame mainFrame) {
			this.ProjectManager = projectManager;
			this.MainFrame = mainFrame;
			this.timer = new PreciseTimer(this.TickSet, 50);
			this.Oscilloscoping = false;
			this.HistorySize = 100;
		}

		public IEnumerable<CircuitMap> RootMap {
			get { return new CircuitMap[] { this.rootMap }; }
		}

		public CircuitMap VisibleMap {
			get { return this.visibleMap; }
			set {
				CircuitMap old = this.visibleMap;
				this.visibleMap = value;
				if(old != null) {
					old.NotifyIsCurrentChanged();
				}
				if(this.visibleMap != null) {
					this.visibleMap.NotifyIsCurrentChanged();
				}
			}
		}

		public int HalfPeriod {
			get { return this.timer.Period; }
			set { this.timer.Period = value; }
		}

		public void TurnOn() {
			lock(this.syncRoot) {
				if(this.evaluationThread != null) {
					return;
				}
				this.evaluationThread = new Thread(new ThreadStart(this.Run));
			}
			this.evaluationThread.IsBackground = true;
			this.evaluationThread.Name = "EvaluationThread";
			this.evaluationThread.Priority = ThreadPriority.Normal;

			this.refreshingThread = new Thread(new ThreadStart(this.MonitorUI));
			this.refreshingThread.IsBackground = true;
			this.refreshingThread.Name = "RefreshingThread";
			this.refreshingThread.Priority = ThreadPriority.BelowNormal;

			this.evaluationThread.Start();
		}

		public void TurnOff() {
			Thread t = this.evaluationThread;
			if(t != null) {
				Thread r = this.refreshingThread;
				if(r != null) {
					r.Abort();
				}
				t.Abort();
			}
		}

		public bool IsTurnedOn { get { return this.evaluationThread != null; } }

		public bool MaxSpeed {
			get { return this.onMaxSpeed; }
			set {
				this.onMaxSpeed = value;
				if(value) {
					AutoResetEvent e = this.evaluationGate;
					if(e != null) {
						e.Set();
					}
				}
			}
		}

		private void NotifyRootMapChanged() {
			if(this.MainFrame.Dispatcher.CheckAccess()) {
				this.OnPropertyChanged("RootMap");
			} else {
				this.MainFrame.Dispatcher.BeginInvoke(DispatcherPriority.SystemIdle, new Action(this.NotifyRootMapChanged));
			}
		}

		private void ShowOscilloscope() {
			DialogOscilloscope dialog = new DialogOscilloscope(this);
			dialog.Owner = this.MainFrame;
			dialog.Show();
		}

		private void Run() {
			try {
				this.refreshing = false;
				this.MainFrame.Status = "Power On";
				this.rootMap = new CircuitMap(this.MainFrame.CircuitEditor.LogicalCircuit);
				this.CircuitState = this.rootMap.Apply(this.HistorySize);
				this.rootMap.CircuitRunner = this;
				this.VisibleMap = this.rootMap;
				this.NotifyRootMapChanged();
				if(this.Oscilloscoping && this.CircuitState.HasProbes) {
					Tracer.Assert(this.DialogOscilloscope == null);
					this.MainFrame.Dispatcher.Invoke(DispatcherPriority.Send, new Action(this.ShowOscilloscope));
				} else {
					this.Oscilloscoping = false;
				}

				this.rootMap.TurnOn();
				this.evaluationGate = new AutoResetEvent(false);
				this.refreshingGate = new AutoResetEvent(false);
				this.refreshingThread.Start();
				this.CircuitState.FunctionUpdated += new EventHandler(this.OnFunctionUpdated);
				int slownesCount = 0;
				int slownesMax = 2;
				bool notifyPerf = false;
				bool hasProbes = this.CircuitState.HasProbes;
				this.flipCount = 1;
				Stopwatch stopwatch = new Stopwatch();
				this.timer.Start();
				for(;;) {
					bool flipClock = (0 < this.flipCount);
					bool maxSpeed = this.MaxSpeed;
					if(!maxSpeed) {
						stopwatch.Reset();
						stopwatch.Start();
					}
					if(!this.CircuitState.Evaluate(maxSpeed || flipClock)) {
						break;
					}
					if(!this.refreshing) {
						this.refreshingGate.Set();
					}
					if(!maxSpeed) {
						if(this.timer.Period < stopwatch.Elapsed.TotalMilliseconds) {
							slownesCount++;
							if(slownesMax < slownesCount) {
								slownesCount = slownesMax;
								if(!notifyPerf) {
									notifyPerf = true;
									this.MainFrame.NotifyPerformance(true);
								}
							}
						} else {
							if(0 < slownesCount) {
								slownesCount--;
								if(slownesCount == 0) {
									notifyPerf = false;
									this.MainFrame.NotifyPerformance(false);
								}
							}
						}
					}
					if(this.Oscilloscoping) {
						if(flipClock && hasProbes) {
							foreach(FunctionProbe probe in this.CircuitState.Probes) {
								probe.Tick();
							}
						}
						if(this.Oscilloscope != null) {
							foreach(FunctionProbe probe in this.CircuitState.Probes) {
								this.Oscilloscope.Read(probe);
							}
							this.Oscilloscope = null;
						}
					}
					if(!maxSpeed && Interlocked.Decrement(ref this.flipCount) <= 0) {
						if(this.flipCount < 0) {
							this.flipCount = 0;
						}
						this.evaluationGate.WaitOne();
					}
				}
				MainFrame.ErrorMessage(Resources.Oscillation);
			} catch(ThreadAbortException) {
			} catch(Exception exception) {
				MainFrame.Report(exception);
			} finally {
				this.timer.Stop();
				try {
					if(this.refreshingGate != null) {
						this.refreshingGate.Close();
						this.refreshingGate = null;
					}
					if(this.evaluationGate != null) {
						this.evaluationGate.Close();
						this.evaluationGate = null;
					}
					this.refreshingThread = null;
					CircuitMap cache = this.rootMap;
					if(cache != null) {
						this.MainFrame.Dispatcher.BeginInvoke(DispatcherPriority.SystemIdle, new Action(() => cache.TurnOff()));
					}
					this.CircuitState = null;
					this.rootMap = null;
					this.NotifyRootMapChanged();
					this.evaluationThread = null;
					this.Oscilloscope = null;
					if(this.DialogOscilloscope != null) {
						this.DialogOscilloscope.Dispatcher.BeginInvoke(DispatcherPriority.SystemIdle,
							new Action(this.DialogOscilloscope.Close)
						);
					}
					this.MainFrame.Status = "Power Off";
					this.MainFrame.NotifyPerformance(false);
				} catch(ThreadAbortException) {
				} catch(Exception exception) {
					MainFrame.Report(exception);
				}
			}
		}

		private void TickSet() {
			if(!this.MaxSpeed) {
				AutoResetEvent e = this.evaluationGate;
				if(e != null) {
					Interlocked.Increment(ref this.flipCount);
					e.Set();
				}
			}
		}

		private void OnFunctionUpdated(object sender, EventArgs e) {
			if(sender == this.CircuitState) {
				try {
					this.evaluationGate.Set();
				} catch(ThreadAbortException) {
				} catch(Exception exception) {
					MainFrame.Report(exception);
				}
			}
		}

		private void MonitorUI() {
			try {
				while(this.refreshingGate != null && this.refreshingThread != null && this.evaluationThread != null) {
					this.refreshingGate.WaitOne();
					if(this.refreshingThread != null && this.evaluationThread != null && !this.refreshing) {
						this.refreshing = true;
						Thread.MemoryBarrier();
						this.MainFrame.Dispatcher.BeginInvoke(DispatcherPriority.SystemIdle, new Action(this.RefreshUI));
					}
				}
			} catch(ThreadAbortException) {
			} catch(Exception exception) {
				this.TurnOff();
				MainFrame.Report(exception);
			}
		}

		private void RefreshUI() {
			try {
				if(this.CircuitState != null) {
					IEnumerable<IFunctionVisual> invalidVisuals = this.CircuitState.InvalidVisuals();
					if(invalidVisuals != null) {
						foreach(IFunctionVisual function in invalidVisuals) {
							if(this.VisibleMap.IsVisible(function)) {
								function.Redraw();
							}
						}
					}
				}
			} catch(ThreadAbortException) {
			} catch(Exception exception) {
				MainFrame.Report(exception);
			} finally {
				this.refreshing = false;
				Thread.MemoryBarrier();
			}
		}
	}
}
