﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace LogicCircuit {
	public abstract class CircuitDescriptor {
		public string Category { get; protected set; }
		public FrameworkElement Glyph { get; protected set; }
		public virtual string Name { get; set; }

		public abstract Circuit Circuit(ProjectManager projectManager);

		protected static FrameworkElement CircuitGlyph(Circuit circuit) {
			FrameworkElement glyph = Plotter.CreateGlyph(circuit);
			VisualBrush brush = new VisualBrush(glyph);
			Rectangle rect = new Rectangle();
			rect.Width = glyph.Width;
			rect.Height = glyph.Height;
			rect.Fill = brush;
			rect.ToolTip = glyph.ToolTip;
			return rect;
		}

		protected List<int> PinRange(int min, int max) {
			List<int> range = new List<int>();
			if(min < max) {
				for(int i = min; i <= max; i++) {
					if(i <= 3 || (i & 1) != 0) {
						range.Add(i);
					}
				}
			} else {
				range.Add(min);
			}
			return range;
		}

		public static int[] BitRange(int minBitWidth) {
			Tracer.Assert(0 < minBitWidth && minBitWidth < BasePin.MaxBitWidth);
			int[] range = new int[BasePin.MaxBitWidth - minBitWidth + 1];
			for(int i = 0; i < range.Length; i++) {
				range[i] = i + minBitWidth;
			}
			return range;
		}

		public static int[] AddressBitRange() {
			int[] range = new int[Memory.MaxAddressBitWidth];
			for(int i = 0; i < range.Length; i++) {
				range[i] = i + 1;
			}
			return range;
		}
	}

	public class GateDescriptor : CircuitDescriptor {
		public int InputCount { get; set; }
		public IEnumerable<int> InputCountRange { get; private set; }
		public int InputCountRangeLength { get; private set; }
		private GateType GateType { get; set; }
		private bool InvertedOutput { get; set; }

		public GateDescriptor(GateStore store, GateType gateType, int minInput, int maxInput, bool invertedOutput) {
			Tracer.Assert(minInput <= maxInput);
			this.GateType = gateType;
			this.InputCount = minInput;
			List<int> range = this.PinRange(minInput, maxInput);
			this.InputCountRange = range.ToArray();
			this.InputCountRangeLength = range.Count;
			this.InvertedOutput = invertedOutput;

			Gate gate = store.Gate(gateType, minInput, invertedOutput);
			this.Glyph = CircuitDescriptor.CircuitGlyph(gate);
			if(invertedOutput && gateType != GateType.Not) {
				this.Name = Resources.NameNotGate(gate.Name);
			} else {
				this.Name = gate.Name;
			}
			if(gate.GateType == GateType.Led || gate.GateType == GateType.Clock || gate.GateType == GateType.Probe) {
				this.Category = Resources.CategoryInputOutput;
			} else if(gate.GateType == GateType.Even || gate.GateType == GateType.Odd) {
				this.Category = Resources.CategoryParity;
			} else if(gate.GateType == GateType.Not || gate.GateType == GateType.TriState) {
				this.Category = Resources.CategoryBuffer;
			} else {
				this.Category = gate.GateType.ToString();
			}
		}

		public override Circuit Circuit(ProjectManager projectManager) {
			return projectManager.GateStore.Gate(this.GateType, this.InputCount, this.InvertedOutput);
		}
	}

	public class ButtonDescriptor : CircuitDescriptor {
		public string Notation { get; set; }

		public ButtonDescriptor(ProjectManager projectManager) {
			Transaction transaction = projectManager.BeginTransaction();
			try {
				this.Glyph = CircuitDescriptor.CircuitGlyph(projectManager.CircuitButtonStore.Create());
			} finally {
				projectManager.EndTransaction(transaction, false);
			}
			this.Category = Resources.CategoryInputOutput;
			this.Name = Resources.NameButton;
			this.Notation = string.Empty;
		}

		public override Circuit Circuit(ProjectManager projectManager) {
			CircuitButton button = projectManager.CircuitButtonStore.Create();
			button.Notation = this.Notation;
			return button;
		}
	}

	public class ConstantDescriptor : CircuitDescriptor {
		public int BitWidth { get; set; }
		public string Value { get; set; }

		public IEnumerable<int> BitWidthRange { get; private set; }

		public ConstantDescriptor(ProjectManager projectManager) {
			Transaction transaction = projectManager.BeginTransaction();
			try {
				this.Glyph = CircuitDescriptor.CircuitGlyph(projectManager.ConstantStore.Create());
			} finally {
				projectManager.EndTransaction(transaction, false);
			}
			this.Category = Resources.CategoryInputOutput;
			this.Name = Resources.NameConstant;
			this.BitWidthRange = CircuitDescriptor.BitRange(1);
			this.BitWidth = 1;
			this.Value = Resources.Zero;
		}

		public override Circuit Circuit(ProjectManager projectManager) {
			Constant constant = projectManager.ConstantStore.Create();
			constant.BitWidth = this.BitWidth;
			int v;
			if(int.TryParse(this.Value, NumberStyles.HexNumber, Resources.Culture, out v)) {
				constant.Value = v;
			}
			return constant;
		}
	}

	public class MemoryDescriptor : CircuitDescriptor {
		private bool writable;
		public int AddressBitWidth { get; set; }
		public int DataBitWidth { get; set; }

		public IEnumerable<int> AddressBitWidthRange { get; private set; }
		public IEnumerable<int> DataBitWidthRange { get; private set; }

		public MemoryDescriptor(ProjectManager projectManager, bool writable) {
			this.writable = writable;
			Transaction transaction = projectManager.BeginTransaction();
			try {
				this.Glyph = CircuitDescriptor.CircuitGlyph(projectManager.MemoryStore.Create(this.writable, 4, 4));
			} finally {
				projectManager.EndTransaction(transaction, false);
			}
			this.Category = Resources.CategoryMemory;
			this.Name = this.writable ? Resources.RAMNotation : Resources.ROMNotation;
			this.AddressBitWidth = 1;
			this.AddressBitWidthRange = CircuitDescriptor.AddressBitRange();
			this.DataBitWidth = 1;
			this.DataBitWidthRange = CircuitDescriptor.BitRange(1);
		}

		public override Circuit Circuit(ProjectManager projectManager) {
			return projectManager.MemoryStore.Create(this.writable, this.AddressBitWidth, this.DataBitWidth);
		}
	}

	public class PinDescriptor : CircuitDescriptor {
		public int BitWidth { get; set; }
		private PinType PinType { get; set; }
		public PinSide PinSide { get; set; }

		public IEnumerable<int> BitWidthRange { get; private set; }
		public IEnumerable<PinSide> PinSideRange { get; set; }

		public PinDescriptor(ProjectManager projectManager, PinType pinType) {
			this.PinType = pinType;
			Transaction transaction = projectManager.BeginTransaction();
			try {
				this.Glyph = CircuitDescriptor.CircuitGlyph(projectManager.PinStore.Create(projectManager.ProjectStore.Project.LogicalCircuit, pinType, 1));
			} finally {
				projectManager.EndTransaction(transaction, false);
			}
			this.Category = Resources.CategoryInputOutput;
			this.Name = Resources.NamePin;
			this.BitWidth = 1;
			this.BitWidthRange = CircuitDescriptor.BitRange(1);
			this.PinSide = (pinType == PinType.Input) ? PinSide.Left : PinSide.Right;
			this.PinSideRange = (PinSide[])Enum.GetValues(typeof(PinSide));
		}

		public override Circuit Circuit(ProjectManager projectManager) {
			Pin pin = projectManager.PinStore.Create(projectManager.ProjectStore.Project.LogicalCircuit, this.PinType, this.BitWidth);
			pin.PinSide = this.PinSide;
			return pin;
		}
	}

	public class LogicalCircuitDescriptor : CircuitDescriptor {
		public LogicalCircuit LogicalCircuit { get; private set; }
		public bool IsCurrent {
			get { return this.LogicalCircuit.ProjectManager.ProjectStore.Project.LogicalCircuit == this.LogicalCircuit; }
		}

		public LogicalCircuitDescriptor(ProjectManager projectManager, LogicalCircuit logicalCircuit, Predicate<string> isReserved) {
			this.LogicalCircuit = logicalCircuit;
			this.Glyph = CircuitDescriptor.CircuitGlyph(this.LogicalCircuit);
			string category = logicalCircuit.Category;
			category = (
				string.IsNullOrEmpty(category)
				? Resources.CategoryProject(projectManager.ProjectStore.Project.Name)
				: category
			);
			if(isReserved(category)) {
				category = Resources.CategoryCustom(category);
			}
			this.Category = category;
			this.Name = this.LogicalCircuit.Name;
		}

		public override Circuit Circuit(ProjectManager projectManager) {
			return this.LogicalCircuit;
		}
	}

	public class SplitterDescriptor : CircuitDescriptor {
		public int BitWidth { get; set; }
		public int PinCount { get; set; }
		public CircuitRotation CircuitRotation { get; set; }

		public IEnumerable<int> BitWidthRange { get; private set; }
		public IEnumerable<int> PinCountRange { get; private set; }
		public IEnumerable<CircuitRotation> CircuitRotationRange { get; private set; }

		public SplitterDescriptor(ProjectManager projectManager) {
			this.BitWidth = 3;
			this.PinCount = 3;
			this.CircuitRotation = CircuitRotation.Left;
			Transaction transaction = projectManager.BeginTransaction();
			try {
				this.Glyph = CircuitDescriptor.CircuitGlyph(projectManager.SplitterStore.Create(this.BitWidth, this.PinCount, this.CircuitRotation));
			} finally {
				projectManager.EndTransaction(transaction, false);
			}
			this.Category = Resources.CategoryInputOutput;
			this.Name = Resources.NameSplitter;

			int[] bitRange = CircuitDescriptor.BitRange(2);
			this.BitWidthRange = bitRange;

			int[] pinRange = new int[Gate.MaxInputCount - 2];
			for(int i = 0; i < pinRange.Length; i++) {
				pinRange[i] = i + 2;
			}
			this.PinCountRange = pinRange;

			this.CircuitRotationRange = (CircuitRotation[])Enum.GetValues(typeof(CircuitRotation));
		}

		public override Circuit Circuit(ProjectManager projectManager) {
			if(this.BitWidth < this.PinCount) {
				throw new CircuitException(Cause.UserError, Resources.ErrorWrongSplitter);
			}
			Splitter splitter = projectManager.SplitterStore.Create(this.BitWidth, this.PinCount, this.CircuitRotation);
			return splitter;
		}
	}
}
