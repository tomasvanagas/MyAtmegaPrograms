﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace LogicCircuit {
	public class CircuitViewer {
		public Canvas Canvas { get; private set; }
		public ProjectManager ProjectManager { get; private set; }
		public LogicalCircuit LogicalCircuit {
			get { return this.ProjectManager.ProjectStore.Project.LogicalCircuit; }
			set { this.ProjectManager.ProjectStore.Project.LogicalCircuit = value; }
		}
		private HashSet<GridPoint> solder;

		public CircuitViewer(Canvas canvas, ProjectManager projectManager) {
			this.Canvas = canvas;
			this.ProjectManager = projectManager;
			this.solder = new HashSet<GridPoint>();
		}

		public void Redraw() {
			if(this.Canvas.Dispatcher.Thread != Thread.CurrentThread) {
				this.Canvas.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, new Action(this.RedrawDiagram));
			} else {
				this.RedrawDiagram();
			}
		}

		private void RedrawDiagram() {
			this.Canvas.Children.Clear();
			this.solder.Clear();
			foreach(Wire wire in this.LogicalCircuit.Wire) {
				Line line = wire.WireGlyph;
				Point p = Point.Add(Plotter.ScreenPoint(wire.Point1), new Vector(Plotter.PinRadius, Plotter.PinRadius));
				line.X1 = p.X;
				line.Y1 = p.Y;
				p = Point.Add(Plotter.ScreenPoint(wire.Point2), new Vector(Plotter.PinRadius, Plotter.PinRadius));
				line.X2 = p.X;
				line.Y2 = p.Y;
				this.Canvas.Children.Add(line);
				this.DrawSolder(wire.Point1);
				this.DrawSolder(wire.Point2);
			}
			foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
				Point point = Plotter.ScreenPoint(symbol.Point);
				Canvas.SetLeft(symbol.Glyph, point.X);
				Canvas.SetTop(symbol.Glyph, point.Y);
				this.Canvas.Children.Add(symbol.Glyph);
			}
		}

		private void DrawSolder(GridPoint point) {
			if(!this.solder.Contains(point)) {
				Wire wire = this.ProjectManager.WireStore.NeedSolder(this.LogicalCircuit, point);
				if(wire != null) {
					this.solder.Add(point);
					Ellipse ellipse = new Ellipse();
					ellipse.Tag = wire;
					ellipse.Width = ellipse.Height = 2 * Plotter.PinRadius;
					Canvas.SetLeft(ellipse, point.X * Plotter.GridSize);
					Canvas.SetTop(ellipse, point.Y * Plotter.GridSize);
					ellipse.Fill = Plotter.JamDirectFill;
					this.Canvas.Children.Add(ellipse);
				}
			}
		}
	}
}
