﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace LogicCircuit {
	partial class CircuitEditor {

		private Point startPoint;

		private bool awaitingArea = false;
		private MarkerArea markerArea;

		private Marker movingMarker;
		private MarkerPoint movingPoint;

		private Line wireLine;

		private void canvas_KeyDown(object sender, KeyEventArgs e) {
			try {
				if(this.InEditMode) {
					if(e.Key == Key.LeftCtrl || e.Key == Key.RightCtrl) {
						this.switcher.OnControlDown();
						this.GestureTip(Resources.TipOnCtrlDown);
						e.Handled = true;
					} else if(e.Key == Key.Tab) {
						this.switcher.OnTabDown(
							(Keyboard.Modifiers & ModifierKeys.Control) != ModifierKeys.None,
							(Keyboard.Modifiers & ModifierKeys.Shift) != ModifierKeys.None
						);
						e.Handled = true;
					} else if(e.Key == Key.Escape) {
						this.CancelAllMoves();
					}
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void canvas_KeyUp(object sender, KeyEventArgs e) {
			try {
				if(this.InEditMode && (e.Key == Key.LeftCtrl || e.Key == Key.RightCtrl)) {
					this.switcher.OnControlUp();
					e.Handled = true;
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void canvas_LostFocus(object sender, RoutedEventArgs e) {
			try {
				this.CancelAllMoves();
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void canvas_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) {
			try {
				this.CancelAllMoves();
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void canvas_MouseDown(object sender, MouseButtonEventArgs e) {
			if(e.ChangedButton == MouseButton.Left) {
				try {
					FrameworkElement element = e.OriginalSource as FrameworkElement;
					if(element != null) {
						if(this.InEditMode) {
							Point point = e.GetPosition(this.Canvas);
							FrameworkElement glyph = (element != this.Canvas) ? element : this.FindLineNear(point);
							if(glyph != null) {
								if(1 < e.ClickCount) {
									this.ElementDoubleClick(glyph, point);
								} else {
									this.ElementMouseDown(glyph, point);
								}
							} else {
								if(1 < e.ClickCount) {
									this.ClearSelection();
									this.Edit(this.LogicalCircuit);
								} else if(this.JamExistsNear(point)) {
									this.StartWire(point);
								} else {
									if(Keyboard.Modifiers != ModifierKeys.Shift) {
										this.ClearSelection();
									}
									this.startPoint = point;
									this.awaitingArea = true;
									this.GestureTip(Resources.TipOnAwaitingArea(this.LogicalCircuit.Name, Plotter.GridPoint(point)));
								}
							}
						} else { // In Run Mode
							FrameworkElement glyph = (element != this.Canvas) ? this.RootElement(element) : null;
							if(glyph != null) {
								CircuitSymbol symbol = glyph.Tag as CircuitSymbol;
								if(symbol != null) {
									if(1 < e.ClickCount) {
										this.RunningSymbolDoubleClick(symbol);
									} else {
										this.ShowStatus(symbol);
									}
								}
							}
						}
						e.Handled = true;
					}
				} catch(Exception exception) {
					MainFrame.Report(exception);
				}
			}
		}

		private void canvas_MouseUp(object sender, MouseButtonEventArgs e) {
			if(e.ChangedButton == MouseButton.Left && this.InEditMode) {
				try {
					if(this.movingMarker != null) {
						this.FinishMove(e.GetPosition(this.Canvas), (Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.None);
					} else if(this.movingPoint != null) {
						this.FinishMove(this.movingPoint, (Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.None);
					} else if(this.markerArea != null) {
						this.Select(this.markerArea.Area(e.GetPosition((Canvas)sender)));
						this.CancelAreaMarker();
					} else if(this.wireLine != null) {
						if(this.CreateWire() == null) { // special case wire was not created, select some wire.
							Point point = e.GetPosition(this.Canvas);
							FrameworkElement glyph = this.FindLineNear(point);
							FrameworkElement root = (glyph != null) ? this.RootElement(glyph) : null;
							Wire wire = (root != null) ? root.Tag as Wire : null;
							if(wire != null) {
								if(Keyboard.Modifiers == ModifierKeys.Control) {
									this.Select(wire);
								} else if(Keyboard.Modifiers == ModifierKeys.Shift) {
									this.ClearSelection();
									this.SelectConductor(wire);
								} else if(Keyboard.Modifiers == (ModifierKeys.Shift | ModifierKeys.Control)) {
									this.SelectConductor(wire);
								} else {
									this.ClearSelection();
									this.Select(wire);
									this.GestureTip(Resources.TipOnWireSelect);
								}
							}
						}
					} else {
						this.awaitingArea = false;
					}
				} catch(Exception exception) {
					MainFrame.Report(exception);
				}
			}
		}

		private void canvas_MouseMove(object sender, MouseEventArgs e) {
			if(this.InEditMode) {
				try {
					if(this.movingMarker != null) {
						this.Move(e.GetPosition(this.Canvas));
					} else if(this.movingPoint != null) {
						this.movingPoint.MoveTo(Plotter.GridPoint(e.GetPosition(this.Canvas)));
					} else if(this.wireLine != null) {
						Point point = CircuitEditor.WireEndPoint(e.GetPosition(this.Canvas));
						this.wireLine.X2 = point.X;
						this.wireLine.Y2 = point.Y;
					} else if(this.awaitingArea) {
						Point point = e.GetPosition((Canvas)sender);
						double x = point.X - this.startPoint.X;
						double y = point.Y - this.startPoint.Y;
						if(this.DragSize < x * x + y * y) {
							this.awaitingArea = false;
							this.StartAreaMarker(this.startPoint, point);
						}
					} else if(this.markerArea != null) {
						this.markerArea.MoveTo(e.GetPosition((Canvas)sender));
					}
				} catch(Exception exception) {
					MainFrame.Report(exception);
				}
			}
		}

		private void ElementMouseDown(FrameworkElement element, Point point) {
			FrameworkElement root = this.RootElement(element);
			Marker marker = root.Tag as Marker;
			if(marker == null) {
				Wire w = root.Tag as Wire;
				if(w != null) {
					marker = this.Marker(w);
				}
			}
			if(marker != null) {
				if(Keyboard.Modifiers == ModifierKeys.Shift && marker.Symbol is Wire) {
					Wire w = (Wire)marker.Symbol;
					this.ClearSelection();
					this.SelectConductor(w);
				} else if(Keyboard.Modifiers == (ModifierKeys.Shift | ModifierKeys.Control) && marker.Symbol is Wire) {
					this.UnselectConductor((Wire)marker.Symbol);
				} else if((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control) {
					this.Unselect(marker);
				} else if(Keyboard.Modifiers == ModifierKeys.Alt && marker.Symbol is Wire) {
					this.Split((Wire)marker.Symbol, Plotter.GridPoint(point));
				} else {
					this.StartMove(marker, point);
					this.GestureTip(Resources.TipOnStartMove);
				}
				return;
			}

			MarkerPoint markerPoint = element.Tag as MarkerPoint;
			if(markerPoint != null) {
				if(Keyboard.Modifiers == ModifierKeys.Control) {
					this.Unselect(markerPoint.Marker);
				} else if(Keyboard.Modifiers == ModifierKeys.Shift) {
					Wire w = (Wire)markerPoint.Marker.Symbol;
					this.ClearSelection();
					this.SelectConductor(w);
				} else if(Keyboard.Modifiers == (ModifierKeys.Shift | ModifierKeys.Control)) {
					this.UnselectConductor((Wire)markerPoint.Marker.Symbol);
				} else if(Keyboard.Modifiers == ModifierKeys.Alt) {
					if(this.SelectionCount == 2) {
						Wire wire1 = null;
						Wire wire2 = null;
						foreach(Symbol s in this.Selection()) {
							Wire w = s as Wire;
							if(w != null && (w.Point1 == markerPoint.Point || w.Point2 == markerPoint.Point)) {
								if(wire1 == null) {
									wire1 = w;
								} else {
									wire2 = w;
									break;
								}
							}
						}
						if(wire1 != null && wire2 != null) {
							this.Merge(wire1, wire2);
							return;
						} else {
							this.StartMove(markerPoint.Marker, point);
						}
					}
					this.GestureTip(Resources.TipOnNotMerge);
				} else if(this.SelectionCount == 1) {
					this.movingPoint = markerPoint;
					this.startPoint = point;
					this.GestureTip(Resources.TipOnStartMove);
				} else {
					this.StartMove(markerPoint.Marker, point);
					this.GestureTip(Resources.TipOnStartMove);
				}
				return;
			}

			Wire wire = root.Tag as Wire;
			if(wire != null) {
				if(Keyboard.Modifiers == ModifierKeys.Control) {
					this.Select(wire);
				} else if(Keyboard.Modifiers == ModifierKeys.Shift) {
					this.ClearSelection();
					this.SelectConductor(wire);
				} else if(Keyboard.Modifiers == (ModifierKeys.Shift | ModifierKeys.Control)) {
					this.SelectConductor(wire);
				} else if(CircuitEditor.IsPinClose(CircuitEditor.WireEndPoint(Plotter.ScreenPoint(wire.Point1)), point)) {
					this.StartWire(Plotter.ScreenPoint(wire.Point1));
				} else if(CircuitEditor.IsPinClose(CircuitEditor.WireEndPoint(Plotter.ScreenPoint(wire.Point2)), point)) {
					this.StartWire(Plotter.ScreenPoint(wire.Point2));
				} else {
					this.ClearSelection();
					this.StartMove(this.Select(wire), point);
					this.GestureTip(Resources.TipOnWireSelect);
				}
				return;
			}

			Jam jam = element.Tag as Jam;
			if(jam != null) {
				this.StartWire(point);
				return;
			}

			CircuitSymbol symbol = root.Tag as CircuitSymbol;
			if(symbol != null) {
				if((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control) {
					this.Select(symbol);
				} else {
					this.ClearSelection();
					this.StartMove(this.Select(symbol), point);
				}
				this.ShowStatus(symbol);
				return;
			}
		}

		private void ElementDoubleClick(FrameworkElement element, Point point) {
			FrameworkElement root = this.RootElement(element);
			Marker marker = (root != null) ? root.Tag as Marker : null;
			CircuitSymbol symbol = ((marker != null) ? marker.Symbol : root.Tag) as CircuitSymbol;
			if(symbol != null) {
				Pin pin = symbol.Circuit as Pin;
				if(pin != null) {
					this.Edit(pin);
					return;
				}
				CircuitButton button = symbol.Circuit as CircuitButton;
				if(button != null) {
					this.Edit(button);
					return;
				}
				LogicalCircuit logicalCircuit = symbol.Circuit as LogicalCircuit;
				if(logicalCircuit != null) {
					this.OpenLogicalCircuit(logicalCircuit);
					return;
				}
				Constant constant = symbol.Circuit as Constant;
				if(constant != null) {
					this.Edit(constant);
					return;
				}
				Memory memory = symbol.Circuit as Memory;
				if(memory != null) {
					this.Edit(memory);
					return;
				}
				this.GestureTip(Resources.TipOnNotDoubleClick);
			}
			Wire wire = ((marker != null) ? marker.Symbol : root.Tag) as Wire;
			if(wire != null) {
				this.GestureTip(Resources.TipOnWireDoubleClick);
			}
		}

		private void RunningSymbolDoubleClick(CircuitSymbol symbol) {
			CircuitMap map = this.MainFrame.CircuitRunner.VisibleMap.Child(symbol);
			if(map != null) {
				this.OpenLogicalCircuit(map);
				return;
			}
			Gate gate = symbol.Circuit as Gate;
			if(gate != null && gate.GateType == GateType.Probe) {
				this.ShowFunctionProbe(this.MainFrame.CircuitRunner.VisibleMap.FunctionProbe(symbol));
				return;
			}
			Memory memory = symbol.Circuit as Memory;
			if(memory != null) {
				this.ShowFunctionMemory(this.MainFrame.CircuitRunner.VisibleMap.FunctionMemory(symbol));
				return;
			}
		}

		private void CancelAllMoves() {
			this.CancelWire();
			this.CancelAreaMarker();
			this.CancelMarkerMove();
			this.CancelMarkerPointMove();
		}

		private void StartAreaMarker(Point start, Point end) {
			if(this.markerArea == null) {
				this.Canvas.CaptureMouse();
				this.markerArea = new MarkerArea(this.Canvas, start, end);
			}
		}

		private void CancelAreaMarker() {
			if(this.markerArea != null) {
				this.markerArea.Delete();
				this.markerArea = null;
				this.Canvas.ReleaseMouseCapture();
			}
		}

		private void StartMove(Marker marker, Point position) {
			this.movingMarker = marker;
			this.startPoint = position;
		}

		private void Move(Point position) {
			double x = position.X - this.startPoint.X;
			double y = position.Y - this.startPoint.Y;
			foreach(Marker marker in this.selection.Values) {
				marker.Move(x, y);
			}
			this.startPoint = position;
		}

		private void FinishMove(Point position, bool withWires) {
			this.Move(position);
			Transaction transaction = this.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				if(withWires) {
					Dictionary<GridPoint, Jam> jams = new Dictionary<GridPoint, Jam>();
					Dictionary<GridPoint, Wire> wire1 = new Dictionary<GridPoint, Wire>();
					Dictionary<GridPoint, Wire> wire2 = new Dictionary<GridPoint, Wire>();
					foreach(Marker marker in this.selection.Values) {
						CircuitSymbol symbol = marker.Symbol as CircuitSymbol;
						if(symbol != null) {
							foreach(Jam jam in this.ProjectManager.JamStore.Select(symbol)) {
								GridPoint point = jam.AbsolutePoint;
								if(!jams.ContainsKey(point)) {
									jams.Add(point, jam);
								}
								wire1.Remove(point);
								wire2.Remove(point);
							}
						} else {
							if(!jams.ContainsKey(marker.Point1.Point) && !wire1.ContainsKey(marker.Point1.Point)) {
								wire1.Add(marker.Point1.Point, (Wire)marker.Symbol);
							}
							if(!jams.ContainsKey(marker.Point2.Point) && !wire2.ContainsKey(marker.Point2.Point)) {
								wire2.Add(marker.Point2.Point, (Wire)marker.Symbol);
							}
						}
						marker.Commit();
					}
					foreach(Wire wire in this.LogicalCircuit.Wire) {
						if(!this.selection.ContainsKey(wire)) {
							Jam jam;
							if(jams.TryGetValue(wire.Point1, out jam)) {
								wire.Point1 = jam.AbsolutePoint;
							} else {
								Wire w;
								if(wire1.TryGetValue(wire.Point1, out w)) {
									if(!this.JamExistsNear(wire.Point1)) {
										wire.Point1 = w.Point1;
									}
								} else if(wire2.TryGetValue(wire.Point1, out w)) {
									if(!this.JamExistsNear(wire.Point1)) {
										wire.Point1 = w.Point2;
									}
								}
							}
							if(jams.TryGetValue(wire.Point2, out jam)) {
								wire.Point2 = jam.AbsolutePoint;
							} else {
								Wire w;
								if(wire1.TryGetValue(wire.Point2, out w)) {
									if(!this.JamExistsNear(wire.Point2)) {
										wire.Point2 = w.Point1;
									}
								} else if(wire2.TryGetValue(wire.Point2, out w)) {
									if(!this.JamExistsNear(wire.Point2)) {
										wire.Point2 = w.Point2;
									}
								}
							}
						}
					}
				} else {
					foreach(Marker marker in this.selection.Values) {
						marker.Commit();
					}
				}
				this.DeleteEmptyWires();
				success = true;
			} finally {
				this.ProjectManager.EndTransaction(transaction, success);
			}
			this.CancelMarkerMove();
		}

		private void CancelMarkerMove() {
			if(this.movingMarker != null) {
				this.movingMarker = null;
				IEnumerable<Symbol> selection = this.Selection();
				this.ClearSelection();
				this.Redraw();
				this.Select(selection);
			}
		}

		private void FinishMove(MarkerPoint markerPoint, bool withWires) {
			Marker marker = markerPoint.Marker;
			Wire wire = (Wire)marker.Symbol;
			Transaction transaction = this.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				if(withWires) {
					GridPoint old = (marker.Point1 == markerPoint) ? wire.Point1 : wire.Point2;
					if(!this.JamExistsNear(old)) {
						foreach(Wire w in this.LogicalCircuit.Wire) {
							if(w.Point1 == old) {
								w.Point1 = markerPoint.Point;
							} else if(w.Point2 == old) {
								w.Point2 = markerPoint.Point;
							}
						}
					}
				}
				wire.Point1 = marker.Point1.Point;
				wire.Point2 = marker.Point2.Point;
				this.DeleteEmptyWires();
				success = true;
			} finally {
				this.ProjectManager.EndTransaction(transaction, success);
			}
			this.CancelMarkerPointMove();
		}

		private void CancelMarkerPointMove() {
			if(this.movingPoint != null) {
				this.movingPoint = null;
				IEnumerable<Symbol> selection = this.Selection();
				this.ClearSelection();
				this.Redraw();
				this.Select(selection);
			}
		}

		private void StartWire(Point point) {
			this.ClearSelection();
			this.CancelWire();
			this.wireLine = new Line();
			this.wireLine.Stroke = Brushes.Black;
			this.wireLine.StrokeThickness = 1;
			Canvas.SetZIndex(this.wireLine, int.MaxValue);
			this.Canvas.Children.Add(this.wireLine);
			Point p = CircuitEditor.WireEndPoint(point);
			this.wireLine.X1 = this.wireLine.X2 = p.X;
			this.wireLine.Y1 = this.wireLine.Y2 = p.Y;
			this.GestureTip(Resources.TipOnStartWire);
		}

		private void CancelWire() {
			if(this.wireLine != null) {
				this.Canvas.Children.Remove(this.wireLine);
				this.wireLine = null;
			}
		}

		private Wire CreateWire() {
			this.ClearSelection();
			GridPoint p1 = Plotter.GridPoint(new Point(this.wireLine.X1, this.wireLine.Y1));
			GridPoint p2 = Plotter.GridPoint(new Point(this.wireLine.X2, this.wireLine.Y2));
			Wire wire = null;
			if(p1 != p2) {
				Transaction transaction = this.ProjectManager.BeginTransaction();
				bool success = false;
				try {
					wire = this.ProjectManager.WireStore.Create(this.LogicalCircuit, p1, p2);
					success = true;
				} finally {
					this.ProjectManager.EndTransaction(transaction, success);
				}
			}
			this.CancelWire();
			if(wire != null) {
				this.Redraw();
			}
			return wire;
		}

		private void DeleteEmptyWires() {
			foreach(Wire wire in this.LogicalCircuit.Wire) {
				if(wire.Point1 == wire.Point2) {
					Marker marker = this.Marker(wire);
					if(marker != null) {
						this.Unselect(marker);
					}
					wire.Delete();
				}
			}
		}

		private void GestureTip(string tip) {
			this.MainFrame.Status = tip;
		}
	}
}
