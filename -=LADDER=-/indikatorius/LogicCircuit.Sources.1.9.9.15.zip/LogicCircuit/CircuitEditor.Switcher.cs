﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	partial class CircuitEditor {
		private class Switcher {
			public CircuitEditor CircuitEditor { get; private set; }
			private List<LogicalCircuit> history = new List<LogicalCircuit>();
			private int tab = 0;

			public Switcher(CircuitEditor circuitEditor) {
				this.CircuitEditor = circuitEditor;
				LogicalCircuit active = this.CircuitEditor.LogicalCircuit;
				Tracer.Assert(active != null);
				foreach(LogicalCircuit logicalCircuit in this.CircuitEditor.ProjectManager.LogicalCircuitStore) {
					if(logicalCircuit != active) {
						this.history.Add(logicalCircuit);
					}
				}
				this.history.Add(active);
				this.CircuitEditor.ProjectManager.ProjectStore.StoreChanged += new EventHandler(this.ProjectStore_StoreChanged);
				this.CircuitEditor.ProjectManager.LogicalCircuitStore.ItemChanged += new ItemStore<LogicalCircuit>.ItemChangedEventHandler(this.LogicalCircuitStore_ItemChanged);
			}

			public void OnControlDown() {
				this.tab = 0;
			}

			public void OnControlUp() {
				this.tab = 0;
				LogicalCircuit logicalCircuit = this.CircuitEditor.LogicalCircuit;
				if(logicalCircuit != this.history[this.history.Count - 1]) {
					this.history.Remove(logicalCircuit);
					this.history.Add(logicalCircuit);
				}
			}

			public void OnTabDown(bool control, bool shift) {
				if(control && this.history.Count > 1) {
					int count = this.history.Count;
					int i = ++this.tab % count;
					if(!shift) {
						i = count - i - 1;
					}
					this.CircuitEditor.OpenLogicalCircuit(this.history[i]);
				} else {
					this.tab = 0;
				}
			}

			public LogicalCircuit SuggestNext() {
				return (1 < this.history.Count) ? this.history[this.history.Count - 2] : null;
			}

			private void ProjectStore_StoreChanged(object sender, EventArgs e) {
				if(this.tab == 0) {
					this.OnControlUp();
				}
			}

			private void LogicalCircuitStore_ItemChanged(LogicalCircuit item, ItemAction action) {
				this.tab = 0;
				if(action == ItemAction.Created) {
					this.history.Insert(0, item);
				} else if(action == ItemAction.Deleted) {
					this.history.Remove(item);
				}
			}
		}
	}
}
