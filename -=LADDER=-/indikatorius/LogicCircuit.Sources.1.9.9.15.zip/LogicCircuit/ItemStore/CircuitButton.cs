﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class CircuitButton : Circuit {

		public static int notation;

		protected CircuitButton(Store.Table.Row row) : base(row) {
			if(CircuitButton.notation == 0) {
				Store.Table table = row.Table;
				CircuitButton.notation = table.ColumnOrdinal("Notation");
			}
		}

		public override string Notation {
			get { return this.Row[CircuitButton.notation].ToString(); }
			set { this.Row[CircuitButton.notation] = value; }
		}

		public override string ToolTip { get { return Resources.ToolTipButton(this.Notation).Trim(); } }
	}
}
