﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class Splitter : Circuit {

		private static int bitWidth;
		private static int pinCount;
		private static int rotation;

		protected Splitter(Store.Table.Row row) : base(row) {
			if(Splitter.bitWidth == 0) {
				Store.Table table = row.Table;
				Splitter.bitWidth = table.ColumnOrdinal("BitWidth");
				Splitter.pinCount = table.ColumnOrdinal("PinCount");
				Splitter.rotation = table.ColumnOrdinal("Rotation");
			}
			this.circuitRotation = new EnumValue<CircuitRotation>(row, Splitter.rotation);
		}

		public int BitWidth {
			get { return BasePin.NormalizeBitWidth((int)this.Row[Splitter.bitWidth]); }
			set { this.Row[Splitter.bitWidth] = BasePin.NormalizeBitWidth(value); }
		}

		private int NormalizePinCount(int count) {
			return Math.Max(1, Math.Min(count, this.BitWidth));
		}

		public int PinCount {
			get { return this.NormalizePinCount((int)this.Row[Splitter.pinCount]); }
			set { this.Row[Splitter.pinCount] = this.NormalizePinCount(value); }
		}

		private EnumValue<CircuitRotation> circuitRotation;
		public CircuitRotation Rotation {
			get { return this.circuitRotation.Value; }
			set { this.circuitRotation.Value = value; }
		}

		public override string ToolTip {
			get { return Resources.ToolTipSplitter(this.BitWidth, this.PinCount); }
		}

		public override string Notation {
			get { return Resources.SplitterNotation(this.BitWidth, this.PinCount); }
			set { throw new InvalidOperationException(); }
		}
	}
}
