﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class GateStore : CircuitStore<Gate> {

		public GateStore(ProjectManager projectManager, Store.Table table, DevicePinStore devicePinStore) : base(projectManager, table) {
			this.Generate(devicePinStore);
		}

		protected override Gate CreateItem(Store.Table.Row row) {
			return new GateItem(row);
		}

		private class GateItem : Gate {
			public GateItem(Store.Table.Row row) : base(row) {}
		}

		public static bool IsValid(GateType gateType) {
			return Enum.IsDefined(typeof(GateType), gateType);
		}

		public static bool IsValid(GateType gateType, int inputCount) {
			Tracer.Assert(GateStore.IsValid(gateType));
			switch(gateType) {
			case GateType.NOP:
			case GateType.Clock:
				return inputCount == 0;
			case GateType.Not:
				return inputCount == 1;
			case GateType.Or:
			case GateType.And:
			case GateType.Xor:
			case GateType.Odd:
			case GateType.Even:
				return 1 < inputCount && inputCount <= LogicCircuit.Gate.MaxInputCount;
			case GateType.Led:
				return inputCount == 1 || inputCount == 8;
			case GateType.Probe:
				return inputCount == 1;
			case GateType.TriState:
				return inputCount == 2;
			default:
				return false;
			}
		}

		public static bool HasOutput(GateType gateType) {
			Tracer.Assert(GateStore.IsValid(gateType));
			return gateType != GateType.NOP && gateType != GateType.Led && gateType != GateType.Probe;
		}

		public Gate Gate(GateType gateType, int inputCount, bool invertedOutput) {
			if(!GateStore.IsValid(gateType)) {
				throw new ArgumentOutOfRangeException("gateType");
			}
			if(!GateStore.IsValid(gateType, inputCount)) {
				throw new ArgumentOutOfRangeException("inputCount");
			}
			return this.Find(GateStore.GateGuid(gateType, inputCount, invertedOutput));
		}

		private static Guid GateGuid(GateType gateType, int inputCount, bool ivertedOutput) {
			Tracer.Assert(gateType != GateType.NOP && GateStore.IsValid(gateType, inputCount));
			return new Guid(0, 0, 0, 0, 0, 0, 0, 0,
				(byte)(int)gateType,
				(byte)inputCount,
				(byte)(ivertedOutput ? 1 : 0)
			);
		}

		private Gate Create(GateType gateType, int inputCount, bool invertedOutput) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = GateStore.GateGuid(gateType, inputCount, invertedOutput);
			Gate gate = this.CreateItem(row);
			gate.GateType = gateType;
			row.Add();
			return gate;
		}

		private Gate Generate(DevicePinStore devicePinStore, GateType gateType, int inputCount, bool invertedOutput) {
			Gate gate = this.Create(gateType, inputCount, invertedOutput);
			for(int i = 0; i < inputCount; i++) {
				DevicePin pin = devicePinStore.Create(gate, PinType.Input, 1);
				pin.Name = Resources.PinName(Resources.PinInName, i + 1);
			}
			if(GateStore.HasOutput(gateType)) {
				DevicePin pin = devicePinStore.Create(gate, PinType.Output, 1);
				pin.Inverted = invertedOutput;
				pin.Name = Resources.PinOutName;
			}
			return gate;
		}

		private void Generate(DevicePinStore devicePinStore, GateType gateType) {
			for(int i = 2; i <= LogicCircuit.Gate.MaxInputCount; i++) {
				this.Generate(devicePinStore, gateType, i, false);
				if(gateType != GateType.Even && gateType != GateType.Odd) {
					this.Generate(devicePinStore, gateType, i, true);
				}
			}
		}

		private Gate GenerateSevenSegmentIndicator(DevicePinStore devicePinStore) {
			Gate gate = this.Create(GateType.Led, 8, false);
			string prefix = "Led7Pin";
			int name = 1;
			for(int i = 0; i < 4; i++) {
				DevicePin pin = devicePinStore.Create(gate, PinType.Input, 1);
				pin.Name = Resources.ResourceManager.GetString(prefix + name);
				name++;
			}
			for(int i = 0; i < 3; i++) {
				DevicePin pin = devicePinStore.Create(gate, PinType.Input, 1);
				pin.Name = Resources.ResourceManager.GetString(prefix + name);
				pin.PinSide = PinSide.Right;
				name++;
			}
			DevicePin pinDot = devicePinStore.Create(gate, PinType.Input, 1);
			pinDot.Name = Resources.ResourceManager.GetString(prefix + name);
			pinDot.PinSide = PinSide.Right;
			return gate;
		}

		private Gate GenerateTriState(DevicePinStore devicePinStore, bool invertedOutput) {
			Gate gate = this.Create(GateType.TriState, 2, invertedOutput);
			DevicePin pinX = devicePinStore.Create(gate, PinType.Input, 1);
			pinX.Name = Resources.PinInName;
			DevicePin pinE = devicePinStore.Create(gate, PinType.Input, 1);
			pinE.Name = Resources.PinEnableName;
			pinE.PinSide = PinSide.Bottom;
			DevicePin pin = devicePinStore.Create(gate, PinType.Output, 1);
			pin.Inverted = invertedOutput;
			pin.Name = Resources.PinOutName;
			return gate;
		}

		private void Generate(DevicePinStore devicePinStore) {
			Tracer.Assert(this.Count == 0);
			this.Generate(devicePinStore, GateType.Clock, 0, false);
			this.Generate(devicePinStore, GateType.Not, 1, true);
			this.Generate(devicePinStore, GateType.Or);
			this.Generate(devicePinStore, GateType.And);
			this.Generate(devicePinStore, GateType.Xor);
			this.Generate(devicePinStore, GateType.Odd);
			this.Generate(devicePinStore, GateType.Even);
			this.Generate(devicePinStore, GateType.Led, 1, false);
			this.GenerateSevenSegmentIndicator(devicePinStore);
			this.Generate(devicePinStore, GateType.Probe, 1, false);
			this.GenerateTriState(devicePinStore, false);
		}
	}
}
