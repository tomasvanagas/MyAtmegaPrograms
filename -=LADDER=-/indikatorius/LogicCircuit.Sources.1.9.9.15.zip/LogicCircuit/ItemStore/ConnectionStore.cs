﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class ConnectionStore : ItemStore<Connection> {

		private static int inJam;
		private static int outJam;

		public ConnectionStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {
			if(ConnectionStore.inJam == 0) {
				ConnectionStore.inJam = table.ColumnOrdinal("InJamId");
				ConnectionStore.outJam = table.ColumnOrdinal("OutJamId");
			}
		}

		protected override Connection CreateItem(Store.Table.Row row) {
			return new ConnectionItem(row);
		}

		private Connection Create(Jam inJam, Jam outJam) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			Connection connection = new ConnectionItem(row);
			connection.InJam = inJam;
			connection.OutJam = outJam;
			row.Add();
			return connection;
		}

		public Connection Connect(Jam inJam, Jam outJam) {
			Connection connection = this.Select(inJam, outJam);
			if(connection == null) {
				return this.Create(inJam, outJam);
			}
			return connection;
		}

		public Connection Select(Jam inJam, Jam outJam) {
			Connection[] list = this.Select(ConnectionStore.inJam, inJam.Guid, ConnectionStore.outJam, outJam.Guid);
			if(list != null && 0 < list.Length) {
				return list[0];
			}
			return null;
		}

		public Connection[] SelectByInput(Jam inputJam) {
			return this.Select(ConnectionStore.inJam, inputJam.Guid);
		}

		public Connection[] SelectByOutput(Jam outputJam) {
			return this.Select(ConnectionStore.outJam, outputJam.Guid);
		}

		private class ConnectionItem : Connection {
			public ConnectionItem(Store.Table.Row row) : base(row) {}
		}
	}
}
