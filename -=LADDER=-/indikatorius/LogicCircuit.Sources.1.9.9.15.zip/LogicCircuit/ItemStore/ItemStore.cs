﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace LogicCircuit {

	/// <summary>
	/// Describes the action performed on item
	/// </summary>
	public enum ItemAction {
		/// <summary>
		/// The item has been created
		/// </summary>
		Created,
		/// <summary>
		/// The item has been changed
		/// </summary>
		Changed,
		/// <summary>
		/// The item has been deleted
		/// </summary>
		Deleted
	}

	public abstract class ItemStore<TItem> : IEnumerable<TItem>
		where TItem:Item
	{
		public delegate void ItemChangedEventHandler(TItem item, ItemAction action);
		public event EventHandler StoreChanged;
		/// <summary>
		/// Occurs when Item is changed in one of the ways described by <see cref="ItemAction"/>
		/// </summary>
		public event ItemChangedEventHandler ItemChanged;

		public ProjectManager ProjectManager { get; private set; }

		private Store.Table table;
		protected Store.Table Table { get { return this.table; } }

		protected ItemStore(ProjectManager projectManager, Store.Table table) {
			this.ProjectManager = projectManager;
			this.table = table;
			this.table.Tag = this;
			Tracer.Assert(
				this.table.PrimaryKey.Length == 1 &&
				this.table.PrimaryKey[0].Ordinal == 0 &&
				this.table.TableColumn(0).Type == typeof(Guid)
			);
			this.InitFromTable();
			this.table.TableChanged += new Store.TableChangedEventHandler(this.Table_TableChanged);
		}

		/// <summary>
		/// Creates the item from the row
		/// </summary>
		/// <param name="row">row that holds item's data</param>
		protected abstract TItem CreateItem(Store.Table.Row row);

		private void InitFromTable() {
			foreach(Store.Table.Row row in this.table) {
				if(row.Tag == null) {
					this.CreateItem(row);
				}
			}
		}

		private bool locked;
		public void Lock() {
			this.locked = true;
		}

		private void Table_TableChanged(Store.RowAction action, Store.Table.Row row, object[] old) {
			if(this.locked) {
				Tracer.Fail("Attempt to change locked table");
			}
			if(action == Store.RowAction.Added && row.Tag == null) {
				this.CreateItem(row);
			}
			if(this.ItemChanged != null) {
				this.ItemChanged((TItem)row.Tag, (ItemAction)((int)action));
			}
			if(this.StoreChanged != null) {
				this.StoreChanged(this, EventArgs.Empty);
			}
		}

		private class Enumerator : IEnumerator<TItem> {
			private IEnumerator<Store.Table.Row> rowEnumerator;
			public Enumerator(Store.Table table) {
				this.rowEnumerator = table.GetEnumerator();
			}
			public TItem Current {
				get { return (TItem)this.rowEnumerator.Current.Tag; }
			}
			public void Dispose() {
				this.rowEnumerator.Dispose();
			}
			object System.Collections.IEnumerator.Current {
				get { return this.rowEnumerator.Current.Tag; }
			}
			public bool MoveNext() {
				return this.rowEnumerator.MoveNext();
			}
			public void Reset() {
				this.rowEnumerator.Reset();
			}
		}

		public IEnumerator<TItem> GetEnumerator() {
			return new Enumerator(this.table);
		}

		System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() {
			return this.GetEnumerator();
		}

		public int Count { get { return this.table.Count; } }

		public TItem this[int index] { get { return (TItem)this.table[index].Tag; } }

		public TItem Find(Guid guid) {
			Store.Table.Row row = this.table.Select(guid);
			if(row != null) {
				return (TItem)row.Tag;
			}
			return null;
		}

		private static TItem[] Select(Store.Table.Row[] row) {
			if(row == null) {
				return new TItem[0];
			} else {
				TItem[] item = new TItem[row.Length];
				for(int i = 0; i < row.Length; i++) {
					item[i] = (TItem)row[i].Tag;
				}
				return item;
			}
		}

		protected TItem[] Select(int columnOrdinal, object value) {
			return ItemStore<TItem>.Select(this.table.Select(columnOrdinal, value));
		}
		protected TItem[] Select(int columnOrdinal, object value, int sortColumn) {
			return ItemStore<TItem>.Select(this.table.Select(columnOrdinal, value, sortColumn));
		}
		protected TItem[] Select(int column1Ordinal, object value1, int column2Ordinal, object value2) {
			return ItemStore<TItem>.Select(this.table.Select(column1Ordinal, value1, column2Ordinal, value2));
		}
		protected TItem[] Select(int column1Ordinal, object value1, int column2Ordinal, object value2, int sortColumn) {
			return ItemStore<TItem>.Select(this.table.Select(column1Ordinal, value1, column2Ordinal, value2, sortColumn));
		}
		protected TItem[] SelectOr(int column1Ordinal, object value1, int column2Ordinal, object value2) {
			return ItemStore<TItem>.Select(this.table.SelectOr(column1Ordinal, value1, column2Ordinal, value2));
		}

		public string UniqueName(string prefix) {
			string uniqueName = prefix;
			int order = 1;
			int name = this.Table.ColumnOrdinal("Name");
			while(this.Table.Exists(name, uniqueName)) {
				uniqueName = prefix + order++;
			}
			return uniqueName;
		}

		public string UniqueName(string prefix, int groupColumn, object groupValue) {
			string uniqueName = prefix;
			int order = 1;
			int name = this.Table.ColumnOrdinal("Name");
			while(this.Table.Exists(name, uniqueName, groupColumn, groupValue)) {
				uniqueName = prefix + order++;
			}
			return uniqueName;
		}
	}
}
