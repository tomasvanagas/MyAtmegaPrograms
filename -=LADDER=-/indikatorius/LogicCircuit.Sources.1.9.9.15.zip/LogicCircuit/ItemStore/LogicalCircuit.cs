﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace LogicCircuit {
	public abstract class LogicalCircuit : Circuit {

		private static int name;
		private static int description;
		private static int notation;
		private static int category;

		protected LogicalCircuit(Store.Table.Row row) : base(row) {
			if(LogicalCircuit.name == 0) {
				Store.Table table = row.Table;
				LogicalCircuit.name = table.ColumnOrdinal("Name");
				LogicalCircuit.notation = table.ColumnOrdinal("Notation");
				LogicalCircuit.description = table.ColumnOrdinal("Description");
				LogicalCircuit.category = table.ColumnOrdinal("Category");
			}
		}

		public override string Name {
			get { return this.Row[LogicalCircuit.name].ToString(); }
			set { this.Row[LogicalCircuit.name] = value; }
		}

		public void Rename(string name) {
			if(this.Row.Table.TableColumn(LogicalCircuit.name).Comparer.Compare(this.Row, name) != 0) {
				this.Name = this.ProjectManager.LogicalCircuitStore.UniqueName(name);
			}
		}

		public override string ToolTip {
			get {
				string d = this.Description;
				if(!string.IsNullOrEmpty(d)) {
					return this.Name + "\n" + d;
				}
				return this.Name;
			}
		}

		public override string Notation {
			get {
				string n = this.Row[LogicalCircuit.notation].ToString();
				if(string.IsNullOrEmpty(n)) {
					return this.Name;
				}
				return n;
			}
			set { this.Row[LogicalCircuit.notation] = value; }
		}

		public string Description {
			get { return this.Row[LogicalCircuit.description].ToString(); }
			set { this.Row[LogicalCircuit.description] = value; }
		}

		public string Category {
			get { return this.Row[LogicalCircuit.category].ToString(); }
			set { this.Row[LogicalCircuit.category] = value; }
		}

		public IEnumerable<CircuitSymbol> CircuitSymbol {
			get { return this.ProjectManager.CircuitSymbolStore.Select(this); }
		}

		public IEnumerable<Wire> Wire {
			get { return this.ProjectManager.WireStore.Select(this); }
		}

		public bool IsEmpty {
			get { return !this.ProjectManager.CircuitSymbolStore.ExistOn(this) && !this.ProjectManager.WireStore.ExistOn(this); }
		}

		public override int InputCount {
			get { return this.ProjectManager.PinStore.Select(this, PinType.Input).Length; }
		}
		public override BasePin Input(int index) {
			return this.ProjectManager.PinStore.Select(this, PinType.Input)[index];
		}

		public override int OutputCount {
			get { return this.ProjectManager.PinStore.Select(this, PinType.Output).Length; }
		}
		public override BasePin Output(int index) {
			return this.ProjectManager.PinStore.Select(this, PinType.Output)[index];
		}

		public override bool Copy(Store store, bool deepCopy) {
			if(base.Copy(store, false) && deepCopy) {
				foreach(CircuitSymbol symbol in this.CircuitSymbol) {
					bool done = symbol.Copy(store, deepCopy);
					Tracer.Assert(done);
				}
				foreach(Wire wire in this.Wire) {
					bool done = wire.Copy(store, deepCopy);
					Tracer.Assert(done);
				}
				return true;
			}
			return false;
		}

		public bool Connected { get; set; }

		public Point ScrollOffset { get; set; }
	}
}
