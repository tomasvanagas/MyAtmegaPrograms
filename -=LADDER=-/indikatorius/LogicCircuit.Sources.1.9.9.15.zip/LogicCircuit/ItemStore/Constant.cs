﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class Constant : Circuit {

		private static int bitWidth;
		private static int value;

		protected Constant(Store.Table.Row row) : base(row) {
			if(Constant.value == 0) {
				Store.Table table = row.Table;
				Constant.bitWidth = table.ColumnOrdinal("BitWidth");
				Constant.value = table.ColumnOrdinal("Value");
			}
		}

		public int BitWidth {
			get { return BasePin.NormalizeBitWidth((int)this.Row[Constant.bitWidth]); }
			set {
				int width = BasePin.NormalizeBitWidth(value);
				this.Row[Constant.bitWidth] = width;
				DevicePin[] pin = this.ProjectManager.DevicePinStore.Select(this);
				Tracer.Assert(pin != null && pin.Length == 1 && pin[0] != null);
				pin[0].BitWidth = width;
				this.Value = this.Value; //this will normalize the value
			}
		}

		public static int Normalize(int value, int bitWidth) {
			bitWidth = BasePin.NormalizeBitWidth(bitWidth);
			if(bitWidth < 32) {
				return value & ((1 << bitWidth) - 1);
			}
			return value;
		}

		public int Value {
			get { return Constant.Normalize((int)this.Row[Constant.value], this.BitWidth); }
			set { this.Row[Constant.value] = Constant.Normalize(value, this.BitWidth); }
		}

		public State this[int index] {
			get {
				Tracer.Assert(0 <= index && index < 32);
				return (this.Value & 1 << index) == 0 ? State.On0 : State.On1;
			}
			set {
				Tracer.Assert(0 <= index && index < 32);
				Tracer.Assert(value == State.On0 || value == State.On1);
				if(value == State.On1) {
					this.Value = this.Value | 1 << index;
				} else {
					this.Value = this.Value & ~(1 << index);
				}
			}
		}

		public override string ToolTip {
			get { return Resources.ToolTipConstant(this.BitWidth, this.Value); }
		}

		public override string Notation {
			get { return string.Format(Resources.Culture, "{0:X}", this.Value); }
			set { throw new InvalidOperationException(); }
		}
	}
}
