﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class LogicalCircuitStore : CircuitStore<LogicalCircuit> {

		private static int name;
		private static int description;
		private static int notation;
		private static int category;

		public LogicalCircuitStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {
			if(LogicalCircuitStore.name == 0) {
				LogicalCircuitStore.name = table.ColumnOrdinal("Name");
				LogicalCircuitStore.notation = table.ColumnOrdinal("Notation");
				LogicalCircuitStore.description = table.ColumnOrdinal("Description");
				LogicalCircuitStore.category = table.ColumnOrdinal("Category");
			}
		}

		protected override LogicalCircuit CreateItem(Store.Table.Row row) {
			return new LogicalCircuitItem(row);
		}

		private LogicalCircuit Create(Guid logicalCircuitId) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = logicalCircuitId;
			LogicalCircuit circuit = new LogicalCircuitItem(row);
			circuit.Name = this.UniqueName(Resources.LogicalCircuitName);
			row.Add();
			return circuit;
		}

		public LogicalCircuit Create() {
			return this.Create(Guid.NewGuid());
		}

		private class LogicalCircuitItem : LogicalCircuit {
			public LogicalCircuitItem(Store.Table.Row row) : base(row) {
			}
		}

		public bool Paste(Store store) {
			Guid projectId;
			Store.Table.Row mainRow = this.ProjectManager.ProjectStore.Project.GetAlienLogicalCircuit(store, out projectId);
			if(mainRow != null) {
				mainRow.Tag = this.ProjectManager.ProjectStore.Project.LogicalCircuit;
				if(projectId != this.ProjectManager.ProjectStore.Project.Guid) {
					// The row from alien table was found so the table also exists. Lets enumrate it.
					foreach(Store.Table.Row row in store[this.Table.Ordinal]) {
						if(row != mainRow) {
							Tracer.Assert(row.Tag == null);
							Guid logicalCircuitId = (Guid)row[0];
							if(this.Find(logicalCircuitId) == null) {
								LogicalCircuit lc = this.Create(logicalCircuitId);
								string text = row[LogicalCircuitStore.name].ToString();
								if(0 < text.Length) {
									lc.Name = this.UniqueName(text);
								}
								lc.Notation = row[LogicalCircuitStore.notation].ToString();
								lc.Description = row[LogicalCircuitStore.description].ToString();
								lc.Category = row[LogicalCircuitStore.category].ToString();
								row.Tag = lc;
							}
						}
					}
				}
				return true;
			}
			return false;
		}

		public LogicalCircuit Paste(Store store, Guid logicalCircuitId) {
			Store.Table table = store[this.Table.Ordinal];
			Store.Table.Row row = table.Select(logicalCircuitId);
			if(row != null) {
				return row.Tag as LogicalCircuit;
			}
			return null;
		}
	}
}
