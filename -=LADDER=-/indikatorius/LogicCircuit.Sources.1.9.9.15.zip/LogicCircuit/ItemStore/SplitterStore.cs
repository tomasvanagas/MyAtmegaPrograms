﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class SplitterStore : CircuitStore<Splitter> {

		private static int bitWidth;
		private static int pinCount;
		private static int rotation;

		public SplitterStore(ProjectManager projectManager, Store.Table table, DevicePinStore devicePinStore) : base(projectManager, table) {
			if(SplitterStore.bitWidth == 0) {
				SplitterStore.bitWidth = table.ColumnOrdinal("BitWidth");
				SplitterStore.pinCount = table.ColumnOrdinal("PinCount");
				SplitterStore.rotation = table.ColumnOrdinal("Rotation");
			}
			foreach(Splitter splitter in this) {
				this.CreatePins(splitter, devicePinStore);
			}
		}

		protected override Splitter CreateItem(Store.Table.Row row) {
			return new SplitterItem(row);
		}

		public Splitter Create(int bitWidth, int pinCount, CircuitRotation rotation) {
			Tracer.Assert(1 < pinCount && pinCount <= bitWidth);
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			Splitter splitter = this.CreateItem(row);
			splitter.BitWidth = bitWidth;
			splitter.PinCount = pinCount;
			splitter.Rotation = rotation;
			row.Add();
			this.CreatePins(splitter, this.ProjectManager.DevicePinStore);
			return splitter;
		}

		private void CreatePins(Splitter splitter, DevicePinStore devicePinStore) {
			// The order of creation of the pins is essential for expantion algorithm (CircuitMap.Connect).
			// The wide pin should go first and then thin pins starting from lower bits to higher
			Tracer.Assert(devicePinStore.Select(splitter).Length == 0);
			if(splitter.PinCount < 2) {
				splitter.PinCount = 2;
			}
			if(splitter.BitWidth < splitter.PinCount) {
				splitter.BitWidth = splitter.PinCount;
			}
			DevicePin pin = devicePinStore.Create(splitter, PinType.None, splitter.BitWidth);
			pin.Name = Resources.SplitterWidePinName;
			PinSide pinSide;
			switch(splitter.Rotation) {
			case CircuitRotation.Up:
				pinSide = PinSide.Bottom;
				pin.PinSide = PinSide.Top;
				break;
			case CircuitRotation.Right:
				pinSide = PinSide.Left;
				pin.PinSide = PinSide.Right;
				break;
			case CircuitRotation.Down:
				pinSide = PinSide.Top;
				pin.PinSide = PinSide.Bottom;
				break;
			case CircuitRotation.Left:
				pinSide = PinSide.Right;
				pin.PinSide = PinSide.Left;
				break;
			default:
				Tracer.Fail();
				return;
			}
			int pinWidth = splitter.BitWidth / splitter.PinCount + Math.Sign(splitter.BitWidth % splitter.PinCount);
			int width = 0;
			for(int i = 0; i < splitter.PinCount; i++) {
				pinWidth = Math.Min(pinWidth, splitter.BitWidth - width);
				if(pinWidth < 1) {
					splitter.PinCount = i;
					Tracer.Assert(1 < i);
					break;
				}
				pin = devicePinStore.Create(splitter, PinType.None, pinWidth);
				pin.PinSide = pinSide;
				if(pinWidth == 1) {
					pin.Name = Resources.SplitterThin1PinName(width);
				} else {
					pin.Name = Resources.SplitterThin2PinName(width, width + pinWidth - 1);
				}
				width += pinWidth;
			}
		}

		private class SplitterItem : Splitter {
			public SplitterItem(Store.Table.Row row) : base(row) {}
		}

		public Splitter Paste(Store store, Guid splitterId) {
			Store.Table table = store[this.Table.Ordinal];
			Store.Table.Row row = table.Select(splitterId);
			if(row != null) {
				Tracer.Assert(row.Tag == null);
				int bitWidth = (int)row[SplitterStore.bitWidth];
				int pinCount = (int)row[SplitterStore.pinCount];
				CircuitRotation rotation = (CircuitRotation)Enum.Parse(typeof(CircuitRotation), row[SplitterStore.rotation].ToString(), true);
				Splitter splitter = this.Create(bitWidth, pinCount, rotation);
				row.Tag = splitter;
				return splitter;
			}
			return null;
		}
	}
}
