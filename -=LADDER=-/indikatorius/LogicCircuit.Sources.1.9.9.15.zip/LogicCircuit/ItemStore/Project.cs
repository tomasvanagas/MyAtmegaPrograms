﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class Project : Item {

		private static int name;
		private static int description;
		private static int zoom;
		private static int logicalCircuitId;

		protected Project(Store.Table.Row row) : base(row) {
			if(Project.name == 0) {
				Store.Table table = row.Table;
				Project.name = table.ColumnOrdinal("Name");
				Project.description = table.ColumnOrdinal("Description");
				Project.zoom = table.ColumnOrdinal("Zoom");
				Project.logicalCircuitId = table.ColumnOrdinal("LogicalCircuitId");
			}
			this.logicalCircuit = new ForeignKey<LogicalCircuit>(row, Project.logicalCircuitId);
		}

		public string Name {
			get { return this.Row[Project.name].ToString(); }
			set { this.Row[Project.name] = value; }
		}

		public string Description {
			get { return this.Row[Project.description].ToString(); }
			set { this.Row[Project.description] = value; }
		}

		public double Zoom {
			get { return (double)this.Row[Project.zoom]; }
			set { this.Row[Project.zoom] = value; }
		}

		private ForeignKey<LogicalCircuit> logicalCircuit;
		public LogicalCircuit LogicalCircuit {
			get { return this.logicalCircuit.Parent; }
			set { this.logicalCircuit.Parent = value; }
		}

		public Store.Table.Row GetAlienLogicalCircuit(Store store, out Guid projectId) {
			Store.Table table = store[this.Row.Table.Ordinal];
			Tracer.Assert(
				store.NameSpaceUri == this.Row.Table.Store.NameSpaceUri &&
				table.Name == this.Row.Table.Name &&
				table.ColumnCount == this.Row.Table.ColumnCount
			);
			if(table.Count == 1) {
				Store.Table.Row row = table[0];
				projectId = (Guid)row[0];
				return row.Parent(Project.logicalCircuitId);
			}
			projectId = Guid.Empty;
			return null;
		}
	}
}
