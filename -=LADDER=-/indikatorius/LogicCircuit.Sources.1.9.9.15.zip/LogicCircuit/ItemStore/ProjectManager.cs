﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Xsl;

namespace LogicCircuit {
	public class ProjectManager : PropertyBag {
		public event EventHandler EditEnded;

		public string File { get; private set; }

		private TransactionalStore Store { get; set; }

		public ProjectStore ProjectStore { get; private set; }
		public DevicePinStore DevicePinStore { get; private set; }
		public GateStore GateStore { get; private set; }
		public LogicalCircuitStore LogicalCircuitStore { get; private set; }
		public PinStore PinStore { get; private set; }
		public ConstantStore ConstantStore { get; private set; }
		public CircuitButtonStore CircuitButtonStore { get; private set; }
		public MemoryStore MemoryStore { get; private set; }
		public SplitterStore SplitterStore { get; private set; }
		public CircuitSymbolStore CircuitSymbolStore { get; private set; }
		public JamStore JamStore { get; private set; }
		public WireStore WireStore { get; private set; }
		public ConnectionStore ConnectionStore { get; private set; }

		public ProjectManager() {
			this.New();
		}

		public string NamespaceUri { get { return this.Store.NameSpaceUri; } }

		private void Load(XmlDocument xml) {
			TransactionalStore store = new TransactionalStore(Schema.CircuitProject);
			store.Tag = this;
			store.EnforceForeignKeys = false;
			ProjectManager.Load(store, xml);

			Transaction transaction = store.BeginTransaction();

			ProjectStore projectStore = new ProjectStore(this, store["Project"]);
			DevicePinStore devicePinStore = new DevicePinStore(this, store["DevicePin"]);
			GateStore gateStore = new GateStore(this, store["Gate"], devicePinStore);
			LogicalCircuitStore logicalCircuitStore = new LogicalCircuitStore(this, store["LogicalCircuit"]);
			PinStore pinStore = new PinStore(this, store["Pin"], devicePinStore);
			ConstantStore constantStore = new ConstantStore(this, store["Constant"], devicePinStore);
			CircuitButtonStore circuitButtonStore = new CircuitButtonStore(this, store["CircuitButton"], devicePinStore);
			MemoryStore memoryStore = new MemoryStore(this, store["Memory"], devicePinStore);
			SplitterStore splitterStore = new SplitterStore(this, store["Splitter"], devicePinStore);
			CircuitSymbolStore circuitSymbolStore = new CircuitSymbolStore(this, store["CircuitSymbol"], pinStore, logicalCircuitStore);
			JamStore jamStore = new JamStore(this, store["Jam"]);
			WireStore wireStore = new WireStore(this, store["Wire"]);
			ConnectionStore connectionStore = new ConnectionStore(this, store["Connection"]);

			gateStore.Lock();
			store.EnforceForeignKeys = true;

			this.Store = store;

			this.ProjectStore = projectStore;
			this.DevicePinStore = devicePinStore;
			this.GateStore = gateStore;
			this.LogicalCircuitStore = logicalCircuitStore;
			this.PinStore = pinStore;
			this.ConstantStore = constantStore;
			this.CircuitButtonStore = circuitButtonStore;
			this.MemoryStore = memoryStore;
			this.SplitterStore = splitterStore;
			this.CircuitSymbolStore = circuitSymbolStore;
			this.JamStore = jamStore;
			this.WireStore = wireStore;
			this.ConnectionStore = connectionStore;

			List<Wire> list = new List<Wire>();
			foreach(Wire wire in this.WireStore) {
				if(wire.Point1 == wire.Point2) {
					list.Add(wire);
				}
			}
			if(0 < list.Count) {
				foreach(Wire wire in list) {
					wire.Delete();
				}
			}
			foreach(CircuitSymbol symbol in this.CircuitSymbolStore) {
				symbol.RefreshGlyph();
			}

			store.Commit(transaction);
			store.ClearLog();
			this.Store.EditEnded += new EventHandler(this.StoreEditEnded);

			this.OnPropertyChanged("ProjectStore");
		}

		private static string ChangeGuid(string text, string nodeName) {
			string s = Regex.Replace(text,
				string.Format(CultureInfo.InvariantCulture,
					@"<lc:{0}>\{{?[0-9a-fA-F]{{8}}-([0-9a-fA-F]{{4}}-){{3}}[0-9a-fA-F]{{12}}\}}?</lc:{0}>", nodeName
				),
				string.Format(CultureInfo.InvariantCulture,
					@"<lc:{0}>{1}</lc:{0}>", nodeName, Guid.NewGuid()
				),
				RegexOptions.CultureInvariant | RegexOptions.Singleline
			);
			return s;
		}

		public void New() {
			XmlDocument xml = new XmlDocument();
			xml.LoadXml(ProjectManager.ChangeGuid(ProjectManager.ChangeGuid(Schema.Empty, "ProjectId"), "LogicalCircuitId"));
			this.Load(xml);
			this.File = null;
		}

		public void Load(string file) {
			XmlDocument xml = new XmlDocument();
			xml.Load(file);
			this.Load(xml);
			this.File = file;
			this.Store.AcceptChanges();
		}

		public bool HasChanges { get { return this.Store.HasChanges; } }

		public void Save() {
			Tracer.Assert(this.File != null);
			LogicCircuit.Store.WriteXml(this.Store.Save(), this.File, Encoding.UTF8);
			this.Store.AcceptChanges();
		}
		public void Save(string fileName) {
			this.File = fileName;
			this.Save();
		}

		public Transaction BeginTransaction() {
			return this.Store.BeginTransaction();
		}
		public void EndTransaction(Transaction transaction, bool success) {
			if(success) {
				this.Store.Commit(transaction);
			} else {
				this.Store.Rollback(transaction);
			}
		}
		public void Omit(Transaction transaction) {
			this.Store.Omit(transaction);
		}

		public void Undo() {
			this.Store.Undo();
		}
		public void Redo() {
			this.Store.Redo();
		}
		public bool HasUndo { get { return this.Store.HasUndo; } }
		public bool HasRedo { get { return this.Store.HasRedo; } }

		public bool IsTransactionOpen { get { return this.Store.IsTransactionOpen(); } }

		public XmlDocument Copy(IEnumerable<Symbol> symbol) {
			Store store = new Store(Schema.CircuitProject);
			store.EnforceForeignKeys = false;
			this.ProjectStore.Project.Copy(store, false);
			this.ProjectStore.Project.LogicalCircuit.Copy(store, false);
			foreach(Symbol i in symbol) {
				i.Copy(store, true);
			}
			return store.Save();
		}

		public List<Symbol> Paste(XmlDocument xml) {
			Store store = new Store(Schema.CircuitProject);
			store.EnforceForeignKeys = false;
			store.Load(xml);
			List<Symbol> result = new List<Symbol>();
			if(this.LogicalCircuitStore.Paste(store)) {
				this.CircuitSymbolStore.Paste(store, result);
				this.WireStore.Paste(store, result);
				LogicalCircuit lc = this.ProjectStore.Project.LogicalCircuit;
				Guid projectId;
				if(0 < result.Count && (Guid)this.ProjectStore.Project.GetAlienLogicalCircuit(store, out projectId)[0] == lc.Guid) {
					foreach(Symbol symbol in result) {
						symbol.Shift(2, 2);
					}
				}
			}
			return result;
		}

		private void StoreEditEnded(object sender, EventArgs e) {
			if(this.EditEnded != null) {
				this.EditEnded(this, EventArgs.Empty);
			}
		}

		private static XmlDocument Transform(XmlDocument xml, string xsltText) {
			XslCompiledTransform xslt = new XslCompiledTransform();
			using(StringReader stringReader = new StringReader(xsltText)) {
				using(XmlTextReader xmlTextReader = new XmlTextReader(stringReader)) {
					xslt.Load(xmlTextReader);
				}
			}
			XmlDocument result = new XmlDocument();
			using(XmlNodeReader reader = new XmlNodeReader(xml.DocumentElement)) {
				using(StringWriter stringWriter = new StringWriter(LogicCircuit.Store.DataCulture)) {
					using(XmlTextWriter writer = new XmlTextWriter(stringWriter)) {
						xslt.Transform(reader, writer);
					}
					result.LoadXml(stringWriter.ToString());
				}
			}
			return result;
		}
		private static bool Load(Store store, XmlDocument xml) {
			StringComparer comparer = LogicCircuit.Store.StringComparer;
			bool upgraded = false;
			if(comparer.Compare(store.NameSpaceUri, xml.DocumentElement.NamespaceURI) != 0) {
				upgraded = true;
				Store version = new Store(Schema.VersionData);
				XmlDocument versionXml = new XmlDocument();
				versionXml.LoadXml(Schema.StoreVersion);
				version.Load(versionXml);
				Store.Table versionTable = version["StoreVersion"];
				while(comparer.Compare(store.NameSpaceUri, xml.DocumentElement.NamespaceURI) != 0) {
					Store.Table.Row row = versionTable.Select(xml.DocumentElement.NamespaceURI);
					if(row == null) {
						throw new CircuitException(Cause.UnknownVersion, Resources.ErrorUnknownVersion);
					}
					xml = ProjectManager.Transform(xml, Schema.ResourceManager.GetString((string)row["Xsl"], Schema.Culture));
				}
			}
			store.Load(xml);
			return upgraded;
		}
	}
}
