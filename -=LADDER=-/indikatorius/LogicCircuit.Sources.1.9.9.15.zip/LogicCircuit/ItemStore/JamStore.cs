﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class JamStore : ItemStore<Jam> {

		private static int pinId;
		private static int circuitSymbolId;

		public JamStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {
			if(JamStore.pinId == 0) {
				JamStore.pinId = table.ColumnOrdinal("PinId");
				JamStore.circuitSymbolId = table.ColumnOrdinal("CircuitSymbolId");
			}
		}

		protected override Jam CreateItem(Store.Table.Row row) {
			throw new InvalidOperationException();
		}

		private Jam Create(BasePin pin, CircuitSymbol symbol, GridPoint point) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			Jam jam = new JamItem(row, pin, symbol, point);
			row.Add();
			return jam;
		}

		private Jam Select(BasePin pin, CircuitSymbol symbol) {
			Jam[] jam = this.Select(JamStore.pinId, pin.Guid, JamStore.circuitSymbolId, symbol.Guid);
			Tracer.Assert(jam == null || jam.Length == 0 || jam.Length == 1);
			return (jam != null && 0 < jam.Length) ? jam[0] : null;
		}

		public Jam Jam(BasePin pin, CircuitSymbol symbol, GridPoint point) {
			Jam jam = this.Select(pin, symbol);
			if(jam != null) {
				jam.Point = point;
				return jam;
			}
			return this.Create(pin, symbol, point);
		}

		public Jam[] Select(CircuitSymbol symbol) {
			return this.Select(JamStore.circuitSymbolId, symbol.Guid);
		}

		private class JamItem : Jam {
			public JamItem(Store.Table.Row row, BasePin pin, CircuitSymbol symbol, GridPoint point) : base(row, pin, symbol, point) {}
		}
	}
}
