﻿using System;

namespace LogicCircuit {
	public enum CircuitRotation {
		Up,
		Right,
		Down,
		Left
	}
}
