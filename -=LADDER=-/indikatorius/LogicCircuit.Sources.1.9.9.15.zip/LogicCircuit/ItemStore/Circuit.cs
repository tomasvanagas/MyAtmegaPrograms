﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class Circuit : Item {

		private static int circuitTable;

		protected Circuit(Store.Table.Row row) : base(row) {
			if(Circuit.circuitTable == 0) {
				Circuit.circuitTable = row.Table.Store["Circuit"].Ordinal;
				Tracer.Assert(0 < Circuit.circuitTable, "Make table Circuit not the first table in the store");
			}
			Store.Table.Row circuitRow = row.Table.Store[Circuit.circuitTable].NewRow();
			circuitRow[0] = row[0];
			circuitRow.Tag = this;
			circuitRow.Add();
		}

		public abstract string ToolTip { get; }

		public abstract string Notation { get; set; }

		public virtual string Name {
			get { return this.Notation; }
			set { this.Notation = value; }
		}

		public virtual int InputCount {
			get { return this.ProjectManager.DevicePinStore.Select(this, PinType.Input).Length; }
		}
		public virtual BasePin Input(int index) {
			return this.ProjectManager.DevicePinStore.Select(this, PinType.Input)[index];
		}

		public virtual int OutputCount {
			get { return this.ProjectManager.DevicePinStore.Select(this, PinType.Output).Length; }
		}
		public virtual BasePin Output(int index) {
			return this.ProjectManager.DevicePinStore.Select(this, PinType.Output)[index];
		}

		public override void Delete() {
			this.Row.Parent(0).Delete();
		}

		public override string ToString() {
			return this.GetType().BaseType.Name + ": " + this.Name.Trim();
		}
	}
}
