﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;

namespace LogicCircuit {
	public abstract class Gate : Circuit {

		public const int MaxInputCount = 18;

		private struct GateInfo {
			public string Name;
			public string Notation;
			public GateInfo(string name, string notation) {
				this.Name = name;
				this.Notation = notation;
			}
		}

		private static Dictionary<GateType, GateInfo> gateInfo = Gate.InitInfo();
		private static Dictionary<GateType, GateInfo> InitInfo() {
			Dictionary<GateType, GateInfo> info = new Dictionary<GateType,GateInfo>();
			info.Add(GateType.Clock,	new GateInfo(Resources.GateClockName, Resources.GateClockNotation));
			info.Add(GateType.Not,		new GateInfo(Resources.GateNotName, Resources.GateNotNotation));
			info.Add(GateType.Or,		new GateInfo(Resources.GateOrName, Resources.GateOrNotation));
			info.Add(GateType.And,		new GateInfo(Resources.GateAndName, Resources.GateAndNotation));
			info.Add(GateType.Xor,		new GateInfo(Resources.GateXorName, Resources.GateXorNotation));
			info.Add(GateType.Odd,		new GateInfo(Resources.GateOddName, Resources.GateOddNotation));
			info.Add(GateType.Even,		new GateInfo(Resources.GateEvenName, Resources.GateEvenNotation));
			info.Add(GateType.Led,		new GateInfo(Resources.GateLedName, Resources.GateLedNotation));
			info.Add(GateType.Probe,	new GateInfo(Resources.GateProbeName, Resources.GateProbeNotation));
			info.Add(GateType.TriState,	new GateInfo(Resources.GateTriStateName, Resources.GateTriStateNotation));
			return info;
		}

		protected Gate(Store.Table.Row row) : base(row) {
			this.gateType = new EnumValue<GateType>(row, row.Table.ColumnOrdinal("GateType"));
		}

		private EnumValue<GateType> gateType;
		public GateType GateType {
			get { return this.gateType.Value; }
			set { this.gateType.Value = value; }
		}

		public override string Name {
			get { return Gate.gateInfo[this.GateType].Name; }
			set { throw new InvalidOperationException(); }
		}

		public override string ToolTip { get { return this.Name; } }
		public override string Notation {
			get { return Gate.gateInfo[this.GateType].Notation; }
			set { throw new InvalidOperationException(); }
		}
	}
}
