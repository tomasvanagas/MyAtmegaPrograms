﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class BasePinStore<TItem> : CircuitStore<TItem>
		where TItem:BasePin
	{
		protected static int circuitId;
		protected static int pinType;
		protected static int pinSide;
		protected static int inverted;
		protected static int name;
		protected static int note;
		protected static int bitWidth;

		protected BasePinStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {
			if(BasePinStore<TItem>.circuitId == 0) {
				BasePinStore<TItem>.circuitId = table.ColumnOrdinal("CircuitId");
				BasePinStore<TItem>.pinType = table.ColumnOrdinal("PinType");
				BasePinStore<TItem>.pinSide = table.ColumnOrdinal("PinSide");
				BasePinStore<TItem>.inverted = table.ColumnOrdinal("Inverted");
				BasePinStore<TItem>.name = table.ColumnOrdinal("Name");
				BasePinStore<TItem>.note = table.ColumnOrdinal("Note");
				BasePinStore<TItem>.bitWidth = table.ColumnOrdinal("BitWidth");
			}
		}

		protected virtual TItem Create(Circuit circuit, PinType pinType) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			TItem pin = this.CreateItem(row);
			pin.Circuit = circuit;
			pin.PinType = pinType;
			pin.PinSide = (pinType == PinType.Input) ? PinSide.Left : PinSide.Right;
			pin.Name = this.UniqueName(
				(pinType == PinType.Input) ? Resources.PinInName : Resources.PinOutName,
				BasePinStore<TItem>.circuitId, circuit.Guid
			);
			row.Add();
			return pin;
		}

		public TItem[] Select(Circuit circuit) {
			return this.Select(BasePinStore<TItem>.circuitId, circuit.Guid);
		}

		public TItem[] Select(Circuit circuit, PinType pinType) {
			return this.Select(BasePinStore<TItem>.circuitId, circuit.Guid, BasePinStore<TItem>.pinType, pinType.ToString());
		}

		public bool Exists(Circuit circuit, PinType pinType) {
			return this.Table.Exists(BasePinStore<TItem>.circuitId, circuit.Guid, BasePinStore<TItem>.pinType, pinType.ToString());
		}
	}

	public class DevicePinStore : BasePinStore<DevicePin> {
		private int order = 0;

		public DevicePinStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {}

		protected override DevicePin CreateItem(Store.Table.Row row) {
			return new PinItem(row);
		}

		private class PinItem : DevicePin {
			public PinItem(Store.Table.Row row) : base(row) {}
		}

		public DevicePin Create(Circuit circuit, PinType pinType, int bitWidth) {
			DevicePin pin = base.Create(circuit, pinType);
			pin.BitWidth = bitWidth;
			pin.Order = this.order++;
			return pin;
		}
	}

	public class PinStore : BasePinStore<Pin> {
		public PinStore(ProjectManager projectManager, Store.Table table, DevicePinStore devicePinStore) : base(projectManager, table) {
			foreach(Pin pin in this) {
				if(pin.PinType != PinType.None) {
					DevicePin devicePin = devicePinStore.Create(pin, pin.PinType == PinType.Input ? PinType.Output : PinType.Input, pin.BitWidth);
					devicePin.Inverted = pin.Inverted;
				}
			}
		}

		protected override Pin CreateItem(Store.Table.Row row) {
			return new PinItem(row);
		}

		private class PinItem : Pin {
			public PinItem(Store.Table.Row row) : base(row) {}
		}

		public Pin Create(Circuit circuit, PinType pinType, int bitWidth) {
			Pin pin = base.Create(circuit, pinType);
			if(pinType != PinType.None) {
				DevicePin devicePin = this.ProjectManager.DevicePinStore.Create(
					pin, (pinType == PinType.Input) ? PinType.Output : PinType.Input, bitWidth
				);
				devicePin.Inverted = pin.Inverted;
			}
			pin.BitWidth = bitWidth;
			return pin;
		}

		public Pin Paste(Store store, Guid pinId) {
			Store.Table table = store[this.Table.Ordinal];
			Store.Table.Row row = table.Select(pinId);
			if(row != null) {
				Tracer.Assert(row.Tag == null);
				LogicalCircuit lc = this.ProjectManager.LogicalCircuitStore.Paste(store, (Guid)row[PinStore.circuitId]);
				if(lc != null) {
					PinType pinType = (PinType)Enum.Parse(typeof(PinType), row[BasePinStore<Pin>.pinType].ToString(), true);
					PinSide pinSide = (PinSide)Enum.Parse(typeof(PinSide), row[BasePinStore<Pin>.pinSide].ToString(), true);
					bool inverted = (bool)row[BasePinStore<Pin>.inverted];
					Pin pin = this.Create(lc, pinType, BasePin.NormalizeBitWidth((int)row[BasePinStore<Pin>.bitWidth]));
					pin.PinSide = pinSide;
					pin.Inverted = inverted;
					pin.Name = this.UniqueName(row[BasePinStore<Pin>.name].ToString(), BasePinStore<Pin>.circuitId, lc.Guid);
					pin.Note = row[BasePinStore<Pin>.note].ToString();
					row.Tag = pin;
					return pin;
				}
			}
			return null;
		}
	}
}
