﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class Connection : Item {

		private static int inJamId;
		private static int outJamId;

		protected Connection(Store.Table.Row row) : base(row) {
			if(Connection.inJamId == 0) {
				Store.Table table = row.Table;
				Connection.inJamId = table.ColumnOrdinal("InJamId");
				Connection.outJamId = table.ColumnOrdinal("OutJamId");
			}
			this.inJam = new ForeignKey<Jam>(row, Connection.inJamId);
			this.outJam = new ForeignKey<Jam>(row, Connection.outJamId);
		}

		private ForeignKey<Jam> inJam;
		public Jam InJam {
			get { return this.inJam.Parent; }
			set {
				Tracer.Assert(value != null && value.Pin.PinType != PinType.Output);
				this.inJam.Parent = value;
			}
		}

		private ForeignKey<Jam> outJam;
		public Jam OutJam {
			get { return this.outJam.Parent; }
			set {
				Tracer.Assert(value != null && value.Pin.PinType != PinType.Input);
				this.outJam.Parent = value;
			}
		}
	}
}
