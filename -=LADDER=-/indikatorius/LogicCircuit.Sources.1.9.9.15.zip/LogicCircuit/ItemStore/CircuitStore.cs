﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class CircuitStore<TItem> : ItemStore<TItem>
		where TItem:Circuit
	{
		public CircuitStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {
			table.TableChanged += new Store.TableChangedEventHandler(TableChanged);
		}

		private void TableChanged(Store.RowAction action, Store.Table.Row row, object[] old) {
			if(action == Store.RowAction.Deleted) {
				Store.Table.Row parent = row.Parent(0);
				if(parent.State == Store.RowState.Current) {
					parent.Delete();
				}
			}
		}
	}
}
