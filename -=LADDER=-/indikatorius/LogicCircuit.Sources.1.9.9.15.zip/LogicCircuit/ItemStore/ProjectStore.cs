﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class ProjectStore : ItemStore<Project> {

		public ProjectStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {}

		protected override Project CreateItem(Store.Table.Row row) {
			return new ProjectItem(row);
		}

		public Project Project { get { return (Project)this.Table[0].Tag; } }

		private class ProjectItem : Project {
			public ProjectItem(Store.Table.Row row) : base(row) {
				Tracer.Assert(this.Row.Table.Count == 1);
			}
		}
	}
}
