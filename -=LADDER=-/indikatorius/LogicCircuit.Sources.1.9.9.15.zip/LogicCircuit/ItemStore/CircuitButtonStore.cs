﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class CircuitButtonStore : CircuitStore<CircuitButton> {

		public static int notation;

		public CircuitButtonStore(ProjectManager projectManager, Store.Table table, DevicePinStore devicePinStore) : base(projectManager, table) {
			if(CircuitButtonStore.notation == 0) {
				CircuitButtonStore.notation = table.ColumnOrdinal("Notation");
			}
			foreach(CircuitButton button in this) {
				devicePinStore.Create(button, PinType.Output, 1);
			}
		}

		protected override CircuitButton CreateItem(Store.Table.Row row) {
			return new CircuitButtonItem(row);
		}

		public CircuitButton Create() {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			CircuitButton button = this.CreateItem(row);
			row.Add();
			this.ProjectManager.DevicePinStore.Create(button, PinType.Output, 1);
			return button;
		}

		private class CircuitButtonItem : CircuitButton {
			public CircuitButtonItem(Store.Table.Row row) : base(row) {}
		}

		public CircuitButton Paste(Store store, Guid buttonId) {
			Store.Table table = store[this.Table.Ordinal];
			Store.Table.Row row = table.Select(buttonId);
			if(row != null) {
				Tracer.Assert(row.Tag == null);
				CircuitButton button = this.Create();
				button.Notation = row[CircuitButtonStore.notation].ToString();
				row.Tag = button;
				return button;
			}
			return null;
		}
	}
}
