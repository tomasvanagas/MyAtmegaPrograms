﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace LogicCircuit {
	public abstract class Symbol : Item {
		protected Symbol(Store.Table.Row row) : base(row) {
			this.logicalCircuit = new ForeignKey<LogicalCircuit>(row, row.Table.ColumnOrdinal("LogicalCircuitId"));
		}

		private ForeignKey<LogicalCircuit> logicalCircuit;
		public LogicalCircuit LogicalCircuit {
			get { return this.logicalCircuit.Parent; }
			set { this.logicalCircuit.Parent = value; }
		}

		public abstract FrameworkElement Glyph { get; }

		public MainFrame MainFrame { get { return MainFrame.FindMainFrame(this.Glyph); } }

		public abstract void Shift(int x, int y);

		public abstract GridPoint Point { get; set; }
	}
}
