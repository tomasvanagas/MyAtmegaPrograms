﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class Item {
		private   Store.Table.Row row;
		protected Store.Table.Row Row { get { return this.row; } }

		public ProjectManager ProjectManager { get { return (ProjectManager)this.row.Table.Store.Tag; } }

		protected Item(Store.Table.Row row) {
			this.row = row;
			this.row.Tag = this;
		}

		public virtual void Delete() {
			if(this.row.State == Store.RowState.Current) {
				this.row.Delete();
			}
		}

		public bool IsDeleted {
			get { return this.row.State == Store.RowState.Deleted; }
		}

		public Guid Guid { get { return (Guid)this.row[0]; } }

		public virtual bool Copy(Store store, bool deepCopy) {
			Store.Table table = store[this.Row.Table.Ordinal];
			Store.Table.Row row = table.Select(this.Guid);
			if(row == null) {
				row = table.NewRow();
				row.ItemArray = this.Row.ItemArray;
				row.Add();
				return true;
			}
			return false;
		}

		/// <summary>
		/// Cache of foreign reference.
		/// </summary>
		/// <typeparam name="TParentItem">Type of the parent item</typeparam>
		protected struct ForeignKey<TParentItem>
			where TParentItem:Item
		{
			private Store.Table.Row row;
			private int column;

			private TParentItem  parentItem;

			/// <summary>
			/// Gets or set parent item
			/// </summary>
			public TParentItem Parent {
				get {
					if(this.parentItem == null || !this.parentItem.Guid.Equals(this.row[this.column])) {
						//all foreign keys are mandatory so row.Parent is never null
						this.parentItem = (TParentItem)this.row.Parent(this.column).Tag;
					}
					return this.parentItem;
				}
				set {
					this.row[this.column] = value.Guid;
					this.parentItem = value;
				}
			}
			public ForeignKey(Store.Table.Row row, int column) {
				this.row = row;
				this.column = column;
				this.parentItem = null;
			}

			/// <summary>
			/// Gets state of the foreign key. True is it is not initialized, false - otherwize
			/// </summary>
			public bool IsNull { get { return this.row == null; } }
		}

		/// <summary>
		/// Cache of enum value.
		/// All enum values are stored as strings in the store, while wrappers expose them as values.
		/// So this structure caches parsing of strings to values.
		/// </summary>
		/// <typeparam name="EnumType">Type of the enumeration</typeparam>
		protected struct EnumValue<EnumType> {
			private Store.Table.Row row;
			private int column;
			private string stringValue;
			private EnumType value;
			public EnumType Value {
				get {
					if(!object.ReferenceEquals(this.stringValue, this.row[this.column])) {
						string s = (string)this.row[this.column];
						this.value = (EnumType)Enum.Parse(typeof(EnumType), s, true);
						this.stringValue = s;
					}
					return this.value;
				}
				set {
					this.stringValue = value.ToString();
					this.value = value;
					this.row[this.column] = this.stringValue;
				}
			}
			public EnumValue(Store.Table.Row row, int column) {
				this.row = row;
				this.column = column;
				this.stringValue = null;
				this.value = default(EnumType);
			}

			/// <summary>
			/// Gets state of the foreign key. True is it is not initialized, false - otherwize
			/// </summary>
			public bool IsNull { get { return this.row == null; } }
		}
	}
}
