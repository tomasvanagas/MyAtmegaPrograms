﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {

	public enum PinType {
		None,
		Input,
		Output
	}

	public enum PinSide {
		Left,
		Top,
		Right,
		Bottom
	}

	public abstract class BasePin : Circuit {

		public const int MaxBitWidth = 32;

		private static int inverted;
		private static int name;
		private static int note;
		private static int bitWidth;
		private static int circuitId;
		private static int pinTypeColumn;
		private static int pinSideColumn;

		protected BasePin(Store.Table.Row row) : base(row) {
			Store.Table table = row.Table;
			if(BasePin.inverted == 0) {
				BasePin.inverted = table.ColumnOrdinal("Inverted");
				BasePin.name = table.ColumnOrdinal("Name");
				BasePin.note = table.ColumnOrdinal("Note");
				BasePin.bitWidth = table.ColumnOrdinal("BitWidth");
				BasePin.circuitId = table.ColumnOrdinal("CircuitId");
				BasePin.pinTypeColumn = table.ColumnOrdinal("PinType");
				BasePin.pinSideColumn = table.ColumnOrdinal("PinSide");
			}
			this.circuit = new ForeignKey<Circuit>(row, BasePin.circuitId);
			this.pinType = new EnumValue<PinType>(row, BasePin.pinTypeColumn);
			this.pinSide = new EnumValue<PinSide>(row, BasePin.pinSideColumn);
		}

		private ForeignKey<Circuit> circuit;
		public Circuit Circuit {
			get { return this.circuit.Parent; }
			set { this.circuit.Parent = value; }
		}

		private EnumValue<PinType> pinType;
		public PinType PinType {
			get { return this.pinType.Value; }
			set { this.pinType.Value = value; }
		}

		private EnumValue<PinSide> pinSide;
		public PinSide PinSide {
			get { return this.pinSide.Value; }
			set { this.pinSide.Value = value; }
		}

		public virtual bool Inverted {
			get { return (bool)this.Row[BasePin.inverted]; }
			set { this.Row[BasePin.inverted] = value; }
		}

		public override string Name {
			get { return this.Row[BasePin.name].ToString(); }
			set { this.Row[BasePin.name] = value; }
		}

		public void Rename(string name) {
			if(this.Row.Table.TableColumn(Pin.name).Comparer.Compare(this.Row, name) != 0) {
				this.Name = this.ProjectManager.PinStore.UniqueName(name, Pin.circuitId, this.Circuit.Guid);
			}
		}

		public static int NormalizeBitWidth(int value) {
			return Math.Max(1, Math.Min(value, BasePin.MaxBitWidth));
		}

		public virtual int BitWidth {
			get { return BasePin.NormalizeBitWidth((int)this.Row[BasePin.bitWidth]); }
			set { this.Row[BasePin.bitWidth] = BasePin.NormalizeBitWidth(value); }
		}

		private string AppendNote(string toolTip) {
			string n = this.Note;
			if(!string.IsNullOrEmpty(n)) {
				return toolTip + "\n" + n;
			}
			return toolTip;
		}

		public override string ToolTip {
			get {
				if(this.PinType == PinType.Input) {
					return this.AppendNote(Resources.ToolTipInputPin(this.BitWidth, this.Name));
				} else if(this.PinType == PinType.Output) {
					return this.AppendNote(Resources.ToolTipOutputPin(this.BitWidth, this.Name));
				} else {
					return this.AppendNote(Resources.ToolTipNonePin(this.BitWidth, this.Name));
				}
			}
		}

		public override string Notation {
			get { return this.Name; }
			set { throw new InvalidOperationException(); }
		}

		public string Note {
			get { return this.Row[BasePin.note].ToString(); }
			set { this.Row[BasePin.note] = value; }
		}
	}

	public abstract class Pin : BasePin {
		protected Pin(Store.Table.Row row) : base(row) {}

		public override int BitWidth {
			get { return base.BitWidth; }
			set {
				base.BitWidth = value;
				DevicePin[] pin = this.ProjectManager.DevicePinStore.Select(this);
				Tracer.Assert(pin != null && pin.Length == 1 && pin[0] != null);
				pin[0].BitWidth = this.BitWidth;
			}
		}

		public override bool Inverted {
			get { return base.Inverted; }
			set {
				base.Inverted = value;
				DevicePin[] pin = this.ProjectManager.DevicePinStore.Select(this);
				Tracer.Assert(pin != null && pin.Length == 1 && pin[0] != null);
				pin[0].Inverted = this.Inverted;
			}
		}
	}

	public abstract class DevicePin : BasePin {
		protected DevicePin(Store.Table.Row row) : base(row) {}

		public int Order { get; set; }
	}
}
