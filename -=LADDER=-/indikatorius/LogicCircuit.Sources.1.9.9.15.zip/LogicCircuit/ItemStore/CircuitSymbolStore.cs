﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class CircuitSymbolStore : ItemStore<CircuitSymbol> {

		private static int logicalCircuitId;
		private static int circuitId;
		private static int x;
		private static int y;

		public CircuitSymbolStore(ProjectManager projectManager, Store.Table table,
			PinStore pinStore, LogicalCircuitStore logicalCircuitStore
		) : base(projectManager, table) {
			if(CircuitSymbolStore.logicalCircuitId == 0) {
				CircuitSymbolStore.logicalCircuitId = table.ColumnOrdinal("LogicalCircuitId");
				CircuitSymbolStore.circuitId = table.ColumnOrdinal("CircuitId");
				CircuitSymbolStore.x = table.ColumnOrdinal("X");
				CircuitSymbolStore.y = table.ColumnOrdinal("Y");
			}
			pinStore.ItemChanged += new ItemStore<Pin>.ItemChangedEventHandler(PinStoreItemChanged);
			logicalCircuitStore.ItemChanged += new ItemStore<LogicalCircuit>.ItemChangedEventHandler(LogicalCircuitStoreItemChanged);
			this.ItemChanged += new ItemStore<CircuitSymbol>.ItemChangedEventHandler(CircuitSymbolStoreItemChanged);
			projectManager.EditEnded += new EventHandler(ProjectManagerEditEnded);
		}

		protected override CircuitSymbol CreateItem(Store.Table.Row row) {
			return new CircuitSymbolItem(row);
		}

		public CircuitSymbol Create(Circuit circuit, LogicalCircuit logicalCircuit, int x, int y) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			CircuitSymbol symbol = new CircuitSymbolItem(row);
			symbol.Circuit = circuit;
			symbol.LogicalCircuit = logicalCircuit;
			symbol.X = x;
			symbol.Y = y;
			row.Add();
			symbol.RefreshGlyph();
			return symbol;
		}

		public IEnumerable<CircuitSymbol> Select(LogicalCircuit logicalCircuit) {
			return this.Select(CircuitSymbolStore.logicalCircuitId, logicalCircuit.Guid);
		}

		/// <summary>
		/// Selects all symbols of circuit on the logical circuit
		/// </summary>
		/// <param name="circuit"></param>
		/// <param name="logicalCircuit"></param>
		/// <returns></returns>
		public CircuitSymbol[] Select(Circuit circuit, LogicalCircuit logicalCircuit) {
			return this.Select(CircuitSymbolStore.circuitId, circuit.Guid, CircuitSymbolStore.logicalCircuitId, logicalCircuit.Guid);
		}

		/// <summary>
		/// Selects all symbols of the Circuit
		/// </summary>
		/// <param name="circuit"></param>
		/// <returns></returns>
		public CircuitSymbol[] Select(Circuit circuit) {
			return this.Select(CircuitSymbolStore.circuitId, circuit.Guid);
		}

		/// <summary>
		/// Checks if any symbols exist on the provided logical circuit
		/// </summary>
		/// <param name="logicalCircuit"></param>
		/// <returns></returns>
		public bool ExistOn(LogicalCircuit logicalCircuit) {
			return this.Table.Exists(CircuitSymbolStore.logicalCircuitId, logicalCircuit.Guid);
		}

		private class CircuitSymbolItem : CircuitSymbol {
			public CircuitSymbolItem(Store.Table.Row row) : base(row) {
			}
		}

		private HashSet<Pin> changedPin = new HashSet<Pin>();

		private void PinStoreItemChanged(Pin item, ItemAction action) {
			if(!item.Circuit.IsDeleted) {
				this.changedPin.Add(item);
			}
		}

		private HashSet<LogicalCircuit> changedLogicalCircuit = new HashSet<LogicalCircuit>();

		private void LogicalCircuitStoreItemChanged(LogicalCircuit logicalCircuit, ItemAction action) {
			if(action == ItemAction.Changed) {
				this.changedLogicalCircuit.Add(logicalCircuit);
			}
		}

		private void CircuitSymbolStoreItemChanged(CircuitSymbol item, ItemAction action) {
			if(action == ItemAction.Changed && item.Circuit is Pin) {
				this.changedPin.Add((Pin)item.Circuit);
			}
		}

		private void ProjectManagerEditEnded(object sender, EventArgs e) {
			try {
				Pin[] pinList = null;
				if(0 < this.changedPin.Count) {
					pinList = new Pin[this.changedPin.Count];
					this.changedPin.CopyTo(pinList);
					this.changedPin.Clear();
				}
				LogicalCircuit[] lcList = null;
				if(0 < this.changedLogicalCircuit.Count) {
					lcList = new LogicalCircuit[this.changedLogicalCircuit.Count];
					this.changedLogicalCircuit.CopyTo(lcList);
					this.changedLogicalCircuit.Clear();
				}
				if(pinList != null || lcList != null) {
					Transaction transaction = this.ProjectManager.BeginTransaction();
					bool success = false;
					try {
						if(pinList != null) {
							foreach(Pin pin in pinList) {
								foreach(CircuitSymbol symbol in this.Select(pin.Circuit)) {
									symbol.RefreshGlyph();
								}
							}
						}
						if(lcList != null) {
							foreach(LogicalCircuit lc in lcList) {
								//get all symbols of the logical circuit, not all symbols on the logical circuit
								foreach(CircuitSymbol symbol in this.Select((Circuit)lc)) {
									symbol.RefreshGlyph();
								}
							}
						}
						success = true;
					} finally {
						this.ProjectManager.EndTransaction(transaction, success);
					}
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		public void Paste(Store store, List<Symbol> result) {
			Store.Table table = store[this.Table.Ordinal];
			foreach(Store.Table.Row row in table) {
				Tracer.Assert(row.Tag == null);
				Store.Table.Row parentRow = row.Parent(CircuitSymbolStore.logicalCircuitId);
				if(parentRow != null && parentRow.Tag != null) {
					LogicalCircuit lc = parentRow.Tag as LogicalCircuit;
					if(lc != null) {
						Circuit circuit = null;
						parentRow = row.Parent(CircuitSymbolStore.circuitId);
						if(parentRow != null) {
							circuit = parentRow.Tag as Circuit;
						} else {
							Guid circuitId = (Guid)row[CircuitSymbolStore.circuitId];
							circuit = this.ProjectManager.LogicalCircuitStore.Find(circuitId);
							if(circuit == null) {
								circuit = this.ProjectManager.GateStore.Find(circuitId);
								if(circuit == null) {
									circuit = this.ProjectManager.LogicalCircuitStore.Paste(store, circuitId);
									if(circuit == null) {
										circuit = this.ProjectManager.PinStore.Paste(store, circuitId);
										if(circuit == null) {
											circuit = this.ProjectManager.ConstantStore.Paste(store, circuitId);
											if(circuit == null) {
												circuit = this.ProjectManager.CircuitButtonStore.Paste(store, circuitId);
												if(circuit == null) {
													circuit = this.ProjectManager.SplitterStore.Paste(store, circuitId);
													if(circuit == null) {
														circuit = this.ProjectManager.MemoryStore.Paste(store, circuitId);
													}
												}
											}
										}
									}
								}
							}
						}
						if(circuit != null) {
							int x = (int)row[CircuitSymbolStore.x];
							int y = (int)row[CircuitSymbolStore.y];
							CircuitSymbol symbol = this.Create(circuit, lc, x, y);
							row.Tag = symbol;
							result.Add(symbol);
						}
					}
				}
			}
		}
	}
}
