﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class WireStore : ItemStore<Wire> {

		private static int logicalCircuitId;
		private static int x1;
		private static int y1;
		private static int x2;
		private static int y2;

		public WireStore(ProjectManager projectManager, Store.Table table) : base(projectManager, table) {
			if(WireStore.logicalCircuitId == 0) {
				WireStore.logicalCircuitId = table.ColumnOrdinal("LogicalCircuitId");
				WireStore.x1 = table.ColumnOrdinal("X1");
				WireStore.y1 = table.ColumnOrdinal("Y1");
				WireStore.x2 = table.ColumnOrdinal("X2");
				WireStore.y2 = table.ColumnOrdinal("Y2");
			}
		}

		protected override Wire CreateItem(Store.Table.Row row) {
			return new WireItem(row);
		}

		public Wire Create(LogicalCircuit logicalCircuit, GridPoint point1, GridPoint point2) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			Wire wire = this.CreateItem(row);
			wire.LogicalCircuit = logicalCircuit;
			wire.Point1 = point1;
			wire.Point2 = point2;
			row.Add();
			return wire;
		}

		private class WireItem : Wire {
			public WireItem(Store.Table.Row row) : base(row) {
			}
		}

		public IEnumerable<Wire> Select(LogicalCircuit logicalCircuit) {
			return this.Select(WireStore.logicalCircuitId, logicalCircuit.Guid);
		}

		/// <summary>
		/// Checks if any wire exist on the provided logical circuit
		/// </summary>
		/// <param name="logicalCircuit"></param>
		/// <returns></returns>
		public bool ExistOn(LogicalCircuit logicalCircuit) {
			return this.Table.Exists(WireStore.logicalCircuitId, logicalCircuit.Guid);
		}

		public Wire NeedSolder(LogicalCircuit logicalCircuit, GridPoint point) {
			int count = 0;
			foreach(Wire wire in this.Select(logicalCircuit)) {
				if(wire.Point1 == point || wire.Point2 == point) {
					count++;
					if(2 < count) {
						return wire;
					}
				}
			}
			return null;
		}

		public void Paste(Store store, List<Symbol> result) {
			Store.Table table = store[this.Table.Ordinal];
			foreach(Store.Table.Row row in table) {
				Tracer.Assert(row.Tag == null);
				Store.Table.Row parentRow = row.Parent(WireStore.logicalCircuitId);
				if(parentRow != null && parentRow.Tag != null) {
					LogicalCircuit lc = parentRow.Tag as LogicalCircuit;
					if(lc != null) {
						int x1 = (int)row[WireStore.x1];
						int y1 = (int)row[WireStore.y1];
						int x2 = (int)row[WireStore.x2];
						int y2 = (int)row[WireStore.y2];
						Wire wire = this.Create(lc, new GridPoint(x1, y1), new GridPoint(x2, y2));
						row.Tag = wire;
						result.Add(wire);
					}
				}
			}
		}
	}
}
