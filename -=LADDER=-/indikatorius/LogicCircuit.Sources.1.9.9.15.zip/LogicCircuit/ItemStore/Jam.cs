﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class Jam : Item {

		private static int x;
		private static int y;

		protected Jam(Store.Table.Row row, BasePin pin, CircuitSymbol symbol, GridPoint point) : base(row) {
			Store.Table table = row.Table;
			if(Jam.x == 0) {
				Jam.x = table.ColumnOrdinal("X");
				Jam.y = table.ColumnOrdinal("Y");
			}
			this.pin = new ForeignKey<BasePin>(row, table.ColumnOrdinal("PinId"));
			this.circuitSymbol = new ForeignKey<CircuitSymbol>(row, table.ColumnOrdinal("CircuitSymbolId"));
			this.Pin = pin;
			this.CircuitSymbol = symbol;
			this.Point = point;
		}

		private ForeignKey<BasePin> pin;
		public BasePin Pin {
			get { return this.pin.Parent; }
			private set { this.pin.Parent = value; }
		}

		private ForeignKey<CircuitSymbol> circuitSymbol;
		public CircuitSymbol CircuitSymbol {
			get { return this.circuitSymbol.Parent; }
			private set { this.circuitSymbol.Parent = value; }
		}

		public int X {
			get { return (int)this.Row[Jam.x]; }
			set { this.Row[Jam.x] = value; }
		}

		public int Y {
			get { return (int)this.Row[Jam.y]; }
			set { this.Row[Jam.y] = value; }
		}

		public int AbsoluteX { get { return this.X + this.CircuitSymbol.X; } }
		public int AbsoluteY { get { return this.Y + this.CircuitSymbol.Y; } }

		public GridPoint AbsolutePoint {
			get { return new GridPoint(this.AbsoluteX, this.AbsoluteY); }
		}

		public GridPoint Point {
			get { return new GridPoint(this.X, this.Y); }
			set { this.X = value.X; this.Y = value.Y; }
		}

		public override string ToString() {
			return "Jam of " + this.Pin.ToString() + " of " + this.Pin.Circuit.ToString() +
			" on " + this.CircuitSymbol.LogicalCircuit.ToString() + "(" + this.AbsoluteX + ", " + this.AbsoluteY + ")";
		}
	}
}
