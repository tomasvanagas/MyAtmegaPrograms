﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Shapes;

namespace LogicCircuit {
	public abstract class Wire : Symbol {

		private static int x1;
		private static int y1;
		private static int x2;
		private static int y2;

		protected Wire(Store.Table.Row row) : base(row) {
			if(Wire.x1 == 0) {
				Store.Table table = row.Table;
				Wire.x1 = table.ColumnOrdinal("X1");
				Wire.y1 = table.ColumnOrdinal("Y1");
				Wire.x2 = table.ColumnOrdinal("X2");
				Wire.y2 = table.ColumnOrdinal("Y2");
			}
		}

		public int X1 {
			get { return (int)this.Row[Wire.x1]; }
			set { this.Row[Wire.x1] = value; }
		}

		public int Y1 {
			get { return (int)this.Row[Wire.y1]; }
			set { this.Row[Wire.y1] = value; }
		}

		public int X2 {
			get { return (int)this.Row[Wire.x2]; }
			set { this.Row[Wire.x2] = value; }
		}

		public int Y2 {
			get { return (int)this.Row[Wire.y2]; }
			set { this.Row[Wire.y2] = value; }
		}

		public GridPoint Point1 {
			get { return new GridPoint(this.X1, this.Y1); }
			set { this.X1 = value.X; this.Y1 = value.Y; }
		}

		public GridPoint Point2 {
			get { return new GridPoint(this.X2, this.Y2); }
			set { this.X2 = value.X; this.Y2 = value.Y; }
		}

		private Line wireGlyph;
		public Line WireGlyph {
			get {
				if(this.wireGlyph == null) {
					this.wireGlyph = Plotter.CreateGlyph(this);
				}
				return this.wireGlyph;
			}
		}

		public override FrameworkElement Glyph { get { return this.WireGlyph; } }

		public override void Shift(int x, int y) {
			this.X1 += x;
			this.Y1 += y;
			this.X2 += x;
			this.Y2 += y;
		}

		public override GridPoint Point {
			get { return this.Point1; }
			set {
				Tracer.Fail();
			}
		}

		public override string ToString() {
			return (
				"Wire on " + this.LogicalCircuit.ToString()
				+ "(" + this.X1 + ", " + this.Y1 + "):(" + this.X2 + ", " + this.Y2 + ")"
			);
		}
	}
}
