﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class MemoryStore : CircuitStore<Memory> {

		private static int writable;
		private static int writeOn1;
		private static int addressBitWidth;
		private static int dataBitWidth;
		private static int data;

		public MemoryStore(ProjectManager projectManager, Store.Table table, DevicePinStore devicePinStore) : base(projectManager, table) {
			if(MemoryStore.writable == 0) {
				MemoryStore.writable = table.ColumnOrdinal("Writable");
				MemoryStore.writeOn1 = table.ColumnOrdinal("WriteOn1");
				MemoryStore.addressBitWidth = table.ColumnOrdinal("AddressBitWidth");
				MemoryStore.dataBitWidth = table.ColumnOrdinal("DataBitWidth");
				MemoryStore.data = table.ColumnOrdinal("Data");
			}
			foreach(Memory memory in this) {
				this.CreatePins(memory, devicePinStore);
			}
		}

		public Memory Create(bool writable, int addressBitWidth, int dataBitWidth) {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			Memory memory = this.CreateItem(row);
			memory.Writable = writable;
			memory.AddressBitWidth = addressBitWidth;
			memory.DataBitWidth = dataBitWidth;
			row.Add();
			this.CreatePins(memory, this.ProjectManager.DevicePinStore);
			return memory;
		}

		protected override Memory CreateItem(Store.Table.Row row) {
			return new MemoryItem(row);
		}

		private class MemoryItem : Memory {
			public MemoryItem(Store.Table.Row row) : base(row) {}
		}

		private void CreatePins(Memory memory, DevicePinStore devicePinStore) {
			Tracer.Assert(devicePinStore.Select(memory).Length == 0);
			// The order of creation of the pins is essential for expantion algorithm.

			DevicePin address = devicePinStore.Create(memory, PinType.Input, memory.AddressBitWidth);
			address.PinSide = PinSide.Left;
			address.Name = Resources.MemoryAddressPinName;
			DevicePin data = devicePinStore.Create(memory, PinType.Output, memory.DataBitWidth);
			data.PinSide = PinSide.Right;
			data.Name = Resources.MemoryDataPinName;
			if(memory.Writable) {
				DevicePin dataIn = devicePinStore.Create(memory, PinType.Input, memory.DataBitWidth);
				dataIn.PinSide = PinSide.Left;
				dataIn.Name = Resources.MemoryDataInPinName;
				DevicePin write = devicePinStore.Create(memory, PinType.Input, 1);
				write.PinSide = PinSide.Bottom;
				memory.SetPins(address, data, dataIn, write);
				MemoryStore.UpdateWritePinName(memory);
			} else {
				memory.SetPins(address, data);
			}
		}

		public static void UpdateWritePinName(Memory memory) {
			Tracer.Assert(memory.Writable);
			memory.WritePin.Name = Resources.MemoryWritePinName(memory.WriteOn1 ? Resources.WriteOn1 : Resources.WriteOn0);
		}

		public Memory Paste(Store store, Guid memoryId) {
			Store.Table table = store[this.Table.Ordinal];
			Store.Table.Row row = table.Select(memoryId);
			if(row != null) {
				Tracer.Assert(row.Tag == null);
				bool writable = (bool)row[MemoryStore.writable];
				bool writeOn1 = (bool)row[MemoryStore.writeOn1];
				int addressBitWidth = (int)row[MemoryStore.addressBitWidth];
				int dataBitWidth = (int)row[MemoryStore.dataBitWidth];
				Memory memory = this.Create(writable, addressBitWidth, dataBitWidth);
				if(!writable) {
					string data = row[MemoryStore.data].ToString();
					if(!string.IsNullOrEmpty(data)) {
						memory.SetDataFromString(data);
					}
				} else {
					memory.WriteOn1 = writeOn1;
				}
				row.Tag = memory;
				return memory;
			}
			return null;
		}
	}
}
