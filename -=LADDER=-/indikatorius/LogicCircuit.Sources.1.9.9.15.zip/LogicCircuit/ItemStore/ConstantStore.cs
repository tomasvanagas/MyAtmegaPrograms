﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class ConstantStore : CircuitStore<Constant> {

		private static int value;
		private static int bitWidth;

		public ConstantStore(ProjectManager projectManager, Store.Table table, DevicePinStore devicePinStore) : base(projectManager, table) {
			if(ConstantStore.value == 0) {
				ConstantStore.value = table.ColumnOrdinal("Value");
				ConstantStore.bitWidth = table.ColumnOrdinal("BitWidth");
			}
			foreach(Constant constant in this) {
				devicePinStore.Create(constant, PinType.Output, constant.BitWidth);
			}
		}

		protected override Constant CreateItem(Store.Table.Row row) {
			return new ConstantItem(row);
		}

		public Constant Create() {
			Store.Table.Row row = this.Table.NewRow();
			row[0] = Guid.NewGuid();
			Constant constant = this.CreateItem(row);
			row.Add();
			this.ProjectManager.DevicePinStore.Create(constant, PinType.Output, constant.BitWidth);
			return constant;
		}

		private class ConstantItem : Constant {
			public ConstantItem(Store.Table.Row row) : base(row) {}
		}

		public Constant Paste(Store store, Guid constantId) {
			Store.Table table = store[this.Table.Ordinal];
			Store.Table.Row row = table.Select(constantId);
			if(row != null) {
				Tracer.Assert(row.Tag == null);
				int v = (int)row[ConstantStore.value];
				int width = (int)row[ConstantStore.bitWidth];
				Constant c = this.Create();
				c.BitWidth = width;
				c.Value = v;
				row.Tag = c;
				return c;
			}
			return null;
		}
	}
}
