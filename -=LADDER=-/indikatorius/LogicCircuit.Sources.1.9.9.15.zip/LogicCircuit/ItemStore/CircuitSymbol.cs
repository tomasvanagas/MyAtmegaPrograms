﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;

namespace LogicCircuit {
	public abstract class CircuitSymbol : Symbol {

		private static int circuitId;
		private static int x;
		private static int y;

		protected CircuitSymbol(Store.Table.Row row) : base(row) {
			if(CircuitSymbol.circuitId == 0) {
				Store.Table table = row.Table;
				CircuitSymbol.circuitId = table.ColumnOrdinal("CircuitId");
				CircuitSymbol.x = table.ColumnOrdinal("X");
				CircuitSymbol.y = table.ColumnOrdinal("Y");
			}
			this.circuit = new ForeignKey<Circuit>(row, CircuitSymbol.circuitId);
		}

		private ForeignKey<Circuit> circuit;
		public Circuit Circuit {
			get { return this.circuit.Parent; }
			set { this.circuit.Parent = value; }
		}

		public int X {
			get { return (int)this.Row[CircuitSymbol.x]; }
			set { this.Row[CircuitSymbol.x] = value; }
		}

		public int Y {
			get { return (int)this.Row[CircuitSymbol.y]; }
			set { this.Row[CircuitSymbol.y] = value; }
		}

		public override GridPoint Point {
			get { return new GridPoint(this.X, this.Y); }
			set { this.X = value.X; this.Y = value.Y; }
		}

		private FrameworkElement glyph;

		public void RefreshGlyph() {
			this.glyph = null;
			this.glyph = Plotter.CreateGlyph(this);
		}

		public override FrameworkElement Glyph {
			get {
				if(this.glyph == null) {
					this.glyph = Plotter.CreateGlyph(this);
				}
				return this.glyph;
			}
		}

		public FrameworkElement ProbeView { get; set; }

		public override void Shift(int x, int y) {
			this.X += x;
			this.Y += y;
		}

		private static CircuitSymbol FindSymbol(FrameworkElement frameworkElement) {
			while(frameworkElement != null && !(frameworkElement.Tag is CircuitSymbol)) {
				frameworkElement = frameworkElement.Parent as FrameworkElement;
			}
			if(frameworkElement != null) {
				return (CircuitSymbol)frameworkElement.Tag;
			}
			return null;
		}

		public void PreviewMouseDown(object sender, MouseButtonEventArgs e) {
			try {
				FrameworkElement glyph = sender as FrameworkElement;
				CircuitSymbol symbol = CircuitSymbol.FindSymbol(glyph);
				MainFrame mainFrame = MainFrame.FindMainFrame(glyph);
				CircuitSymbol.OnPressed(symbol, mainFrame);
				if(glyph != null && e.ClickCount == 2 && e.ChangedButton == MouseButton.Left) {
					CircuitSymbol.OnDoubleClick(symbol, mainFrame);
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		public void PreviewMouseUp(object sender, MouseButtonEventArgs e) {
			try {
				CircuitSymbol.OnDepressed(CircuitSymbol.FindSymbol(sender as FrameworkElement), MainFrame.FindMainFrame(this.Glyph));
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		public void PreviewKeyDown(object sender, KeyEventArgs e) {
			try {
				if(e.Key == Key.Space) {
					CircuitSymbol.OnPressed(CircuitSymbol.FindSymbol(sender as FrameworkElement), MainFrame.FindMainFrame(this.Glyph));
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		public void PreviewKeyUp(object sender, KeyEventArgs e) {
			try {
				if(e.Key == Key.Space) {
					CircuitSymbol.OnDepressed(CircuitSymbol.FindSymbol(sender as FrameworkElement), MainFrame.FindMainFrame(this.Glyph));
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private static void OnPressed(CircuitSymbol symbol, MainFrame mainFrame) {
			if(symbol != null && mainFrame.CircuitRunner.IsTurnedOn) {
				IFunctionInteractive function = mainFrame.CircuitRunner.VisibleMap.Input(symbol);
				if(function != null) {
					function.OnSymbolPress();
				}
			}
		}

		private static void OnDepressed(CircuitSymbol symbol, MainFrame mainFrame) {
			if(symbol != null && mainFrame.CircuitRunner.IsTurnedOn) {
				IFunctionInteractive function = mainFrame.CircuitRunner.VisibleMap.Input(symbol);
				if(function != null) {
					function.OnSymbolRelease();
				}
			}
		}

		private static void OnDoubleClick(CircuitSymbol symbol, MainFrame mainFrame) {
			if(symbol != null && mainFrame.CircuitRunner.IsTurnedOn) {
				IFunctionInteractive function = mainFrame.CircuitRunner.VisibleMap.Input(symbol);
				if(function != null) {
					function.OnSymbolDoubleClick();
				}
			}
		}

		public override bool Copy(Store store, bool deepCopy) {
			Tracer.Assert(deepCopy);
			this.Circuit.Copy(store, deepCopy);
			this.LogicalCircuit.Copy(store, deepCopy);
			return base.Copy(store, false);
		}

		public override string ToString() {
			return (
				"Symbol of " + this.Circuit.ToString() +
				" on " + this.LogicalCircuit.ToString() + "(" + this.X + ", " + this.Y + ")"
			);
		}
	}
}
