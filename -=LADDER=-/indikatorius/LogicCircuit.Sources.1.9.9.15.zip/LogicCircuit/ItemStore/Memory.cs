﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public abstract class Memory : Circuit {

		public const int MaxAddressBitWidth = 16;

		private static int writable;
		private static int writeOn1;
		private static int addressBitWidth;
		private static int dataBitWidth;
		private static int data;

		protected Memory(Store.Table.Row row) : base(row) {
			if(Memory.writable == 0) {
				Store.Table table = row.Table;
				Memory.writable = table.ColumnOrdinal("Writable");
				Memory.writeOn1 = table.ColumnOrdinal("WriteOn1");
				Memory.addressBitWidth = table.ColumnOrdinal("AddressBitWidth");
				Memory.dataBitWidth = table.ColumnOrdinal("DataBitWidth");
				Memory.data = table.ColumnOrdinal("Data");
			}
		}

		public bool Writable {
			get { return (bool)this.Row[Memory.writable]; }
			set { this.Row[Memory.writable] = value; }
		}

		public bool WriteOn1 {
			get { return (bool)this.Row[Memory.writeOn1]; }
			set { this.Row[Memory.writeOn1] = value; }
		}

		private static int NormalizeAddressWidth(int width) {
			return Math.Min(Memory.MaxAddressBitWidth, BasePin.NormalizeBitWidth(width));
		}

		public int AddressBitWidth {
			get { return Memory.NormalizeAddressWidth((int)this.Row[Memory.addressBitWidth]); }
			set {
				int width = Memory.NormalizeAddressWidth(value);
				this.Row[Memory.addressBitWidth] = width;
				if(this.AddressPin != null) {
					this.AddressPin.BitWidth = width;
					this.AddressPin.Name = Resources.MemoryAddressPinName;
				}
			}
		}

		public int DataBitWidth {
			get { return BasePin.NormalizeBitWidth((int)this.Row[Memory.dataBitWidth]); }
			set {
				int width = BasePin.NormalizeBitWidth(value);
				this.Row[Memory.dataBitWidth] = width;
				if(this.DataOutPin != null) {
					this.DataOutPin.BitWidth = width;
					this.DataOutPin.Name = Resources.MemoryDataPinName;
					if(this.Writable) {
						this.DataInPin.BitWidth = width;
						this.DataInPin.Name = Resources.MemoryDataInPinName;
					}
				}
			}
		}

		public int BytesPerCell {
			get { return Memory.BytesPerCellFor(this.DataBitWidth); }
		}

		public int TotalCells {
			get { return Memory.NumberCellsFor(this.AddressBitWidth); }
		}

		public int TotalBytes {
			get { return this.BytesPerCell * this.TotalCells; }
		}

		public static int BytesPerCellFor(int dataBitWidth) {
			Tracer.Assert(0 < dataBitWidth && dataBitWidth <= Pin.MaxBitWidth);
			return dataBitWidth / 8 + (((dataBitWidth % 8) == 0) ? 0 : 1);
		}
		public static int NumberCellsFor(int addressBitWidth) {
			Tracer.Assert(0 < addressBitWidth && addressBitWidth <= Memory.MaxAddressBitWidth);
			return 1 << addressBitWidth;
		}

		public static int CellValue(byte[] data, int bitWidth, int index) {
			int cellSize = Memory.BytesPerCellFor(bitWidth);
			int cellStart = index * cellSize;
			int value = 0;
			for(int i = 0; i < cellSize; i++) {
				value |= ((int)data[cellStart + i]) << (i * 8);
			}
			if(bitWidth < 32) {
				value &= (1 << bitWidth) - 1;
			}
			return value;
		}

		public static void SetCellValue(byte[] data, int bitWidth, int index, int value) {
			int cellSize = Memory.BytesPerCellFor(bitWidth);
			int cellStart = index * cellSize;
			if(bitWidth < 32) {
				value &= (1 << bitWidth) - 1;
			}
			for(int i = 0; i < cellSize; i++) {
				data[cellStart + i] = (byte)(value >> (i * 8));
			}
		}

		public static byte[] Reallocate(byte[] old, int oldAddressBitWidth, int oldDataBitWidth, int newAddressBitWidth, int newDataBitWidth) {
			Tracer.Assert(old.Length == Memory.BytesPerCellFor(oldDataBitWidth) * Memory.NumberCellsFor(oldAddressBitWidth));
			if(oldAddressBitWidth != newAddressBitWidth || oldDataBitWidth != newDataBitWidth) {
				byte[] data = new byte[Memory.BytesPerCellFor(newDataBitWidth) * Memory.NumberCellsFor(newAddressBitWidth)];
				int count = Math.Min(Memory.NumberCellsFor(oldAddressBitWidth), Memory.NumberCellsFor(newAddressBitWidth));
				for(int i = 0; i < count; i++) {
					Memory.SetCellValue(data, newDataBitWidth, i, Memory.CellValue(old, oldDataBitWidth, i));
				}
				return data;
			}
			return old;
		}

		private static byte[] Reallocate(byte[] old, int addressBitWidth, int dataBitWidth) {
			int size = Memory.BytesPerCellFor(dataBitWidth) * Memory.NumberCellsFor(addressBitWidth);
			if(old == null || old.Length != size) {
				byte[] data = new byte[size];
				if(old != null) {
					Array.Copy(old, data, Math.Min(size, old.Length));
				}
				return data;
			}
			return old;
		}

		private byte[] value = null;
		private string text = null;

		public byte[] Data {
			get {
				Tracer.Assert(!this.Writable);
				if(this.value == null || !object.ReferenceEquals(this.text, this.Row[Memory.data].ToString())) {
					this.text = this.Row[Memory.data].ToString();
					byte[] d = Convert.FromBase64String(this.text);
					if(d.Length != this.BytesPerCell * this.TotalCells) {
						d = Memory.Reallocate(d, this.AddressBitWidth, this.DataBitWidth);
					}
					this.value = d;
				}
				return this.value;
			}
			set {
				Tracer.Assert(!this.Writable);
				Tracer.Assert(value != null && value.Length == this.BytesPerCell * this.TotalCells);
				this.value = value;
				this.text = Convert.ToBase64String(value, Base64FormattingOptions.InsertLineBreaks);
				this.Row[Memory.data] = this.text;
			}
		}

		public void Erase() {
			Tracer.Assert(!this.Writable);
			this.Row[Memory.data] = string.Empty;
			this.text = string.Empty;
			this.value = null;
		}

		public void SetDataFromString(string text) {
			this.Data = Convert.FromBase64String(text);
		}

		public override string ToolTip {
			get { return this.Writable ? Resources.ToolTipRAM(this.AddressBitWidth, this.DataBitWidth) : Resources.ToolTipROM(this.AddressBitWidth, this.DataBitWidth); }
		}

		public override string Notation {
			get { return this.Writable ? Resources.RAMNotation : Resources.ROMNotation; }
			set { throw new InvalidOperationException(); }
		}

		public DevicePin AddressPin { get; private set; }
		public DevicePin DataOutPin { get; private set; }
		public DevicePin DataInPin { get; private set; }
		public DevicePin WritePin { get; private set; }

		public void SetPins(DevicePin addressPin, DevicePin dataPin) {
			Tracer.Assert(!this.Writable);
			Tracer.Assert(this.AddressPin == null);
			Tracer.Assert(addressPin != null && dataPin != null);
			this.AddressPin = addressPin;
			this.DataOutPin = dataPin;
		}

		public void SetPins(DevicePin addressPin, DevicePin dataOutPin, DevicePin dataInPin, DevicePin writePin) {
			Tracer.Assert(this.Writable);
			Tracer.Assert(this.AddressPin == null);
			Tracer.Assert(addressPin != null && dataOutPin != null && dataInPin != null && writePin != null);
			Tracer.Assert(dataOutPin.BitWidth == dataInPin.BitWidth);
			this.AddressPin = addressPin;
			this.DataOutPin = dataOutPin;
			this.DataInPin = dataInPin;
			this.WritePin = writePin;
		}
	}
}
