﻿using System;
using System.Collections.Generic;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Threading;

namespace LogicCircuit {
	public class FunctionLed : Probe, IFunctionVisual {

		public CircuitSymbol CircuitSymbol { get; private set; }

		public FunctionLed(CircuitState circuitState, CircuitSymbol symbol, int parameter) : base(circuitState, parameter) {
			Tracer.Assert(symbol.ProbeView != null);
			this.CircuitSymbol = symbol;
		}

		private static string ResourceName(State state) {
			switch(state) {
			case State.Off:
				return "LedOff";
			case State.On0:
				return "LedOn0";
			case State.On1:
				return "LedOn1";
			default:
				Tracer.Fail();
				return null;
			}
		}

		public void Redraw() {
			Shape shape = this.CircuitSymbol.ProbeView as Shape;
			if(shape != null) {
				shape.Fill = Plotter.Brush(FunctionLed.ResourceName(this[0]));
			}
		}

		public override bool Evaluate() {
			if(this.GetState()) {
				this.CircuitState.Invalidate(this);
			}
			return false;
		}

		public void TurnOn() {
		}

		public void TurnOff() {
			Shape shape = this.CircuitSymbol.ProbeView as Shape;
			if(shape != null) {
				shape.Fill = Plotter.Brush(FunctionLed.ResourceName(State.Off));
			}
		}
	}
}
