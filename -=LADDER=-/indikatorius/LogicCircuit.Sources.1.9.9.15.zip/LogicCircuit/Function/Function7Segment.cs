﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Threading;

namespace LogicCircuit {
	public class Function7Segment : Probe, IFunctionVisual {

		public CircuitSymbol CircuitSymbol { get; private set; }
		private volatile bool evaluating;
		private State[] stateCopy;

		public Function7Segment(CircuitState circuitState, CircuitSymbol symbol, int[] parameter) : base(circuitState, parameter) {
			Tracer.Assert(symbol.ProbeView != null);
			this.CircuitSymbol = symbol;
			this.stateCopy = new State[this.BitWidth];
		}

		private static string ResourceName(State state) {
			switch(state) {
			case State.Off:
				return "Led7SegmentOff";
			case State.On0:
				return "Led7SegmentOn0";
			case State.On1:
				return "Led7SegmentOn1";
			default:
				Tracer.Fail();
				return null;
			}
		}

		public void Redraw() {
			int count = 5;
			do {
				while(this.evaluating);
				this.CopyTo(this.stateCopy);
			} while(this.evaluating && 0 <= --count);
			Canvas back = this.CircuitSymbol.ProbeView as Canvas;
			Tracer.Assert(back.Children.Count == this.stateCopy.Length);
			if(back != null) {
				for(int i = 0; i < this.stateCopy.Length; i++) {
					this.SetVisual((Shape)back.Children[i], this.stateCopy[i]);
				}
			}
		}

		private void SetVisual(Shape shape, State state) {
			Brush brush = Plotter.Brush(Function7Segment.ResourceName(state));
			Line line = shape as Line;
			if(line != null) {
				line.Stroke = brush;
			} else {
				shape.Fill = brush;
			}
		}

		public override bool Evaluate() {
			this.evaluating = true;
			bool changed = false;
			try {
				changed = this.GetState();
			} finally {
				this.evaluating = false;
			}
			if(changed) {
				this.CircuitState.Invalidate(this);
			}
			return false;
		}

		public void TurnOn() {
			this.evaluating = false;
		}

		public void TurnOff() {
			Canvas back = this.CircuitSymbol.ProbeView as Canvas;
			if(back != null) {
				for(int i = 0; i < 8; i++) {
					this.SetVisual((Shape)back.Children[i], State.Off);
				}
			}
		}
	}
}
