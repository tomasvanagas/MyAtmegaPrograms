﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace LogicCircuit {
	public abstract class Function {
		private int[] parameter;
		private int[] result;
		public  CircuitState CircuitState { get; private set; }

		public IEnumerable<int> Parameter { get { return this.parameter; } }
		public IEnumerable<int> Result { get { return this.result; } }

		public string Label { get; set; }

		protected Function(CircuitState circuitState, int[] parameter, int[] result) {
			this.CircuitState = circuitState;
			this.parameter = (parameter == null) ? new int[0] : parameter;
			this.result = (result == null) ? new int[0] : result;
			this.CircuitState.DefineFunction(this);
		}
		public Function(CircuitState circuitState, int[] parameter, int minimumParameterCount, int result) : this(circuitState, parameter, new int[] { result }) {
			if(parameter == null) {
				throw new ArgumentNullException("parameter");
			}
			if(parameter.Length < minimumParameterCount) {
				throw new ArgumentException(Resources.FunctionParameter(this.Name, minimumParameterCount));
			}
		}
		public Function(CircuitState circuitState, int[] parameter, int result) : this(circuitState, parameter, 1, result) {
		}
		public Function(CircuitState circuitState, int parameter, int result) : this(circuitState, new int[] { parameter }, new int[] { result }) {
		}

		public abstract bool Evaluate();

		public string Name { get { return this.GetType().Name; } }

		public int ParameterCount { get { return this.parameter.Length; } }
		public int ResultCount { get { return this.result.Length; } }

		public static State FromBool(bool value) {
			return value ? State.On1 : State.On0;
		}

		public static char ToChar(State state) {
			switch(state) {
			case State.Off:
				return '-';
			case State.On0:
				return '0';
			case State.On1:
				return '1';
			default:
				throw Function.BadState(state);
			}
		}

		public static State FromChar(char c) {
			switch(c) {
			case '-':
				return State.Off;
			case '0':
				return State.On0;
			case '1':
				return State.On1;
			default:
				throw new Exception(Resources.UnknownStateCharacter(c));
			}
		}

		protected bool SetResult(int index, State state) {
			if(this.CircuitState[this.result[index]] != state) {
				this.CircuitState[this.result[index]] = state;
				return true;
			}
			return false;
		}
		protected bool SetResult(State state) {
			return this.SetResult(0, state);
		}
		/// <summary>
		/// Sets multibit result from the 32 bit parameter
		/// </summary>
		/// <param name="state"></param>
		/// <returns></returns>
		protected bool SetResult(int state) {
			bool changed = false;
			for(int i = 0; i < this.result.Length; i++) {
				changed |= this.SetResult(i, Function.FromBool((state & (1 << i)) != 0));
			}
			return changed;
		}

		protected static Exception BadState(State state) {
			return new Exception(Resources.UnknownState(state));
		}

		protected State And(State allOff) {
			State result = allOff;
			foreach(int index in this.parameter) {
				switch(this.CircuitState[index]) {
				case State.On0:
					return State.On0;
				case State.On1:
					result = State.On1;
					break;
				case State.Off:
					break;
				default:
					throw Function.BadState(this.CircuitState[index]);
				}
			}
			return result;
		}

		protected State Or(State allOff) {
			State result = allOff;
			foreach(int index in this.parameter) {
				switch(this.CircuitState[index]) {
				case State.On0:
					result = State.On0;
					break;
				case State.On1:
					return State.On1;
				case State.Off:
					break;
				default:
					throw Function.BadState(this.CircuitState[index]);
				}
			}
			return result;
		}

		protected static State Not(State state) {
			switch(state) {
			case State.Off:
				return State.On0;
			case State.On0:
				return State.On1;
			case State.On1:
				return State.On0;
			default:
				throw Function.BadState(state);
			}
		}

		protected State Not() {
			return Function.Not(this.CircuitState[this.parameter[0]]);
		}

		protected State ControlledState(State enable) {
			return (this.CircuitState[this.parameter[1]] == enable) ? this.CircuitState[this.parameter[0]] : State.Off;
		}

		protected int Count(State state) {
			int count = 0;
			foreach(int index in this.parameter) {
				if(this.CircuitState[index] == state) {
					count++;
				}
			}
			return count;
		}

		public override string ToString() {
			StringBuilder text = new StringBuilder();
			text.Append(this.Name);
			if(!string.IsNullOrEmpty(this.Label)) {
				text.Append('<');
				text.Append(this.Label);
				text.Append('>');
			}
			text.Append("(");
			bool comma = false;
			foreach(int p in this.parameter) {
				if(comma) {
					text.Append(", ");
				} else {
					comma = true;
				}
				text.Append(p);
			}
			text.Append(") -> [");
			comma = false;
			foreach(int r in this.result) {
				if(comma) {
					text.Append(", ");
				} else {
					comma = true;
				}
				text.Append(r);
			}
			text.Append("]");
			return text.ToString();
		}
	}

	public class OneBitConst : Function {
		private State state;
		public State State { get { return this.state; } }
		public void SetState(State state) {
			if(this.state != state) {
				this.state = state;
				this.CircuitState.MarkUpdated(this);
			}
		}

		public OneBitConst(CircuitState circuitState, State state, int result) : base(circuitState, null, new int[] { result }) {
			this.state = state;
		}
		public override bool Evaluate() {
			return this.SetResult(this.state);
		}
	}

	public class Clock : Function {
		private bool state;
		public Clock(CircuitState circuitState, int result) : base(circuitState, null, new int[] { result }) {
			this.state = false;
		}
		public void Flip() {
			this.state = !this.state;
		}
		public override bool Evaluate() {
			return this.SetResult(Function.FromBool(this.state));
		}
	}

	public class TriState : Function {
		public TriState(CircuitState circuitState, int parameter, int enable, int result) : base(
			circuitState, new int[] { parameter, enable }, result
		) {
		}
		public override bool Evaluate() {
			return this.SetResult(this.ControlledState(State.On1));
		}
	}

	public class TriStateGroup : Function {
		public TriStateGroup(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {
		}
		public override bool Evaluate() {
			return this.SetResult(this.And(State.Off));
		}
	}

	public class Not : Function {
		public Not(CircuitState circuitState, int parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(this.Not());
		}
	}

	public class And : Function {
		public And(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(this.And(State.On0));
		}
	}

	public class AndNot : Function {
		public AndNot(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(Function.Not(this.And(State.On0)));
		}
	}

	public class Or : Function {
		public Or(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(this.Or(State.On0));
		}
	}

	public class OrNot : Function {
		public OrNot(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(Function.Not(this.Or(State.On0)));
		}
	}

	public class Xor : Function {
		public Xor(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(Function.FromBool((this.Count(State.On1) == 1)));
		}
	}

	public class XorNot : Function {
		public XorNot(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(Function.FromBool((this.Count(State.On1) != 1)));
		}
	}

	public class Odd : Function {
		public Odd(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(Function.FromBool(((this.Count(State.On1) & 1) == 1)));
		}
	}

	public class Even : Function {
		public Even(CircuitState circuitState, int[] parameter, int result) : base(circuitState, parameter, result) {}
		public override bool Evaluate() {
			return this.SetResult(Function.FromBool(((this.Count(State.On1) & 1) == 0)));
		}
	}

	public abstract class Probe : Function {
		private State[] state;

		protected Probe(CircuitState circuitState, int[] parameter) : base(circuitState, parameter, null) {
			this.Init(parameter != null ? parameter.Length : 0);
		}
		protected Probe(CircuitState circuitState, int parameter) : base(circuitState, new int[] { parameter }, null) {
			this.Init(1);
		}
		private void Init(int count) {
			if(0 < count) {
				this.state = new State[count];
			}
		}

		protected bool GetState() {
			bool changed = false;
			int index = 0;
			foreach(int parameter in this.Parameter) {
				if(this.state[index] != this.CircuitState[parameter]) {
					this.state[index] = this.CircuitState[parameter];
					changed = true;
				}
				index++;
			}
			return changed;
		}

		public int BitWidth { get { return this.state != null ? this.state.Length : 0; } }
		public State this[int index] { get { return this.state[index]; } }

		protected void CopyTo(State[] copy) {
			if(copy == null || copy.Length != this.state.Length) {
				throw new ArgumentOutOfRangeException("copy");
			}
			this.state.CopyTo(copy, 0);
		}

		public string ToBinary() {
			if(this.state != null) {
				char[] c = new char[this.state.Length];
				for(int i = 0; i < this.state.Length; i++) {
					c[c.Length - i - 1] = Function.ToChar(this.state[i]);
				}
				return new string(c);
			}
			return string.Empty;
		}

		private string ToNumber(string format) {
			if(this.state != null) {
				long l = 0L;
				int count = Math.Min(this.state.Length, 64);
				for(int i = 0; i < count; i++) {
					switch(this.state[i]) {
					case State.Off:
						return string.Empty;
					case State.On0:
						break;
					case State.On1:
						l |= 1L << i;
						break;
					default:
						throw Function.BadState(this.state[i]);
					}
				}
				return string.Format(CultureInfo.InvariantCulture, format,  l);
			}
			return string.Empty;
		}

		public string ToHex() {
			return this.ToNumber("{0:X}");
		}

		public string ToDecimal() {
			return this.ToNumber("{0:G}");
		}
	}
}
