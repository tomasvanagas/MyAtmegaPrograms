﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace LogicCircuit {
	partial class MainFrame {

		public static bool IsFilePathValid(string path) {
			if(path != null && path.Length > 0) {
				try {
					if(Directory.Exists(Path.GetDirectoryName(Path.GetFullPath(path)))) {
						return true;
					}
				} catch(Exception exception) {
					Tracer.Report("MainFrame.IsPathValid", exception);
					MainFrame.Report(exception);
				}
			}
			return false;
		}

		public static bool IsDirectoryPathValid(string path) {
			if(path != null && path.Length > 0) {
				try {
					if(Directory.Exists(Path.GetFullPath(path))) {
						return true;
					}
				} catch(Exception exception) {
					Tracer.Report("MainFrame.IsPathValid", exception);
					MainFrame.Report(exception);
				}
			}
			return false;
		}

		private bool EnsureSaved() {
			if(this.ProjectManager.HasChanges) {
				MessageBoxResult result = DialogMessage.Show(this, this.Title,
					LogicCircuit.Resources.MessageSaveFile(this.ProjectManager.ProjectStore.Project.Name), null,
					MessageBoxImage.Question, MessageBoxButton.YesNoCancel
				);
				switch(result) {
				case MessageBoxResult.Yes:
					this.Save();
					break;
				case MessageBoxResult.No:
					break;
				case MessageBoxResult.Cancel:
					this.Status = LogicCircuit.Resources.OperationCanceled;
					return false;
				}
			}
			return true;
		}

		private void New() {
			if(this.EnsureSaved()) {
				this.Power(false);
				this.ProjectManager.New();
				this.NotifyLoad();
			}
		}

		private void Load(string file) {
			this.Power(false);
			if(MainFrame.IsFilePathValid(file) && File.Exists(file)) {
				this.ProjectManager.Load(file);
				Settings.User.AddRecentFile(file);
			}
		}

		private void Open() {
			if(this.EnsureSaved()) {
				OpenFileDialog dialog = new OpenFileDialog();
				string file = Settings.User.LastFile;
				if(MainFrame.IsFilePathValid(file)) {
					dialog.InitialDirectory = Path.GetDirectoryName(Path.GetFullPath(file));
				}
				dialog.Filter = MainFrame.FileFilter;
				dialog.DefaultExt = MainFrame.FileExtention;
				bool? result = dialog.ShowDialog(this);
				if(result.HasValue && result.Value) {
					file = dialog.FileName;
					this.Load(file);
					this.NotifyLoad();
					this.Status = LogicCircuit.Resources.Ready;
				}
			}
		}

		private void SaveAs() {
			string file = this.ProjectManager.File;
			if(!MainFrame.IsFilePathValid(file)) {
				file = Settings.User.LastFile;
				string dir;
				if(MainFrame.IsFilePathValid(file)) {
					dir = Path.GetDirectoryName(file);
				} else {
					dir = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
				}
				file = Path.Combine(dir, this.ProjectManager.ProjectStore.Project.Name + MainFrame.FileExtention);
			}
			SaveFileDialog dialog = new SaveFileDialog();
			dialog.FileName = file;
			dialog.Filter = MainFrame.FileFilter;
			dialog.DefaultExt = MainFrame.FileExtention;
			bool? result = dialog.ShowDialog(this);
			if(result.HasValue && result.Value) {
				file = dialog.FileName;
				this.ProjectManager.Save(file);
				Settings.User.AddRecentFile(file);
				this.Status = LogicCircuit.Resources.FileSaved(file);
				this.OnPropertyChanged("Caption");
			}
		}

		private void Save() {
			if(MainFrame.IsFilePathValid(this.ProjectManager.File)) {
				this.ProjectManager.Save();
				Settings.User.AddRecentFile(this.ProjectManager.File);
				this.Status = LogicCircuit.Resources.FileSaved(this.ProjectManager.File);
			} else {
				this.SaveAs();
			}
		}
	}
}
