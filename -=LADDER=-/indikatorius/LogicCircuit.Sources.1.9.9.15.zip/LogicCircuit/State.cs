﻿using System;

namespace LogicCircuit {
	public enum State : byte {
		Off,
		On0,
		On1
	}
}
