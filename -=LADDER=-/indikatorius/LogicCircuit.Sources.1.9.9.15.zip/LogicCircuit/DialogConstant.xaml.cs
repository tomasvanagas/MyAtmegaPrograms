﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace LogicCircuit {
	/// <summary>
	/// Interaction logic for DialogConstant.xaml
	/// </summary>
	public partial class DialogConstant : Window {

		private SettingsWindowLocationCache windowLocation;
		public SettingsWindowLocationCache WindowLocation { get { return this.windowLocation ?? (this.windowLocation = new SettingsWindowLocationCache(this)); } }
		private Constant constant;

		public DialogConstant(Constant constant) {
			this.DataContext = this;
			this.constant = constant;
			this.InitializeComponent();
			this.value.Text = constant.Notation;
			for(int i = 1; i <= BasePin.MaxBitWidth; i++) {
				this.bitWidth.Items.Add(i);
			}
			this.bitWidth.SelectedItem = this.constant.BitWidth;
		}

		private void ButtonOkClick(object sender, RoutedEventArgs e) {
			Transaction transaction = this.constant.ProjectManager.BeginTransaction();
			bool success = false;
			try {
				this.constant.BitWidth = (int)this.bitWidth.SelectedItem;
				this.constant.Value = int.Parse(this.value.Text.Trim(), NumberStyles.HexNumber);
				foreach(CircuitSymbol symbol in this.constant.ProjectManager.CircuitSymbolStore.Select(this.constant)) {
					symbol.RefreshGlyph();
				}
				success = true;
			} catch(Exception exception) {
				MainFrame.Report(exception);
			} finally {
				this.constant.ProjectManager.EndTransaction(transaction, success);
			}
			MainFrame mainFrame = this.Owner as MainFrame;
			if(mainFrame != null) {
				mainFrame.CircuitEditor.Refresh();
			}
			this.Close();
		}
	}
}
