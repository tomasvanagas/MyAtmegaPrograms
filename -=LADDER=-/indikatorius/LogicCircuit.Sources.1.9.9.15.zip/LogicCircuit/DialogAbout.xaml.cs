﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace LogicCircuit {
	/// <summary>
	/// Interaction logic for DialogAbout.xaml
	/// </summary>
	public partial class DialogAbout : Window {

		public string Version { get; set; }

		public DialogAbout() {
			this.Version = this.GetType().Assembly.GetName().Version.ToString();
			this.DataContext = this;
			this.InitializeComponent();
		}

		private void WebRequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e) {
			Hyperlink link = sender as Hyperlink;
			if(link != null) {
				Process.Start(link.NavigateUri.AbsoluteUri);
			}
		}
	}
}
