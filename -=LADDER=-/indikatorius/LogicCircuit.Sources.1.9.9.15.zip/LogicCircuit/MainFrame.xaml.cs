﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace LogicCircuit {
	/// <summary>
	/// Interaction logic for MainFrame.xaml
	/// </summary>
	public partial class MainFrame : Window, INotifyPropertyChanged {

		private const string FileExtention = ".CircuitProject";
		private static readonly string FileFilter = LogicCircuit.Resources.FileFilter(MainFrame.FileExtention);
		private static MainFrame currentMainFrame;

		public event PropertyChangedEventHandler PropertyChanged;

		private SettingsWindowLocationCache windowLocation;
		public SettingsWindowLocationCache WindowLocation { get { return this.windowLocation ?? (this.windowLocation = new SettingsWindowLocationCache(this)); } }

		public ProjectManager ProjectManager { get; private set; }
		public CircuitEditor CircuitEditor { get; private set; }
		public CircuitRunner CircuitRunner { get; private set; }

		public MainFrame() {
			Tracer.Assert(MainFrame.currentMainFrame == null);
			MainFrame.currentMainFrame = this;
			this.ProjectManager = new ProjectManager();
			this.CircuitRunner = new CircuitRunner(this.ProjectManager, this);
			this.DataContext = this;
			this.InitializeComponent();
			this.Loaded += new RoutedEventHandler(MainFrameLoaded);
			this.CircuitEditor = new CircuitEditor(this, this.diagram, this.ProjectManager);
		}

		public string Caption {
			get { return LogicCircuit.Resources.MainFrameCaption(this.ProjectManager.File); }
		}

		public double Zoom {
			get { return this.ProjectManager.ProjectStore.Project.Zoom; }
			set {
				Transaction transaction = this.ProjectManager.BeginTransaction();
				bool success = false;
				try {
					this.ProjectManager.ProjectStore.Project.Zoom = value;
					success = true;
				} finally {
					this.ProjectManager.EndTransaction(transaction, success);
				}
			}
		}

		public Brush GridBrush { get { return Plotter.CircuitGrid; } }

		public CircuitDescriptorList CircuitDescriptorList { get { return new CircuitDescriptorList(this.ProjectManager, this); } }

		public LogicalCircuit CurrentLogicalCircuit { get { return this.ProjectManager.ProjectStore.Project.LogicalCircuit; } }

		private string statusText = string.Empty;
		private volatile bool statusChanged = false;
		public string Status {
			get { return this.statusText; }
			set {
				string text = (value == null) ? string.Empty : value;
				if(0 < text.Length) {
					text = Regex.Replace(text.Trim(), @"\s+", " ");
				}
				if(this.statusText != text) {
					this.statusText = text;
					if(!this.statusChanged) {
						this.statusChanged = true;
						this.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle,
							new Action(this.NotifyStatusChanged)
						);
					}
				}
			}
		}

		private void NotifyStatusChanged() {
			this.statusChanged = false;
			this.OnPropertyChanged("Status");
		}

		public int Frequency {
			get { return 500 / this.CircuitRunner.HalfPeriod; }
			set { this.CircuitRunner.HalfPeriod = 500 / value; }
		}

		public bool IsMaxSpeed {
			get { return this.CircuitRunner.MaxSpeed; }
			set { this.CircuitRunner.MaxSpeed = value; }
		}

		private Visibility performanceDeprivation = Visibility.Hidden;
		public Visibility PerformanceDeprivation {
			get {
				return this.performanceDeprivation;
			}
		}

		public void NotifyPerformance(bool slow) {
			Visibility v = slow ? Visibility.Visible : Visibility.Hidden;
			if(this.performanceDeprivation != v) {
				this.performanceDeprivation = v;
				this.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(this.NotifyPerformanceChanged));
			}
		}

		private void NotifyPerformanceChanged() {
			this.OnPropertyChanged("PerformanceDeprivation");
		}

		public static void Report(Exception exception) {
			if(MainFrame.currentMainFrame != null) {
				MainFrame.currentMainFrame.ReportException(exception);
			} else {
				Tracer.Report("Error", exception);
			}
		}

		public static void ErrorMessage(string message) {
			if(MainFrame.currentMainFrame != null) {
				MainFrame.currentMainFrame.ShowErrorMessage(message, null);
			}
		}

		public static MainFrame FindMainFrame(FrameworkElement frameworkElement) {
			while(frameworkElement != null && !(frameworkElement is MainFrame)) {
				frameworkElement = frameworkElement.Parent as FrameworkElement;
			}
			return (frameworkElement as MainFrame) ?? MainFrame.currentMainFrame;
		}

		private void ShowErrorMessage(string message, string details) {
			if(!this.Dispatcher.CheckAccess()) {
				this.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle,
					new Action<string, string>(this.ShowErrorMessage), message, details
				);
			} else {
				DialogMessage.Show(this,
					LogicCircuit.Resources.MainFrameCaption(null), message, details, MessageBoxImage.Error, MessageBoxButton.OK
				);
				this.Power(false);
			}
		}

		private void ReportException(Exception exception) {
			CircuitException circuitException = exception as CircuitException;
			if(circuitException != null && circuitException.Cause == Cause.UserError) {
				this.ShowErrorMessage(exception.Message, null);
			} else {
				this.ShowErrorMessage(exception.Message, exception.ToString());
			}
		}

		private void OnPropertyChanged(string propertyName) {
			PropertyChangedEventHandler handler = this.PropertyChanged;
			if(handler != null) {
				handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		private void NotifyLoad() {
			this.ProjectManager.ProjectStore.ItemChanged += new ItemStore<Project>.ItemChangedEventHandler(ProjectStoreItemChanged);
			this.ProjectManager.LogicalCircuitStore.ItemChanged += new ItemStore<LogicalCircuit>.ItemChangedEventHandler(LogicalCircuitStoreItemChanged);
			this.OnPropertyChanged("Zoom");
			this.OnPropertyChanged("CircuitDescriptorList");
			this.OnPropertyChanged("CurrentLogicalCircuit");
			this.OnPropertyChanged("Caption");
			this.CircuitEditor.OnProjectLoad();
			this.CircuitEditor.Refresh();
		}

		private void ProjectStoreItemChanged(Project item, ItemAction action) {
			try {
				this.OnPropertyChanged("Zoom");
				this.OnPropertyChanged("CurrentLogicalCircuit");
			} catch(Exception exception) {
				Tracer.Report("MainFrame.ProjectStoreItemChanged", exception);
				this.ReportException(exception);
			}
		}

		private void LogicalCircuitStoreItemChanged(LogicalCircuit item, ItemAction action) {
			try {
				this.OnPropertyChanged("CurrentLogicalCircuit");
			} catch(Exception exception) {
				Tracer.Report("MainFrame.LogicalCircuitStoreItemChanged", exception);
				this.ReportException(exception);
			}
		}

		private void MainFrameLoaded(object sender, RoutedEventArgs e) {
			this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, new Action(this.PostLoaded));
		}

		private void PostLoaded() {
			try {
				if(!string.IsNullOrEmpty(App.FileToOpen) && File.Exists(App.FileToOpen)) {
					this.Load(App.FileToOpen);
				} else if(Settings.User.LoadLastFileOnStartup) {
					this.Load(Settings.User.LastFile);
				}
				this.NotifyLoad();
				this.Status = LogicCircuit.Resources.Ready;
			} catch(Exception exception) {
				Tracer.Report("MainFrame.PostLoaded", exception);
				this.ReportException(exception);
				this.ProjectManager.New();
			}
		}

		protected override void OnClosing(System.ComponentModel.CancelEventArgs e) {
			base.OnClosing(e);
			try {
				if(!this.EnsureSaved()) {
					e.Cancel = true;
				} else {
					Settings.User.Save();
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.OnClosing", exception);
				this.ReportException(exception);
			}
		}

		private void DescriptorMouseDown(object sender, MouseButtonEventArgs e) {
			try {
				this.CircuitEditor.DescriptorMouseDown((FrameworkElement)sender, e);
			} catch(Exception exception) {
				Tracer.Report("MainFrame.DescriptorMouseDown", exception);
				this.ReportException(exception);
			}
		}

		private void DescriptorMouseUp(object sender, MouseButtonEventArgs e) {
			try {
				this.CircuitEditor.DescriptorMouseUp((FrameworkElement)sender, e);
			} catch(Exception exception) {
				Tracer.Report("MainFrame.DescriptorMouseUp", exception);
				this.ReportException(exception);
			}
		}

		private void DescriptorMouseMove(object sender, MouseEventArgs e) {
			try {
				this.CircuitEditor.DescriptorMouseMove((FrameworkElement)sender, e);
			} catch(Exception exception) {
				Tracer.Report("MainFrame.DescriptorMouseMove", exception);
				this.ReportException(exception);
			}
		}

		private void Power(bool pwerOn) {
			this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, new Action(() => this.PowerSwitch.IsChecked = pwerOn));
		}

		private void PowerSwitchOn(object sender, RoutedEventArgs e) {
			try {
				this.CircuitEditor.TurnOn();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.PowerSwitchOn", exception);
				this.ReportException(exception);
			}
		}

		private void PowerSwitchOff(object sender, RoutedEventArgs e) {
			try {
				this.CircuitEditor.TurnOff();
			} catch(Exception exception) {
				Tracer.Report("MainFrame.PowerSwitchOff", exception);
				this.ReportException(exception);
			}
		}

		private void PowerButtonMouseDown(object sender, MouseButtonEventArgs e) {
			try {
				if(e.ChangedButton == MouseButton.Left) {
					this.Power(this.PowerSwitch.IsChecked.HasValue && !this.PowerSwitch.IsChecked.Value);
				}
			} catch(Exception exception) {
				Tracer.Report("MainFrame.PowerButtonMouseDown", exception);
				this.ReportException(exception);
			}
		}

		private TreeViewItem Container(TreeView treeView, CircuitMap map) {
			Tracer.Assert(map != null);
			if(map.Parent == null) {
				return (TreeViewItem)treeView.ItemContainerGenerator.ContainerFromItem(map);
			} else {
				TreeViewItem parent = this.Container(treeView, map.Parent);
				if(parent != null) {
					parent.IsExpanded = true;
					return (TreeViewItem)parent.ItemContainerGenerator.ContainerFromItem(map);
				} else {
					return null;
				}
			}
		}

		private void RunningMapTreeViewSelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e) {
			try {
				if(sender == e.OriginalSource && e.NewValue != null && !object.ReferenceEquals(e.OldValue, e.NewValue)) {
					TreeViewItem item = this.Container((TreeView)sender, (CircuitMap)e.NewValue);
					if(item != null) {
						item.IsExpanded = true;
						item.BringIntoView();
					}
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}

		private void RunningMapTreeViewMouseDoubleClick(object sender, MouseButtonEventArgs e) {
			try {
				if(e.ChangedButton == MouseButton.Left && this.CircuitRunner.IsTurnedOn) {
					TreeView treeView = sender as TreeView;
					if(treeView != null && treeView.SelectedItem != null) {
						CircuitMap map = treeView.SelectedItem as CircuitMap;
						if(map != null) {
							this.CircuitEditor.OpenLogicalCircuit(map);
							TreeViewItem item = this.Container(treeView, map);
							if(item != null) {
								item.IsExpanded = true;
							}
							e.Handled = true;
						}
					}
				}
			} catch(Exception exception) {
				MainFrame.Report(exception);
			}
		}
	}
}
