﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;

namespace LogicCircuit {
	public class ButtonControl : Button {

		public ButtonControl() : base() {
			//this.Clickable = false;
		}

		public bool Clickable { get; set; }

		protected override void OnMouseDown(System.Windows.Input.MouseButtonEventArgs e) {
			if(this.Clickable) {
				base.OnMouseDown(e);
			}
		}
		protected override void OnMouseUp(System.Windows.Input.MouseButtonEventArgs e) {
			if(this.Clickable) {
				base.OnMouseUp(e);
			}
		}
		protected override void OnMouseLeftButtonDown(System.Windows.Input.MouseButtonEventArgs e) {
			if(this.Clickable) {
				base.OnMouseLeftButtonDown(e);
			}
		}
		protected override void OnMouseLeftButtonUp(System.Windows.Input.MouseButtonEventArgs e) {
			if(this.Clickable) {
				base.OnMouseLeftButtonUp(e);
			}
		}
	}
}
