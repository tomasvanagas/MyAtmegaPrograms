﻿using System;
using System.Collections.Generic;

namespace LogicCircuit {
	public class PinComparer : IComparer<BasePin> {
		public static readonly PinComparer Comparer = new PinComparer();

		public int Compare(BasePin x, BasePin y) {
			Tracer.Assert(x.GetType() == y.GetType());
			//Tracer.Assert(x.PinSide == y.PinSide);

			DevicePin dp1 = x as DevicePin;
			if(dp1 != null) {
				DevicePin dp2 = (DevicePin)y;
				return dp1.Order - dp2.Order;
			} else {
				CircuitSymbol[] s1 = x.ProjectManager.CircuitSymbolStore.Select(x);
				CircuitSymbol[] s2 = x.ProjectManager.CircuitSymbolStore.Select(y);
				if(s1 != null && s1.Length == 1 && s2 != null && s2.Length == 1) {
					int d = s1[0].Y - s2[0].Y;
					if(d == 0) {
						d = s1[0].X - s2[0].X;
						if(d == 0) {
							return StringComparer.Ordinal.Compare(x.Name, y.Name);
						}
					}
					return d;
				} else {
					return StringComparer.Ordinal.Compare(x.Name, y.Name);
				}
			}
		}
	}
}
