﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace LogicCircuit {
	partial class CircuitEditor {
		private Dictionary<Symbol, Marker> selection = new Dictionary<Symbol, Marker>();

		public int SelectionCount { get { return this.selection.Count; } }

		public Marker Select(Symbol symbol) {
			Marker marker;
			if(!this.selection.TryGetValue(symbol, out marker)) {
				marker = new Marker(symbol);
				this.selection.Add(symbol, marker);
			}
			return marker;
		}

		public void Select(IEnumerable<Symbol> symbol) {
			foreach(Symbol s in symbol) {
				this.Select(s);
			}
		}

		private void Select(Rect area) {
			foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
				Rect item = new Rect(Canvas.GetLeft(symbol.Glyph), Canvas.GetTop(symbol.Glyph), symbol.Glyph.Width, symbol.Glyph.Height);
				if(area.Contains(item)) {
					this.Select(symbol);
				}
			}
			foreach(Wire wire in this.LogicalCircuit.Wire) {
				Line line = (Line)wire.Glyph;
				if(area.Contains(line.X1, line.Y1) && area.Contains(line.X2, line.Y2)) {
					this.Select(wire);
				}
			}
		}

		public void SelectAll() {
			if(this.InEditMode) {
				foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
					this.Select(symbol);
				}
				foreach(Wire wire in this.LogicalCircuit.Wire) {
					this.Select(wire);
				}
			}
		}

		public void SelectAllWires() {
			if(this.InEditMode) {
				foreach(Wire wire in this.LogicalCircuit.Wire) {
					this.Select(wire);
				}
			}
		}

		public void SelectFreeWires() {
			if(this.InEditMode) {
				Dictionary<GridPoint, int> pointCount = new Dictionary<GridPoint, int>();
				Dictionary<GridPoint, Wire> firstWire = new Dictionary<GridPoint, Wire>();
				foreach(Wire wire in this.LogicalCircuit.Wire) {
					Tracer.Assert(wire.Point1 != wire.Point2);
					int count;
					if(pointCount.TryGetValue(wire.Point1, out count)) {
						if(count < 2) {
							pointCount[wire.Point1] = count + 1;
						}
					} else {
						pointCount.Add(wire.Point1, 1);
						firstWire.Add(wire.Point1, wire);
					}
					if(pointCount.TryGetValue(wire.Point2, out count)) {
						if(count < 2) {
							pointCount[wire.Point2] = count + 1;
						}
					} else {
						pointCount.Add(wire.Point2, 1);
						firstWire.Add(wire.Point2, wire);
					}
				}
				foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
					foreach(Jam jam in this.ProjectManager.JamStore.Select(symbol)) {
						int count;
						if(pointCount.TryGetValue(jam.AbsolutePoint, out count) && count < 2) {
							pointCount[jam.AbsolutePoint] = count + 1;
						}
					}
				}
				int freeWireCount = 0;
				foreach(GridPoint point in pointCount.Keys) {
					if(pointCount[point] < 2) {
						this.Select(firstWire[point]);
						freeWireCount++;
					}
				}
				MainFrame.Status = Resources.MessageFreeWireCount(freeWireCount);
			}
		}

		public void SelectFloatingSymbols() {
			if(this.InEditMode) {
				HashSet<GridPoint> wirePoint = new HashSet<GridPoint>();
				foreach(Wire wire in this.LogicalCircuit.Wire) {
					wirePoint.Add(wire.Point1);
					wirePoint.Add(wire.Point2);
				}
				int count = 0;
				foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
					foreach(Jam jam in this.ProjectManager.JamStore.Select(symbol)) {
						if(!wirePoint.Contains(jam.AbsolutePoint)) {
							this.Select(symbol);
							count++;
							break;
						}
					}
				}
				MainFrame.Status = Resources.MessageFloatingSymbolCount(count);
			}
		}

		public void SelectAllButWires() {
			if(this.InEditMode) {
				foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
					this.Select(symbol);
				}
			}
		}

		public void UnselectAllWires() {
			if(this.InEditMode) {
				foreach(Wire wire in this.LogicalCircuit.Wire) {
					Marker marker;
					if(this.selection.TryGetValue(wire, out marker)) {
						this.Unselect(marker);
					}
				}
			}
		}

		public void UnselectAllButWires() {
			if(this.InEditMode) {
				foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
					Marker marker;
					if(this.selection.TryGetValue(symbol, out marker)) {
						this.Unselect(marker);
					}
				}
			}
		}

		public void SelectAllProbes(bool withWire) {
			if(this.InEditMode) {
				foreach(CircuitSymbol symbol in this.LogicalCircuit.CircuitSymbol) {
					Gate gate = symbol.Circuit as Gate;
					if(gate != null && gate.GateType == GateType.Probe) {
						this.Select(symbol);
						if(withWire) {
							Jam[] jam = this.ProjectManager.JamStore.Select(symbol);
							Tracer.Assert(jam != null && jam.Length == 1);
							foreach(Wire wire in this.LogicalCircuit.Wire) {
								if(wire.Point1 == jam[0].AbsolutePoint || wire.Point2 == jam[0].AbsolutePoint) {
									this.Select(wire);
								}
							}
						}
					}
				}
			}
		}

		private void Unselect(Marker marker) {
			this.selection.Remove(marker.Symbol);
			marker.Delete();
		}

		public void ClearSelection() {
			foreach(Marker marker in this.selection.Values) {
				marker.Delete();
			}
			this.selection.Clear();
		}

		public IEnumerable<Symbol> Selection() {
			return new List<Symbol>(this.selection.Keys);
		}

		private Marker Marker(Symbol symbol) {
			Marker marker = null;
			this.selection.TryGetValue(symbol, out marker);
			return marker;
		}

		private void SelectConductor(Wire wire) {
			ConductorMap map = new ConductorMap(this.LogicalCircuit);
			Conductor conductor;
			if(map.TryGetValue(wire.Point1, out conductor)) {
				int count = 0;
				foreach(Wire w in conductor.Wires) {
					this.Select(w);
					count++;
				}
				this.MainFrame.Status = Resources.MessageConductor(count);
			}
		}

		private void UnselectConductor(Wire wire) {
			ConductorMap map = new ConductorMap(this.LogicalCircuit);
			Conductor conductor;
			if(map.TryGetValue(wire.Point1, out conductor)) {
				foreach(Wire w in conductor.Wires) {
					Marker marker = this.Marker(w);
					if(marker != null) {
						this.Unselect(marker);
					}
				}
			}
		}
	}
}
