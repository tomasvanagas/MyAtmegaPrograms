﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace LogicCircuit {
	public class MarkerArea {

		public Canvas Canvas { get; private set; }
		public Rectangle Glyph { get; private set; }
		public Point Point0 { get; private set; }

		public MarkerArea(Canvas canvas, Point point0, Point point1) {
			this.Canvas = canvas;
			this.Point0 = point0;
			this.Glyph = new Rectangle();
			this.Glyph.Tag = this;
			this.Glyph.Width = MarkerPoint.Size;
			this.Glyph.Height = MarkerPoint.Size;
			this.Glyph.Stroke = Plotter.MarkerStroke;
			this.Glyph.StrokeThickness = 1;
			this.Glyph.Fill = Plotter.MarkerFill;
			Canvas.SetZIndex(this.Glyph, int.MaxValue);
			this.MoveTo(point1);
			this.Canvas.Children.Add(this.Glyph);
		}

		public void MoveTo(Point point) {
			Rect rect = new Rect(this.Point0, point);
			Canvas.SetLeft(this.Glyph, rect.X);
			Canvas.SetTop(this.Glyph, rect.Y);
			this.Glyph.Width = rect.Width;
			this.Glyph.Height = rect.Height;
		}

		public Rect Area(Point point) {
			return new Rect(this.Point0, point);
		}

		public void Delete() {
			this.Canvas.Children.Remove(this.Glyph);
			this.Canvas = null;
			this.Glyph = null;
		}
	}
}
