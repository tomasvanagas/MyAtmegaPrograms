﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicCircuit;

namespace UnitTest {
	/// <summary>
	///This is a test class for CircuitStateTest and is intended
	///to contain all CircuitStateTest Unit Tests
	///</summary>
	[TestClass()]
	public class CircuitStateTest {

		#region Additional test attributes
		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext { get; set; }

		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion

		/// <summary>
		/// A test for CircuitState Constructor
		/// This will be tested by other methods
		///</summary>
		//[TestMethod()]
		//public void CircuitStateConstructorTest() {
		//}

		/// <summary>
		///A test for Item
		///</summary>
		[TestMethod()]
		public void ItemTest() {
			CircuitState target = new CircuitState();
			Assert.AreEqual<int>(0, target.Count);
			target.ReserveState(2);
			Assert.AreEqual<int>(2, target.Count);
			Assert.AreEqual<State>(State.Off, target[0]);
			Assert.AreEqual<State>(State.Off, target[1]);
			target[0] = State.On0;
			target[1] = State.On1;
			Assert.AreEqual<State>(State.On0, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
		}

		/// <summary>
		/// A test for Count
		/// This will be tested by other methods
		///</summary>
		//[TestMethod()]
		//public void CountTest() {
		//}

		/// <summary>
		/// A test for ReserveState
		/// This will be tested by other methods
		///</summary>
		//[TestMethod()]
		//public void ReserveStateTest() {
		//}

		/// <summary>
		///A test for DefineFunction
		/// This will be tested by other methods
		///</summary>
		//[TestMethod()]
		//public void DefineFunctionTest() {
		//}

		/// <summary>
		///A test for Evaluate
		///</summary>
		[TestMethod()]
		public void EvaluateTest() {
			CircuitState target = new CircuitState();
			target.ReserveState(3);
			OneBitConst c1 = new OneBitConst(target, State.On0, 0);
			OneBitConst c2 = new OneBitConst(target, State.On1, 1);
			And and = new And(target, new int[] { 0, 1 }, 2);
			bool success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On0, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
			Assert.AreEqual<State>(State.On0, target[2]);
		}

		/// <summary>
		///A test for MarkUpdated
		///</summary>
		[TestMethod()]
		public void MarkUpdatedTest() {
			CircuitState target = new CircuitState();
			target.ReserveState(3);
			OneBitConst c1 = new OneBitConst(target, State.On0, 0);
			OneBitConst c2 = new OneBitConst(target, State.On1, 1);
			And and = new And(target, new int[] { 0, 1 }, 2);
			bool success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On0, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
			Assert.AreEqual<State>(State.On0, target[2]);

			c1.SetState(State.On1);
			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On1, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
			Assert.AreEqual<State>(State.On1, target[2]);
		}

		/// <summary>
		///A test for ToString
		///</summary>
		[TestMethod()]
		public void ToStringTest() {
			CircuitState target = new CircuitState();
			target.ReserveState(3);
			target[0] = State.On0;
			target[2] = State.On1;
			string expected = "0-1";
			string actual = target.ToString();
			Assert.AreEqual(expected, actual);
		}

		/// <summary>
		/// A test for "real" circuit - RS trigger
		/// </summary>
		[TestMethod()]
		public void RSTriggerTest() {
			CircuitState target = new CircuitState();
			target.ReserveState(4);
			OneBitConst c1 = new OneBitConst(target, State.On0, 0);
			OneBitConst c2 = new OneBitConst(target, State.On0, 1);
			AndNot g1 = new AndNot(target, new int[] { 0, 3 }, 2);
			AndNot g2 = new AndNot(target, new int[] { 2, 1 }, 3);
			bool success;

			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On0, target[0]);
			Assert.AreEqual<State>(State.On0, target[1]);
			Assert.AreEqual<State>(State.On1, target[2]);
			Assert.AreEqual<State>(State.On1, target[3]);

			c1.SetState(State.On1);
			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On1, target[0]);
			Assert.AreEqual<State>(State.On0, target[1]);
			Assert.AreEqual<State>(State.On0, target[2]);
			Assert.AreEqual<State>(State.On1, target[3]);

			c2.SetState(State.On1);
			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On1, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
			Assert.AreEqual<State>(State.On0, target[2]);
			Assert.AreEqual<State>(State.On1, target[3]);

			c1.SetState(State.On0);
			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On0, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
			Assert.AreEqual<State>(State.On1, target[2]);
			Assert.AreEqual<State>(State.On0, target[3]);

			c2.SetState(State.On0);
			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On0, target[0]);
			Assert.AreEqual<State>(State.On0, target[1]);
			Assert.AreEqual<State>(State.On1, target[2]);
			Assert.AreEqual<State>(State.On1, target[3]);

			c2.SetState(State.On1);
			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On0, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
			Assert.AreEqual<State>(State.On1, target[2]);
			Assert.AreEqual<State>(State.On0, target[3]);

			c1.SetState(State.On1);
			success = target.Evaluate();
			Assert.IsTrue(success);
			Assert.AreEqual<State>(State.On1, target[0]);
			Assert.AreEqual<State>(State.On1, target[1]);
			Assert.AreEqual<State>(State.On1, target[2]);
			Assert.AreEqual<State>(State.On0, target[3]);
		}
	}
}
