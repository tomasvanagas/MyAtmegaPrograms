﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicCircuit;

namespace UnitTest {
	public class ClockSocket {

		public CircuitState CircuitState { get; private set; }

		public FunctionConstant CConstant { get; private set; }

		public FunctionProbe HProbe { get; private set; }
		public FunctionProbe MProbe { get; private set; }
		public FunctionProbe SProbe { get; private set; }

		public ClockSocket(
			CircuitState circuitState,
			FunctionConstant cConstant,
			FunctionProbe hProbe,
			FunctionProbe mProbe,
			FunctionProbe sProbe
		) {
			Assert.IsNotNull(circuitState);
			Assert.IsNotNull(cConstant);
			Assert.IsNotNull(hProbe);
			Assert.IsNotNull(mProbe);
			Assert.IsNotNull(sProbe);

			this.CircuitState = circuitState;
			this.CConstant = cConstant;
			this.HProbe = hProbe;
			this.MProbe = mProbe;
			this.SProbe = sProbe;

			Assert.AreEqual<int>(1, this.CConstant.BitWidth);
			Assert.AreEqual<int>(8, this.HProbe.BitWidth);
			Assert.AreEqual<int>(8, this.MProbe.BitWidth);
			Assert.AreEqual<int>(8, this.SProbe.BitWidth);
		}

		public State C {
			get { return this.CConstant.Value == 0 ? State.On0 : State.On1; }
			set { this.CConstant.Value = (this.Check(value) == State.On0 ? 0 : 1); }
		}

		public int H { get { return this.Value(this.HProbe, 24); } }
		public int M { get { return this.Value(this.MProbe, 60); } }
		public int S { get { return this.Value(this.SProbe, 60); } }

		public void Start() {
			this.C = State.On0;
			Assert.IsTrue(this.CircuitState.Evaluate());

			Assert.AreEqual<int>(0, this.H);
			Assert.AreEqual<int>(0, this.M);
			Assert.AreEqual<int>(0, this.S);
		}

		public TimeSpan Tick() {
			int h = this.H;
			int m = this.M;
			int s = this.S;
			
			this.C = State.On1;
			Assert.IsTrue(this.CircuitState.Evaluate());

			Assert.AreEqual<int>(h, this.H);
			Assert.AreEqual<int>(m, this.M);
			Assert.AreEqual<int>(s, this.S);
			
			this.C = State.On0;
			Assert.IsTrue(this.CircuitState.Evaluate());

			return new TimeSpan(this.H, this.M, this.S);
		}

		private State Check(State value) {
			Assert.IsTrue(value == State.On0 || value == State.On1);
			return value;
		}

		private int ToInt(State state) {
			switch(state) {
			case State.On0: return 0;
			case State.On1: return 1;
			default:
				Assert.Fail();
				return -1;
			}
		}

		private int BinDecimal(FunctionProbe probe) {
			int value = 0;
			for(int i = 0; i < probe.BitWidth; i++) {
				value |= this.ToInt(probe[i]) << i;
			}
			return value;
		}

		private int Value(FunctionProbe probe, int max) {
			int value = this.BinDecimal(probe);
			value = (value >> 4) * 10 + (value & 0xF);
			Assert.IsTrue(0 <= value && value < max);
			return value;
		}
	}
}
