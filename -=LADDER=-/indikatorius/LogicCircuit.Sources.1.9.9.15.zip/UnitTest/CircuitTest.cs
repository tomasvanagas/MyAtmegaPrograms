﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicCircuit;
using System.Windows;
using System.Windows.Markup;

namespace UnitTest {
	
	/// <summary>
	/// Test for real circuits comming from files.
	/// </summary>
	[TestClass]
	public class CircuitTest {
		#region Additional test attributes
		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext { get; set; }

		//
		// You can use the following additional attributes as you write your tests:
		//
		// Use ClassInitialize to run code before running the first test in the class
		// [ClassInitialize()]
		// public static void MyClassInitialize(TestContext testContext) { }
		//
		// Use ClassCleanup to run code after all tests in a class have run
		// [ClassCleanup()]
		// public static void MyClassCleanup() { }
		//
		// Use TestInitialize to run code before running each test 
		// [TestInitialize()]
		// public void MyTestInitialize() { }
		//
		// Use TestCleanup to run code after each test has run
		// [TestCleanup()]
		// public void MyTestCleanup() { }
		//
		#endregion

		[TestMethod]
		public void JKFlipFlopTest() {
			TestProject project = this.LoadTest("UnitTestJK", "JK flip-flop test");
			Assert.AreEqual(4, project.Input.Length);
			Assert.AreEqual(2, project.Output.Length);

			JKSocket jk = new JKSocket(project.State,
				project.Input[0],
				project.Input[1],
				project.Input[2],
				project.Input[3],
				project.Output[0],
				project.Output[1]
			);

			jk.Reset();
			for(int i = 0; i < 100; i++) {
				for(int j = 0; j < 2; j++) {
					for(int k = 0; k < 2; k++) {
						jk.TestJK(j, k);
						for(int l = 0; l < 100; l++) {
							jk.TestJK(0, 0);
						}
						for(int l = 0; l < 100; l++) {
							jk.TestJK(1, 1);
						}
					}
				}
			}
		}

		[TestMethod]
		public void Counter4Test() {
			TestProject project = this.LoadTest("UnitTestCount", "Count test");
			Assert.AreEqual(2, project.Input.Length);
			Assert.AreEqual(4, project.Output.Length);

			CounterSocket c = new CounterSocket(project.State,
				project.Input[0],
				project.Input[1],
				project.Output[3],
				project.Output[2],
				project.Output[1],
				project.Output[0]
			);

			c.Reset();
			for(int i = 0; i < 1000000; i++) {
				int actual = c.Tick();
				Assert.AreEqual<int>((i + 1) % 16, actual);
			}
		}

		[TestMethod]
		public void DigitalClockTest() {
			TestProject project = this.LoadTest("DigitalClock", "Unit Test");
			Assert.AreEqual(3, project.Input.Length);
			Assert.AreEqual(3, project.Output.Length);

			ClockSocket c = new ClockSocket(project.State,
				project.Input[0],
				project.Output[0],
				project.Output[1],
				project.Output[2]
			);

			c.Start();
			for(int i = 0; i < 60 * 60 * 24 * 50; i++) {
				TimeSpan expected = new TimeSpan(0, 0, i + 1);
				expected = new TimeSpan(expected.Hours, expected.Minutes, expected.Seconds);
				TimeSpan actual = c.Tick();
				Assert.AreEqual<TimeSpan>(expected, actual);
			}
		}

		private struct TestProject {
			public ProjectManager ProjectManager;
			public Transaction Transaction;
			public LogicalCircuit Diagram;
			public CircuitState State;
			public CircuitMap Map;
			public FunctionConstant[] Input;
			public FunctionProbe[] Output;
		}

		private TestProject LoadTest(string projectName, string diagramName) {
			TestProject project = new TestProject();
			project.ProjectManager = this.LoadProject(projectName);
			project.Transaction = project.ProjectManager.BeginTransaction();
			project.Diagram = this.LogicalCircuit(project.ProjectManager, diagramName);
			project.ProjectManager.ProjectStore.Project.LogicalCircuit = project.Diagram;
			project.Map = new CircuitMap(project.Diagram);
			project.State = project.Map.Apply(1);

			List<CircuitSymbol> inputSymbol = new List<CircuitSymbol>();
			foreach(CircuitSymbol symbol in project.Diagram.CircuitSymbol) {
				if(symbol.Circuit is Constant) {
					inputSymbol.Add(symbol);
				}
			}
			inputSymbol.Sort(new CircuitSymbolComparer(true));
			project.Input = new FunctionConstant[inputSymbol.Count];
			for(int i = 0; i < project.Input.Length; i++) {
				project.Input[i] = (FunctionConstant)project.Map.Input(inputSymbol[i]);
				Assert.IsNotNull(project.Input[i]);
			}

			List<CircuitSymbol> outputSymbol = new List<CircuitSymbol>();
			foreach(CircuitSymbol symbol in project.Diagram.CircuitSymbol) {
				Gate g = symbol.Circuit as Gate;
				if(g != null && g.GateType == GateType.Probe) {
					outputSymbol.Add(symbol);
				}
			}
			outputSymbol.Sort(new CircuitSymbolComparer(true));
			project.Output = new FunctionProbe[outputSymbol.Count];
			for(int i = 0; i < project.Output.Length; i++) {
				project.Output[i] = project.Map.FunctionProbe(outputSymbol[i]);
				Assert.IsNotNull(project.Output[i]);
			}

			return project;
		}

		private ProjectManager LoadProject(string projectName) {
			ProjectManager projectManager = new ProjectManager();
			string file = null;
			try {
				file = Path.GetTempFileName();
				File.AppendAllText(file, Properties.Resources.ResourceManager.GetString(projectName), Encoding.UTF8);
				projectManager.Load(file);
			} finally {
				if(!string.IsNullOrEmpty(file) && File.Exists(file)) {
					File.Delete(file);
				}
			}
			return projectManager;
		}

		private LogicalCircuit LogicalCircuit(ProjectManager projectManager, string name) {
			foreach(LogicalCircuit c in projectManager.LogicalCircuitStore) {
				if(c.Name == name) {
					return c;
				}
			}
			return null;
		}
	}
}
