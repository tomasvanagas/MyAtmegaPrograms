﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicCircuit;
using System;

namespace UnitTest {
    /// <summary>
    ///This is a test class for Function and is intended
    ///to contain all Function Unit Tests
    ///</summary>
	[TestClass()]
	public class FunctionTest {

		#region Additional test attributes
		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext { get; set; }

		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
		//}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//
		//Use TestInitialize to run code before running each test
		//[TestInitialize()]
		//public void MyTestInitialize()
		//{
		//}
		//
		//Use TestCleanup to run code after each test has run
		//[TestCleanup()]
		//public void MyTestCleanup()
		//{
		//}
		//
		#endregion

		private Random Rand() {
			int seed = (int)DateTime.UtcNow.Ticks;
			this.TestContext.WriteLine("FunctionTest: seed = {0}", seed);
			return new Random(seed);
		}

		/// <summary>
		///A test for ControlledState
		///</summary>
		[TestMethod()]
		[DeploymentItem("LogicCircuit.exe")]
		public void ControlledStateTest() {
			CircuitState state = new CircuitState();
			state.ReserveState(6);
			TriState func = new TriState(state, 3, 4, 5);
			bool changed = func.Evaluate();
			Assert.IsFalse(changed);
			Assert.AreEqual<State>(State.Off, state[5]);

			int[] param = new int[] { 3, 4 };
			State[] value = new State[] { State.Off, State.On0, State.On1 };
			Random random = this.Rand();
			for(int i = 0; i < 1000000; i++) {
				state[param[random.Next(param.Length)]] = value[random.Next(value.Length)];
				State expected = (state[4] == State.On1) ? state[3] : State.Off;
				func.Evaluate();
				Assert.AreEqual<State>(expected, state[5]);
			}
		}

		/// <summary>
		///A test for ControlledGroup
		///</summary>
		[TestMethod()]
		[DeploymentItem("LogicCircuit.exe")]
		public void ControlledGroupTest() {
			int[] param = new int[5];
			for(int i = 0; i < param.Length; i++) {
				param[i] = 3 + i;
			}

			CircuitState state = new CircuitState();
			state.ReserveState(3 + 1 + param.Length);
			int result = state.Count - 1;

			TriStateGroup func = new TriStateGroup(state, param, result);
			bool changed = func.Evaluate();
			Assert.IsFalse(changed);
			Assert.AreEqual<State>(State.Off, state[result]);

			State[] value = new State[] { State.Off, State.On0, State.On1 };
			Random random = this.Rand();
			for(int i = 0; i < 1000000; i++) {
				state[param[random.Next(param.Length)]] = value[random.Next(value.Length)];
				State expected = State.Off;
				foreach(int p in param) {
					if(state[p] == State.On0) {
						expected = State.On0;
						break;
					} else if(state[p] == State.On1) {
						expected = State.On1;
					}
				}
				func.Evaluate();
				Assert.AreEqual<State>(expected, state[result]);
			}
		}
	}
}
