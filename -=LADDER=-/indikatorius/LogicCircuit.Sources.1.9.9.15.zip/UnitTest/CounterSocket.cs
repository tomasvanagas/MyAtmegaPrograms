﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicCircuit;

namespace UnitTest {
	public class CounterSocket {

		public CircuitState CircuitState { get; private set; }

		public FunctionConstant CConstant { get; private set; }
		public FunctionConstant RConstant { get; private set; }

		public FunctionProbe Q0Probe { get; private set; }
		public FunctionProbe Q1Probe { get; private set; }
		public FunctionProbe Q2Probe { get; private set; }
		public FunctionProbe Q3Probe { get; private set; }

		public CounterSocket(
			CircuitState circuitState,
			FunctionConstant cConstant,
			FunctionConstant rConstant,
			FunctionProbe q0Probe,
			FunctionProbe q1Probe,
			FunctionProbe q2Probe,
			FunctionProbe q3Probe
		) {
			Assert.IsNotNull(circuitState);
			Assert.IsNotNull(cConstant);
			Assert.IsNotNull(rConstant);
			Assert.IsNotNull(q0Probe);
			Assert.IsNotNull(q1Probe);
			Assert.IsNotNull(q2Probe);
			Assert.IsNotNull(q3Probe);

			this.CircuitState = circuitState;
			this.CConstant = cConstant;
			this.RConstant = rConstant;
			this.Q0Probe = q0Probe;
			this.Q1Probe = q1Probe;
			this.Q2Probe = q2Probe;
			this.Q3Probe = q3Probe;
		}

		private State Check(State value) {
			Assert.IsTrue(value == State.On0 || value == State.On1);
			return value;
		}

		public State C {
			get { return this.CConstant.Value == 0 ? State.On0 : State.On1; }
			set { this.CConstant.Value = (this.Check(value) == State.On0 ? 0 : 1); }
		}

		public State R {
			get { return this.RConstant.Value == 0 ? State.On0 : State.On1; }
			set { this.RConstant.Value = (this.Check(value) == State.On0 ? 0 : 1); }
		}

		public State Q0 {
			get { return this.Check(this.Q0Probe[0]); }
		}

		public State Q1 {
			get { return this.Check(this.Q1Probe[0]); }
		}

		public State Q2 {
			get { return this.Check(this.Q2Probe[0]); }
		}

		public State Q3 {
			get { return this.Check(this.Q3Probe[0]); }
		}

		public int ToInt(State state) {
			switch(state) {
			case State.On0: return 0;
			case State.On1: return 1;
			default:
				Assert.Fail();
				return -1;
			}
		}

		public int CurrentCount {
			get {
				return (
					this.ToInt(this.Q0) |
					this.ToInt(this.Q1) << 1 |
					this.ToInt(this.Q2) << 2 |
					this.ToInt(this.Q3) << 3
				);
			}
		}

		public void Reset() {
			this.R = State.On0;
			Assert.IsTrue(this.CircuitState.Evaluate());
			Assert.AreEqual<int>(0, this.CurrentCount);
			this.R = State.On1;
			Assert.IsTrue(this.CircuitState.Evaluate());
			Assert.AreEqual<int>(0, this.CurrentCount);
		}

		public int Tick() {
			int c = this.CurrentCount;
			this.C = State.On1;
			Assert.IsTrue(this.CircuitState.Evaluate());
			Assert.AreEqual<int>(c, this.CurrentCount);
			this.C = State.On0;
			Assert.IsTrue(this.CircuitState.Evaluate());
			return this.CurrentCount;
		}
	}
}
