﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogicCircuit;

namespace UnitTest {
	public class JKSocket {
		public CircuitState CircuitState { get; private set; }
		public FunctionConstant JConstant { get; private set; }
		public FunctionConstant CConstant { get; private set; }
		public FunctionConstant KConstant { get; private set; }
		public FunctionConstant RConstant { get; private set; }
		public FunctionProbe QProbe { get; private set; }
		public FunctionProbe NProbe { get; private set; }

		public JKSocket(
			CircuitState circuitState,
			FunctionConstant jConstant,
			FunctionConstant cConstant,
			FunctionConstant kConstant,
			FunctionConstant rConstant,
			FunctionProbe qProbe,
			FunctionProbe nProbe
		) {
			Assert.IsNotNull(circuitState);
			Assert.IsNotNull(jConstant);
			Assert.IsNotNull(cConstant);
			Assert.IsNotNull(kConstant);
			Assert.IsNotNull(rConstant);
			Assert.IsNotNull(qProbe);
			Assert.IsNotNull(nProbe);
			this.CircuitState = circuitState;
			this.JConstant = jConstant;
			this.CConstant = cConstant;
			this.KConstant = kConstant;
			this.RConstant = rConstant;
			this.QProbe = qProbe;
			this.NProbe = nProbe;
		}

		private State Check(State value) {
			Assert.IsTrue(value == State.On0 || value == State.On1);
			return value;
		}

		public State J {
			get { return this.JConstant.Value == 0 ? State.On0 : State.On1; }
			set { this.JConstant.Value = (this.Check(value) == State.On0 ? 0 : 1); }
		}

		public State C {
			get { return this.CConstant.Value == 0 ? State.On0 : State.On1; }
			set { this.CConstant.Value = (this.Check(value) == State.On0 ? 0 : 1); }
		}

		public State K {
			get { return this.KConstant.Value == 0 ? State.On0 : State.On1; }
			set { this.KConstant.Value = (this.Check(value) == State.On0 ? 0 : 1); }
		}

		public State R {
			get { return this.RConstant.Value == 0 ? State.On0 : State.On1; }
			set { this.RConstant.Value = (this.Check(value) == State.On0 ? 0 : 1); }
		}

		public State Q {
			get { return this.Check(this.QProbe[0]); }
		}

		public State N {
			get { return this.Check(this.NProbe[0]); }
		}

		public void Reset() {
			this.R = State.On0;
			Assert.IsTrue(this.CircuitState.Evaluate());
			Assert.AreEqual<State>(State.On0, this.Q);
			Assert.AreEqual<State>(State.On1, this.N);
			this.R = State.On1;
			Assert.IsTrue(this.CircuitState.Evaluate());
			Assert.AreEqual<State>(State.On0, this.Q);
			Assert.AreEqual<State>(State.On1, this.N);
		}

		public void Tick() {
			Assert.AreEqual<State>(State.On0, this.C);
			State q = this.Q;
			State n = this.N;
			this.C = State.On1;
			Assert.IsTrue(this.CircuitState.Evaluate());
			Assert.AreEqual<State>(q, this.Q);
			Assert.AreEqual<State>(n, this.N);
			this.C = State.On0;
			Assert.IsTrue(this.CircuitState.Evaluate());
		}

		private State FromInt(int state) {
			switch(state) {
			case 0: return State.On0;
			case 1: return State.On1;
			default:
				Assert.Fail();
				return State.Off;
			}
		}

		public void Test(int j, int k, int q) {
			this.J = this.FromInt(j);
			this.K = this.FromInt(k);
			this.Tick();
			Assert.AreEqual<State>(this.FromInt(q), this.Q);
			Assert.AreEqual<State>(this.FromInt(q ^ 1), this.N);
		}

		public void TestJK(int j, int k) {
			State q = this.Q;
			State n = this.N;
			Assert.AreNotEqual<State>(this.Q, this.N);

			this.J = this.FromInt(j);
			this.K = this.FromInt(k);
			this.Tick();

			Assert.AreNotEqual<State>(this.Q, this.N);

			if(j == 0 && k == 0) {
				Assert.AreEqual<State>(q, this.Q);
				Assert.AreEqual<State>(n, this.N);
			} else if(j == 1 && k == 1) {
				Assert.AreEqual<State>(n, this.Q);
				Assert.AreEqual<State>(q, this.N);
			} else {
				Assert.AreEqual<State>(this.FromInt(j), this.Q);
				Assert.AreEqual<State>(this.FromInt(k), this.N);
			}
		}
	}
}
